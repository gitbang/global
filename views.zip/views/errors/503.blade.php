<!DOCTYPE>
<html lang="en">
    <head>
        <meta charset="utf-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=0">
        <!-- The above 3 meta tags *must* come first in the head; any other head content must come *after* these tags -->
        <title>Bidworks</title>
        <!-- font libray -->
        <link href="https://fonts.googleapis.com/css?family=Lato:300,400,700" rel="stylesheet">
        <link href="https://fonts.googleapis.com/css?family=Raleway:300,400,700" rel="stylesheet">
        
        <!-- css files -->
        <link rel="stylesheet" type="text/css" href="http://maxcdn.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">
        <link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet" type="text/css" />
        <link rel="stylesheet" type="text/css" href="{{ asset('front/css/style.css') }}" />
        
    </head>

<body>

<div class="error-page">
    <div class="error-content">
        <div class="container">
            <h1>500</h1>
			<p>Oops couldn't find the page <br/>Sorry the page you requested might have been moved or deleted</p>
            <a href="{{ URL::route('home.index') }}">HOME PAGE</a>
        </div>
    </div>
</div>







<script src="http://ajax.googleapis.com/ajax/libs/jquery/1.10.2/jquery.min.js"></script>
<script>
        $(window).resize(function(){    
           
            var winH = $(window).outerHeight();
            var winW = $(window).outerWidth();
            $('.error-page').css({'width' : winW, 'height' : winH});
            
        });
        
        $(window).load(function(){  
           
            var winH = $(window).outerHeight();
            var winW = $(window).outerWidth();
            $('.error-page').css({'width' : winW, 'height' : winH});
        });
</script>
</body>
</html>