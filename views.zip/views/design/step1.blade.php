@extends('layouts.inner')
@section('title', 'Property Type')
@section('content')

<!-- List property page code -->
<div class="row_dv">
<section class="inner_page_banner">
    <img class="img-responsive" src="{{ asset('front/images/inner_banner.jpg') }}" alt="fig">
    <figcaption class="inner_banner_text">
    <div class="container text-center">
        <h2>The <span class="green">New Way</span> to Sell or Rent <span class="blue">Your Home</span></h2>
        <p>Easy. Fast. Online</p>
        </div>
    </figcaption>
</section>


<section class="row_dv mid_top_gap">
    <div class="container">
        
        <article class="col-xs-12 col-sm-6 col-md-4 col-md-offset-2">
        <div class="row_dv featured_loop">
        
        <header class="row_dv text-center featured_head">
        <h3>Standard Listing</h3>
        <p>Free</p>
        </header>

        <div class="row_dv featured_mid">
            <h4>Includes:</h4>
            <ul class="list_item">
                <li><i class="fa fa-caret-right"></i> 15 Images</li>
                <li><i class="fa fa-caret-right"></i> Professional Description</li>
                <li><i class="fa fa-caret-right"></i> Map Linked to Listing</li>
                <li><i class="fa fa-caret-right"></i> Direct Conact Forms</li>
            </ul>
            <p class="featured_text">This is the Basic Property Listing that will appear in search Result</p>
            <p class="pad_top text-center"><a href="#" class="btn btn-primary list_btn">List Your Property</a> </p>
        </div>
        </div>
        </article>



        <article class="col-xs-12  col-sm-6 col-md-4">
        <div class="row_dv featured_loop">
        
        <header class="row_dv text-center featured_head">
        <h3>Featured Listing</h3>
        <p>Mzn 1,500 (Incl.Lva)</p>
        </header>

        <div class="row_dv featured_mid">
            <h4>Includes:</h4>
            <ul class="list_item">
                <li><i class="fa fa-caret-right"></i> 15 Images</li>
                <li><i class="fa fa-caret-right"></i> Professional Description</li>
                <li><i class="fa fa-caret-right"></i> Map Linked to Listing</li>
                <li><i class="fa fa-caret-right"></i> Direct Conact Forms</li>
                <li><i class="fa fa-caret-right"></i> Alert Sent to Database</li>
                <li><i class="fa fa-caret-right"></i> Placed in Featured Section</li>
            </ul>
            <p class="featured_text">This is the Basic Property Listing that will appear in search Result</p>
            <p class="pad_top text-center"><a href="#" class="btn btn-primary list_btn">List Your Property</a> </p>
        </div>
        </div>
        </article>

    </div>
</section>


<section class="top_gap row_dv">
<div class="container">
<div class="row">

<article class="col-xs-12 col-sm-4">
<div class="media art_loop">
  <div class="media-left">
    <a href="#">
      <img class="media-object" src="{{asset('front/images/art_fig.jpg')}}" alt="Fig-1">
    </a>
  </div>
  <div class="media-body">
    <h4 class="media-heading">The standard Lorem Ipsum</h4>
    <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod </p>
    <a href="#" class="green">Konw More</a>
  </div>
</div>
</article>

<article class="col-xs-12 col-sm-4">
<div class="media art_loop">
  <div class="media-left">
    <a href="#">
      <img class="media-object" src="{{asset('front/images/art_fig.jpg')}}" alt="Fig-1">
    </a>
  </div>
  <div class="media-body">
    <h4 class="media-heading">The standard Lorem Ipsum</h4>
    <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod </p>
    <a href="#" class="green">Konw More</a>
  </div>
</div>
</article>

<article class="col-xs-12 col-sm-4">
<div class="media art_loop">
  <div class="media-left">
    <a href="#">
      <img class="media-object" src="{{asset('front/images/art_fig.jpg')}}" alt="Fig-1">
    </a>
  </div>
  <div class="media-body">
    <h4 class="media-heading">The standard Lorem Ipsum</h4>
    <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod </p>
    <a href="#" class="green">Konw More</a>
  </div>
</div>
</article>



</div>
</div>
</section>



</div>
@endsection