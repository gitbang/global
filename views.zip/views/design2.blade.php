<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="utf-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=0">
        <!-- The above 3 meta tags *must* come first in the head; any other head content must come *after* these tags -->
        <title>Propbidder</title>
		<!-- font libray -->
		<link href="https://fonts.googleapis.com/css?family=Lato:300,400,700" rel="stylesheet">
		<link href="https://fonts.googleapis.com/css?family=Raleway:300,400,700" rel="stylesheet">
		
		<!-- css files -->
		<link rel="stylesheet" type="text/css" href="http://maxcdn.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">
		<link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet" type="text/css" />
		<link rel="stylesheet" type="text/css" href="../front/css/style.css" />
		
		<!-- HTML5 Shim and Respond.js IE8 support of HTML5 elements and media queries -->
		<!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
		<!--about-us.html-->

		<!--[if lt IE 9]>
		<script src="https://oss.maxcdn.com/html5shiv/3.7.2/html5shiv.min.js"></script>
		<script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
		<![endif]-->
    </head>
<body>
<!--<div class="wrapper">
	<!-- header start -->
<!--	<header id="header" class="head-fixed">
		<div class="container-fluid">
			<div class="row">
				<div class="col-sm-3 col-xs-6">
					<h1><a href="#" class="logo"><img src="../front/images/logo.png" alt="logo" /></a>
						<a href="#" class="mb-logo"><img src="../front/images/mb-logo.png" alt="mb-logo" /></a>
					</h1>
				</div>
				<div class="col-sm-9 col-xs-6">
					<nav class="header-menu">
						<ul class="nav-menu">
							<li><a href="#" class="active">Auctions<i class="fa fa-caret-down" aria-hidden="true"></i></a>
								<ul class="submenu">
									<li><a href="#">View All Auctions</a></li>
									<li><a href="#">Markets</a></li>
									<li><a href="#">Existing Homes</a></li>
									<li><a href="#">New Homes</a></li>
								</ul>
							</li>
							<li><a href="#">Sell</a></li>
							<li><a href="#">Buy</a></li>
							<li><a href="#">Calender</a></li>
							<li><a href="#">Blog</a></li>
							<li><a href="#">About Us<i class="fa fa-caret-down" aria-hidden="true"></i></a>
								<ul class="submenu">
									<li><a href="#">View All Auctions</a></li>
									<li><a href="#">Markets</a></li>
									<li><a href="#">Existing Homes</a></li>
									<li><a href="#">New Homes</a></li>
								</ul>
							</li>
						</ul>
						<div class="signUp">
							<ul>
								<li><a href="#" data-toggle="modal" data-target="#myModal"><i class="material-icons dp48">lock</i>Sign in</a></li>
							</ul>
						</div>
					</nav>	
				</div>
			</div>
		</div>
	</header>
	<!-- header end -->
	<!-- start profile1 page here -->
	<!--<div class="profile1-page inner-page">
			<aside class="left-side-bar">
				<h2>bid works</h2>
				<div class="list-section">
					<ul>
						<li><a class="prof list" href="javascript:void(0)">Profile</a></li>
						<li><a class="fav list" href="javascript:void(0)">Favourites</a></li>
						<li><a class="hist list" href="javascript:void(0)">History</a></li>
						<li><a class="emalert list" href="javascript:void(0)">Email Alerts</a></li>
					</ul>
				</div>
			</aside>
			<section class="profile-right-section">
				<div class="container-fluid">	
					<div class="porfile-tab">
						<h2 class="page-title">Profile<a href="javascript:void(0)">Change Password</a></h2>
						<div class="profile-image-section fullWidth">
							<div class="profile-image">
								<a href="javascript:void(0)"><img src="../front/images/profile-pic.png"></a>
							</div>
							<div class="profile-image-desc">
								<div class="profile-name">Admin Clavax</div>
								<div class="add-remove-photo">
									<a href="javascript:void(0)">Remove Photo</a>
									<div class="brouse-file">
										<input type="file" class="custom-file-input">
									</div>
									<!--<a href="javascript:void(0)">Browse Photo</a>-->
								<!--</div>
							</div>


						</div>
						<div class="usr-info fullWidth">
							<div class="row">
								<div class="col-md-12"><h2>User Info</h2></div>
								<form>
									<div class="col-sm-6 col-xs-12">
										<div class="form-group">
											<label>First Name</label>
											<input type="text" name="firstname" placeholder="Admin" class="form-control">
										</div>
									</div>
									<div class="col-sm-6 col-xs-12">
										<div class="form-group">
											<label>Last Name</label>
											<input type="text" name="lastname" placeholder="Clavax" class="form-control">
										</div>
									</div>
									<div class="col-sm-6 col-xs-12">
										<div class="form-group">
											<label>Date Of Birth</label>
											<input type="text" name="dob" placeholder="DOB" class="form-control">
										</div>
									</div>
									<div class="col-sm-6 col-xs-12">
										<div class="form-group">
											<label>Contact Number</label>
											<input type="number" name="cnumber" placeholder="NA" class="form-control">
										</div>
									</div>
									<div class="col-sm-6 col-xs-12">
										<div class="form-group">
											<label>Country</label>
											<div class="form-group selectbox-wrapper">
												<select class="form-control">
													<option>Country</option>
													<option>Option 1</option>
													<option>Option 2</option>
													<option>Option 3</option>
												</select>
											</div>
										</div>
									</div>
									<div class="col-sm-6 col-xs-12">
										<div class="form-group">
											<label>State</label>
											<div class="form-group selectbox-wrapper">
												<select class="form-control">
													<option>Delhi</option>
													<option>Option 1</option>
													<option>Option 2</option>
													<option>Option 3</option>
												</select>
											</div>
										</div>
									</div>
									<div class="col-sm-6 col-xs-12">
										<div class="form-group">
											<label>Street</label>
											<div class="form-group selectbox-wrapper">
												<select class="form-control">
													<option>Street</option>
													<option>Option 1</option>
													<option>Option 2</option>
													<option>Option 3</option>
												</select>
											</div>
										</div>
									</div>
									<div class="col-sm-6 col-xs-12">
										<div class="form-group">
											<label>City</label>
											<div class="form-group selectbox-wrapper">
												<select class="form-control">
													<option>City</option>
													<option>Option 1</option>
													<option>Option 2</option>
													<option>Option 3</option>
												</select>
											</div>
										</div>
									</div>
									<div class="col-sm-6 col-xs-12">
										<button type="submit" value="Submit">Submit</button>
									</div>
								</form>
							</div>
						</div>
					</div>
					<div class="email-tab">
						<h2 class="page-title">Property Save Search Filter</h2>
						<div class="filter-serch">
							<form>
								<div class="col-sm-4 col-md-4 col-lg-3 padding-right-15">
									<div class="form-group">
										<input type="text" name="dob" placeholder="Add An Alert" class="form-control">
									</div>
								</div>
								<div class="col-sm-4 col-md-4 col-lg-3 padding-right-15">
									<div class="form-group">
										<input type="text" name="dob" placeholder="Location" class="form-control">
									</div>
								</div>
								<div class="col-sm-4 col-md-3 col-lg-2 padding-right-15">
									<div class="form-group">
										<div class="form-group selectbox-wrapper">
											<select class="form-control">
												<option>All Status</option>
												<option>Option 1</option>
												<option>Option 2</option>
												<option>Option 3</option>
											</select>
										</div>
									</div>
								</div>
								<div class="col-sm-4 col-md-3 col-lg-2 padding-right-15">
									<div class="form-group">
										<div class="form-group selectbox-wrapper">
											<select class="form-control">
												<option>All Types</option>
												<option>Option 1</option>
												<option>Option 2</option>
												<option>Option 3</option>
											</select>
										</div>
									</div>
								</div>
								<div class="col-sm-4 col-md-3 col-lg-2 padding-right-15">
									<div class="form-group">
										<div class="form-group selectbox-wrapper">
											<select class="form-control">
												<option>Bedrooms</option>
												<option>Option 1</option>
												<option>Option 2</option>
												<option>Option 3</option>
											</select>
										</div>
									</div>
								</div>
								<div class="col-sm-4 col-md-3 col-lg-2 padding-right-15">
									<div class="form-group">
										<div class="form-group selectbox-wrapper">
											<select class="form-control">
												<option>Max Area</option>
												<option>Option 1</option>
												<option>Option 2</option>
												<option>Option 3</option>
											</select>
										</div>
									</div>
								</div>
								<div class="col-sm-4 col-md-3 col-lg-2 padding-right-15">
									<div class="form-group">
										<div class="form-group selectbox-wrapper">
											<select class="form-control">
												<option>Min Area</option>
												<option>Option 1</option>
												<option>Option 2</option>
												<option>Option 3</option>
											</select>
										</div>
									</div>
								</div>
								<div class="col-sm-4 col-md-3 col-lg-2 padding-right-15">
									<div class="form-group">
										<div class="form-group selectbox-wrapper">
											<select class="form-control">
												<option>Price </option>
												<option>Option 1</option>
												<option>Option 2</option>
												<option>Option 3</option>
											</select>
										</div>
									</div>
								</div>								
								<div class="form-group">
									<button type="button" value="Add An Alert">Add An Alert</button>
								</div>
							</form>
						</div>
						<div class="filter-data-table">
							<table align="center" cellpadding="0" cellspacing="0" width="100%">
								<tr>
									<th>Keywords</th>
									<th>Location</th>
									<th>Price<span>(Min - Max)</span></th>
									<th>Status</th>
									<th>Bedroom</th>
									<th>Types</th>
									<th>Area<span>(Min - Max)</span></th>
									<th></th>
								</tr>
								<tr>
									<td>Buy</td>
									<td>India</td>
									<td>243243-6565666</td>
									<td>Rent</td>
									<td>2</td>
									<td>Apartment</td>
									<td>25-10000</td>
									<td><a href="#" class="view">View</a><br/><a href="#">Delete</a></td>
								</tr>	
								<tr>
									<td>Buy</td>
									<td>India</td>
									<td>243243-6565666</td>
									<td>Rent</td>
									<td>2</td>
									<td>Apartment</td>
									<td>25-10000</td>
									<td><a href="#" class="view">View</a><br/><a href="#">Delete</a></td>
								</tr>
								<tr>
									<td>Buy</td>
									<td>India</td>
									<td>243243-6565666</td>
									<td>Rent</td>
									<td>2</td>
									<td>Apartment</td>
									<td>25-10000</td>
									<td><a href="#" class="view">View</a><br/><a href="#">Delete</a></td>
								</tr>
								<tr>
									<td>Buy</td>
									<td>India</td>
									<td>243243-6565666</td>
									<td>Rent</td>
									<td>2</td>
									<td>Apartment</td>
									<td>25-10000</td>
									<td><a href="#" class="view">View</a><br/><a href="#">Delete</a></td>
								</tr>
							</table>
						</div>
					</div>
				</section>
			</div>
	</div>-->
	<!-- end profile1 page here -->
	
	<!-- property page submit -->
	
	<!--<div class="body-content header-margin">
		<!--<section class="banner inner-page-banner">
			<div class="banner-content">
				<div class="container">
					<h2>Home Auctions</h2>
					<h3><span>For Mainstream</span> REAL ESTATE</h3>				
				</div>
			</div>
		</section>
		<section class="property-submit-block">
			<div class="container">
				<h3>Property Submit</h3>
				<div class="form-section">
					<form>
						<div class="row">
							<div class="col-sm-6 col-xs-12 padding-right">
								<div class="form-group">
									<label>First Name<sup>*</sup></label>
									<input type="text" class="form-control" />
								</div>
							</div>
							<div class="col-sm-6 col-xs-12 padding-left">
								<div class="form-group">
									<label>Last Name<sup>*</sup></label>
									<input type="text" class="form-control" />
								</div>
							</div>
						</div>
						<div class="row">
							<div class="col-sm-6 col-xs-12 padding-right">
								<div class="form-group">
									<label>Email<sup>*</sup></label>
									<input type="email" class="form-control" />
								</div>
							</div>
							<div class="col-sm-6 col-xs-12 padding-left">
								<div class="form-group">
									<label>Phone Number<sup>*</sup></label>
									<input type="text" class="form-control" />
								</div>
							</div>
						</div>
						<div class="row">
							<div class="col-sm-6 col-xs-12 padding-right">
								<div class="form-group">
									<label>Address Line 1<sup>*</sup></label>
									<input type="text" class="form-control" />
								</div>
							</div>
							<div class="col-sm-6 col-xs-12 padding-left">
								<div class="form-group">
									<label>Address Line 2</label>
									<input type="text" class="form-control" />
								</div>
							</div>
						</div>
						<div class="row">
							<div class="col-sm-6 col-xs-12 padding-right">
								<div class="form-group">
									<label>Country<sup>*</sup></label>
									<select class="form-control">
										<option></option>
										<option>India</option>
										<option>China</option>
									</select>
								</div>
							</div>
							<div class="col-sm-6 col-xs-12 padding-left">
								<div class="form-group">
									<label>State<sup>*</sup></label>
									<select class="form-control">
										<option></option>
										<option>India</option>
										<option>China</option>
									</select>
								</div>
							</div>
						</div>
						<div class="row">
							<div class="col-sm-6 col-xs-12 padding-right">
								<div class="form-group">
									<label>City<sup>*</sup></label>
									<select class="form-control">
										<option></option>
										<option>India</option>
										<option>China</option>
									</select>
								</div>
							</div>
							<div class="col-sm-6 col-xs-12 padding-left">
								<div class="form-group">
									<label>Zip Code<sup>*</sup></label>
									<input type="text" class="form-control" />
								</div>
							</div>
						</div>
						<div class="row">
							<div class="col-sm-12 col-xs-12">
								<div class="form-group">
									<label>Message</label>
									<textarea class="form-control">
									</textarea>
								</div>
							</div>
						</div>
						<div class="row">
							<div class="col-sm-12 col-xs-12 text-center">
								<button class="btn submitBtn">Submit</button>
							</div>
						</div>
					</form>
				</div>				
			</div>
		</section>-->
		<!--<section class="banner">
			<div class="block-page-banner">								
				<figure>
					<img src="../front/images/home-slide1.jpg" alt="logo" />
				</figure>
				<div class="banner-content">
					<div class="container">
						<h2>Home Auctions</h2>
						<h3><span>For Mainstream</span> REAL ESTATE</h3>
					</div>
				</div>			
			</div>
		</section>
		<section class="block-page-content">
			<div class="container-fluid">
				<div class="row">
					<div class="col-xs-12 col-sm-6 col-md-4">
						<div class="blog-list">
							<figure>
								<img src="../front/images/map-building1.jpg" alt="" />
								<a href="#"></a>
							</figure>
							<div class="block-list-content">
								<h4>Propbidder is a home auction <span>marketplace for non-distressed</span></h4>
								<p>What is Curadux and why is it needed?</p>
								<ul class="social-media-icons">
									<li><a href="#"><i class="fa fa-twitter" aria-hidden="true"></i></a></li>
									<li><a href="#"><i class="fa fa-facebook" aria-hidden="true"></i></a></li>
									<li><a href="#"><i class="fa fa-envelope-o" aria-hidden="true"></i></a></li>
								</ul>
							</div>
						</div>
					</div>
					<div class="col-xs-12 col-sm-6 col-md-4">
						<div class="blog-list">
							<figure>
								<img src="../front/images/map-building1.jpg" alt="" />
								<a href="#"></a>
							</figure>
							<div class="block-list-content">
								<h4>Propbidder is a home auction <span>marketplace for non-distressed</span></h4>
								<p>What is Curadux and why is it needed?</p>
								<ul class="social-media-icons">
									<li><a href="#"><i class="fa fa-twitter" aria-hidden="true"></i></a></li>
									<li><a href="#"><i class="fa fa-facebook" aria-hidden="true"></i></a></li>
									<li><a href="#"><i class="fa fa-envelope-o" aria-hidden="true"></i></a></li>
								</ul>
							</div>
						</div>
					</div>
					<div class="col-xs-12 col-sm-6 col-md-4">
						<div class="blog-list">
							<figure>
								<img src="../front/images/map-building1.jpg" alt="" />
								<a href="#"></a>
							</figure>
							<div class="block-list-content">
								<h4>Propbidder is a home auction <span>marketplace for non-distressed</span></h4>
								<p>What is Curadux and why is it needed?</p>
								<ul class="social-media-icons">
									<li><a href="#"><i class="fa fa-twitter" aria-hidden="true"></i></a></li>
									<li><a href="#"><i class="fa fa-facebook" aria-hidden="true"></i></a></li>
									<li><a href="#"><i class="fa fa-envelope-o" aria-hidden="true"></i></a></li>
								</ul>
							</div>
						</div>
					</div>
					<div class="col-xs-12 col-sm-6 col-md-4">
						<div class="blog-list">
							<figure>
								<img src="../front/images/map-building1.jpg" alt="" />
								<a href="#"></a>
							</figure>
							<div class="block-list-content">
								<h4>Propbidder is a home auction <span>marketplace for non-distressed</span></h4>
								<p>What is Curadux and why is it needed?</p>
								<ul class="social-media-icons">
									<li><a href="#"><i class="fa fa-twitter" aria-hidden="true"></i></a></li>
									<li><a href="#"><i class="fa fa-facebook" aria-hidden="true"></i></a></li>
									<li><a href="#"><i class="fa fa-envelope-o" aria-hidden="true"></i></a></li>
								</ul>
							</div>
						</div>
					</div>
				</div>
			</div>
		</section>-->


		<!-- <section class="banner inner-page-banner">
			<div class="banner-content">
				<div class="container">
					<h2>Home Auctions</h2>
					<h3><span>For Mainstream</span> REAL ESTATE</h3>				
				</div>
			</div>
		</section>
		<section class="bid-registration-page">
			<div class="container">
				<h3>Bidding Registration</h3>
				<div class="form-section">
					<form>
						<h4>Buyer Information</h4>
						<div class="buyar-info gray-bg">
							<div class="row">
								<div class="col-sm-6 col-xs-12 padding-right">
									<div class="form-group">
										<label>Registrant Name<sup>*</sup></label>
										<input type="text" class="form-control" />
									</div>
								</div>
								<div class="col-sm-6 col-xs-12 padding-left">
									<div class="form-group">
										<label>Buyer Name(if different)</label>
										<input type="text" class="form-control" />
									</div>
								</div>
							</div>
							<div class="row">
								<div class="col-sm-6 col-xs-12 padding-right">
									<div class="form-group">
										<label>Email<sup>*</sup></label>
										<input type="email" class="form-control" />
									</div>
								</div>
								<div class="col-sm-6 col-xs-12 padding-left">
									<div class="form-group">
										<label>Mobile Number<sup>*</sup></label>
										<input type="number" class="form-control" />
									</div>
								</div>
							</div>	
							<div class="row">
								<div class="col-sm-6 col-xs-12 padding-right">
									<div class="form-group">
										<label>Office Number<sup>*</sup></label>
										<input type="text" class="form-control" />
									</div>
								</div>
								<div class="col-sm-6 col-xs-12 padding-left">
									<div class="form-group">
										<label>Extension</label>
										<input type="text" class="form-control" />
									</div>
								</div>
							</div>	
							<div class="row">
								<div class="col-sm-6 col-xs-12 padding-right">
									<div class="form-group">
										<label>Address Line 1<sup>*</sup></label>
										<input type="text" class="form-control" />
									</div>
								</div>
								<div class="col-sm-6 col-xs-12 padding-left">
									<div class="form-group">
										<label>Address Line 2</label>
										<input type="text" class="form-control" />
									</div>
								</div>
							</div>
							<div class="row">
								<div class="col-sm-6 col-xs-12 padding-right">
									<div class="form-group">
										<label>City<sup>*</sup></label>
										<select class="form-control">
											<option></option>
											<option>India</option>
											<option>China</option>
										</select>
									</div>
								</div>
								<div class="col-sm-6 col-xs-12 padding-left">
									<div class="form-group">
										<label>Zip Code<sup>*</sup></label>
										<input type="text" class="form-control" />
									</div>
								</div>
							</div>
							<div class="row">
								<div class="col-sm-6 col-xs-12 padding-right">
									<div class="form-group">
										<label>Country<sup>*</sup></label>
										<select class="form-control">
											<option></option>
											<option>India</option>
											<option>China</option>
										</select>
									</div>
								</div>
								<div class="col-sm-6 col-xs-12 padding-left">
									<div class="form-group">
										<label>State<sup>*</sup></label>
										<select class="form-control">
											<option></option>
											<option>India</option>
											<option>China</option>
										</select>
									</div>
								</div>
							</div>
												
						</div>
						<h4>Property to purchase</h4>
						<div class="purchase-info gray-bg">
							<div class="row">
								<div class="col-xs-12">
									<div class="form-group">
										<label>First Name<sup>*</sup></label>
										<select class="form-control">
											<option></option>
											<option>India</option>
											<option>China</option>
										</select>
									</div>
								</div>								
							</div>
						</div>						
						<h4>Proof of funds</h4>
						<div class="funds-info gray-bg">
							<div class="row">
								<div class="col-md-6 col-sm-12 col-xs-12 padding-right">
									<div class="form-group">
										<label>Requested Bid Limit<sup>*</sup></label>
										<input type="text" class="form-control" />
									</div>
								</div>								
							</div>
							<div class="row">
								<div class="col-sm-12 col-xs-12">
									<p>Please provide proof of funds which will demonstrate your ability to bind up to your requested limit.</p>
								</div>
								<div class="col-md-6 col-sm-12 col-xs-12 padding-right">									
									<select class="form-control">
										<option>Bank statement or verification</option>
										<option>India</option>
										<option>China</option>
									</select>
								</div>		
								<div class="col-md-6 col-sm-12 col-xs-12 padding-left add-row">	
									<div class="brouse-file choose-file">
                                        <input type="file" name="profileimg" id="profileimg" onchange="checkimagetype(this.id)" data-targetimg="imageTag" class="custom-file-input">								
										<label for="profileimg"><span>Choose File</span><span class="file-text">no file chosen</span></label>
                                    </div>
									<button class="btn addMore">Add More</button>									
								</div>								
							</div>
							<div class="row">
								<div class="col-sm-12 col-xs-12 text-center">
									<div class="btn-block">
										<button class="btn submitBtn saveBtn">Save & Continue Later</button>
										<button class="btn submitBtn">Submit</button>
									</div>
								</div>
							</div>
						</div>
						
					</form>
				</div>				
			</div>
		</section> -->

		<!--<section class="banner bid-detail-banner">
			<div class="banner-content">
				<div class="container">
					<h2>Home Auctions</h2>
					<h3><span>For Mainstream</span> REAL ESTATE</h3>				
				</div>
			</div>
		</section>
		<section class="bid-detail-page">
			<div class="container">
				<h3>Bid Details</h3>
				<div class="bid-detail-block">
					<div class="bid-left-content">
						<form>
							<div class="form-group">
								<input type="text" name="" class="form-control" >
								<button class="bidBtn">BID</button>
							</div>
						</form>
						<figure>
							<img src="../front/images/property-img1.jpg" alt="" />
						</figure>
						<h4>660 Douglass Street...</h4>
						<h5>Noe Valley, San Francisco, California</h5>
						<ul>
							<li>Current Bid: <span>3,990,000</span></li>
							<li>Next Bid: <span>4,000,000</span></li>
							<li>Bid Increments: <span>5,000</span></li>
							<li>Bid Status: <span>OutBid</span></li>
							<li>No. of Bid: <span>25</span></li>
							<li>Active Bid: <span>10</span></li>
						</ul>
					</div>
					<div class="bid-history-content">
						<h4 class="history-heading">History</h4>
						<div class="history-list">
							<table>
								<tr>
									<th>Time</th>
									<th>Amount</th>
									<th>Bidder</th>
								</tr>
								<tr>
									<td><span class="date"><i class="fa fa-calendar" aria-hidden="true"></i>January 5, 2017</span><span class="time">12:45 PM</span></td>
									<td>3,990,000</td>
									<td>User 3</td>
								</tr>
								<tr>
									<td><span class="date"><i class="fa fa-calendar" aria-hidden="true"></i>January 5, 2017</span><span class="time">12:45 PM</span></td>
									<td>3,990,000</td>
									<td>User 3</td>
								</tr>
								<tr>
									<td><span class="date"><i class="fa fa-calendar" aria-hidden="true"></i>January 5, 2017</span><span class="time">12:45 PM</span></td>
									<td>3,990,000</td>
									<td>User 3</td>
								</tr>
								<tr>
									<td><span class="date"><i class="fa fa-calendar" aria-hidden="true"></i>January 5, 2017</span><span class="time">12:45 PM</span></td>
									<td>3,990,000</td>
									<td>User 3</td>
								</tr>
								<tr>
									<td><span class="date"><i class="fa fa-calendar" aria-hidden="true"></i>January 5, 2017</span><span class="time">12:45 PM</span></td>
									<td>3,990,000</td>
									<td>User 3</td>
								</tr>
								<tr>
									<td><span class="date"><i class="fa fa-calendar" aria-hidden="true"></i>January 5, 2017</span><span class="time">12:45 PM</span></td>
									<td>3,990,000</td>
									<td>User 3</td>
								</tr>
								<tr>
									<td><span class="date"><i class="fa fa-calendar" aria-hidden="true"></i>January 5, 2017</span><span class="time">12:45 PM</span></td>
									<td>3,990,000</td>
									<td>User 3</td>
								</tr>
								<tr>
									<td><span class="date"><i class="fa fa-calendar" aria-hidden="true"></i>January 5, 2017</span><span class="time">12:45 PM</span></td>
									<td>3,990,000</td>
									<td>User 3</td>
								</tr>
								<tr>
									<td><span class="date"><i class="fa fa-calendar" aria-hidden="true"></i>January 5, 2017</span><span class="time">12:45 PM</span></td>
									<td>3,990,000</td>
									<td>User 3</td>
								</tr>
								<tr>
									<td><span class="date"><i class="fa fa-calendar" aria-hidden="true"></i>January 5, 2017</span><span class="time">12:45 PM</span></td>
									<td>3,990,000</td>
									<td>User 3</td>
								</tr>
								<tr>
									<td><span class="date"><i class="fa fa-calendar" aria-hidden="true"></i>January 5, 2017</span><span class="time">12:45 PM</span></td>
									<td>3,990,000</td>
									<td>User 3</td>
								</tr>
								<tr>
									<td><span class="date"><i class="fa fa-calendar" aria-hidden="true"></i>January 5, 2017</span><span class="time">12:45 PM</span></td>
									<td>3,990,000</td>
									<td>User 3</td>
								</tr>
								<tr>
									<td><span class="date"><i class="fa fa-calendar" aria-hidden="true"></i>January 5, 2017</span><span class="time">12:45 PM</span></td>
									<td>3,990,000</td>
									<td>User 3</td>
								</tr>
							</table>
						</div>
					</div>
				</div>			
			</div>
		</section>-->
		

		<!-- about us page content -->
		<!--<section class="banner about-us-banner">
			<div class="banner-content">
				<div class="container">
					<h2>Home Auctions</h2>
					<h3><span>For Mainstream</span> REAL ESTATE</h3>				
				</div>
			</div>
		</section>
		<section class="about-us-block">
			<div class="container">
				<h3> About Us</h3>
				<ul>
					<li>If you thought home auctions were just for distressed or ultra-luxury properties, THINK AGAIN!</li>
					<li>Propbidder is a disruptive online home auction marketplace for new and existing homes.</li>
					<li>We work with homebuilders and real estate agents to improve (not replace) the traditional sales process. For buyers, sellers, and other consumers, Propbidder is the dominant discovery and bidding latform or mainstream, non-distressed home auctions.</li>
				</ul>
			</div>
		</section>
		<section class="who-we-serve">
			<div class="container">
				<h3>Who We Serve</h3>
				<div class="serve-slider">
					<div>
						<div class="img-block">
							<figure>
								<img src="../front/images/serve-img1.jpg" alt="" />
							</figure>							
						</div>
						<h4>Homebuilders</h4>
						<p>Efficient Price-Setting <span>Sustain Buyer Momentum</span> Facilitate Foreign Audiences</p>
					</div>
					<div>
						<div class="img-block">
							<figure>
								<img src="../front/images/serve-img2.jpg" alt="" />
							</figure>							
						</div>
						<h4>Agents & Brokers</h4>
						<p>Protect Commissions <span>Save Time on Negotiations</span> Capture Motivated Buyers & Sellers</p>
					</div>
					<div>
						<div class="img-block">
							<figure>
								<img src="../front/images/serve-img3.jpg" alt="" />
							</figure>							
						</div>
						<h4>Buyers & Sellers</h4>
						<p>Transact Faster <span>Increase Offer Transparency</span> Discover A Market's Best Homes</p>
					</div>
				</div>
			</div>			
		</section>
		<section class="real-state-domain">
			<div class="container">
				<h3>Strong Real Estate Domain & Tech Expertise Among <br/>Founding Team, Mentors, & Advisors</h3>
				<div class="row">
					<div class="col-xs-12">
						<div class="logo-slider">
							<div>
								<div class="slide-item"><img src="../front/images/real-state-logo1.jpg" alt="" /></div>
							</div>
							<div>
								<div class="slide-item"><img src="../front/images/real-state-logo2.jpg" alt="" /></div>
							</div>
							<div>
								<div class="slide-item"><img src="../front/images/real-state-logo3.jpg" alt="" /></div>
							</div>
							<div>
								<div class="slide-item"><img src="../front/images/real-state-logo4.jpg" alt="" /></div>
							</div>
							<div>
								<div class="slide-item"><img src="../front/images/real-state-logo1.jpg" alt="" /></div>
							</div>
							<div>
								<div class="slide-item"><img src="../front/images/real-state-logo2.jpg" alt="" /></div>
							</div>
							<div>
								<div class="slide-item"><img src="../front/images/real-state-logo3.jpg" alt="" /></div>
							</div>
							<div>
								<div class="slide-item"><img src="../front/images/real-state-logo4.jpg" alt="" /></div>
							</div>
						</div>

					</div>
				</div>
			</div>
		</section>
		<section class="combine-technology">
			<div class="container">
				<h3>A Rare Combination Of Real Estate & Technology</h3>
				<div class="technology-slider">				
					<div>
						<div class="technology-info">
							<figure>
								<img src="../front/images/technology-user1.jpg" alt="" />
							</figure>
							<h4>Mikael Hastrup<span>CEO, Founder</span></h4>
							<ul>
								<li>Stanford GSB 17 , UC Irvine 12</li>
								<li>RE Tech Investor @ Fifth Wall</li>
								<li>Growth @ Matterport</li>
								<li>Strategy @ irvine Company</li>
								<li>TMT IB @ Deutsche Bank</li>
							</ul>
						</div>
					</div>
					<div>
						<div class="technology-info">
							<figure>
								<img src="../front/images/technology-user2.jpg" alt="" />
							</figure>
							<h4>Akshay Rampuria<span>CTO, Co-Founder</span></h4>
							<ul>
								<li>Stanford Computer Science '17</li>
								<li>President @ Stanford VC Club</li>
								<li>Full Stack Engineer @ Various Early Stage Startups</li>
								<li>Experienced with Deep Learning</li>
							</ul>
						</div>
					</div>
					<div>
						<div class="technology-info">
							<figure>
								<img src="../front/images/technology-user3.jpg" alt="" />
							</figure>
							<h4>Erin Allard<span>Product, Co-Founder</span></h4>
							<ul>
								<li>MS Int’l RE @ FIU, Mills ‘12</li>
								<li>Licensed RE Broker</li>
								<li>RE Investor @ Rockford</li>
								<li>Instructor @ Girls Who Code</li>
								<li>CS Fellow @ Hackbright</li>
							</ul>
						</div>
					</div>
				</div>
			</div>
		</section>	
		<section class="get-in-touch-footer">
			<div class="container">
				<h3>GET IN TOUCH</h3>
				<div class="row">
					<div class="col-xs-12 col-sm-6">
						<a href="#" class="location-link">Stanford, CA</a>
					</div>
					<div class="col-xs-12 col-sm-6 border-left">
						<a href="mailto:info@Propbidder.com" target="_blank" class="mail-link">info@Propbidder.com</a>
					</div>
				</div>
			</div>
		</section>	-->

	<!--	<section class="banner">
			<div class="block-detail-page-banner">								
				<figure>
					<img src="../front/images/home-slide1.jpg" alt="logo" />
				</figure>
				<div class="banner-content">
					<div class="container">
						<h2>Home Auctions</h2>
						<h3><span>For Mainstream</span> REAL ESTATE</h3>
					</div>
				</div>			
			</div>
		</section>
		<section class="block-detail-page-content">
			<div class="container">
				<div class="inner-container">
					<ul class="social-media">
						<li><a href="#"><i class="fa fa-twitter" aria-hidden="true"></i></a></li>
						<li><a href="#"><i class="fa fa-facebook" aria-hidden="true"></i></a></li>
						<li><a href="#"><i class="fa fa-envelope-o" aria-hidden="true"></i></a></li>
					</ul>
					<ul class="chat-comment">
						<li><a href="#"></a></li>
						<li><a href="#" class="chat-icon"></a></li>
					</ul>
					<div class="blog-detail-heading">
						<h3>fdsfsas</h3>	
					</div>
					<div class="comment-blog">
						<h4>4 COMMENT</h4>						
						<form class="submit-block">
							<div class="text-area">
								<textarea placeholder="comments...."></textarea>
							</div>
							<div class="submit-comment">
								<div class="form-group half-width pad-right">
									<label>Name</label>
									<input type="text" class="form-control" />									
								</div>
								<div class="form-group half-width pad-left">
									<label>Email</label>
									<input type="email" class="form-control" />									
								</div>
								<button>Submit Comment</button>
							</div>
						</form>
					</div>
					<div class="comment-list">
						<p><span class="user-name">Ashish Sharma</span> <small> •  December 20, 2016 </small></p>
						<p class="blog_comment_text">gfbgsg</p>
					</div>
					<div class="comment-list">
						<p><span class="user-name">Ashish Sharma</span> <small> •  December 20, 2016 </small></p>
						<p class="blog_comment_text">gfbgsg</p>
					</div>
					<div class="comment-list">
						<p><span class="user-name">Ashish Sharma</span> <small> •  December 20, 2016 </small></p>
						<p class="blog_comment_text">gfbgsg</p>
					</div>
					<div class="comment-list">
						<p><span class="user-name">Ashish Sharma</span> <small> •  December 20, 2016 </small></p>
						<p class="blog_comment_text">gfbgsg</p>
					</div>
				</div>
			</div>
		</section>
		
	</div>
	
	
	<!-- footer start from here -->
	<!--<footer id="footer">
		<div class="footer-menu">
			<div class="container">
				<div class="row">
					<div class="col-sm-8 hidden-xs">
						<ul>
							<li><a href="#">Auctions</a></li>
							<li><a href="#">View All Auctions</a></li>
							<li><a href="#">Markets</a></li>
							<li><a href="#">Existing Home</a></li>
							<li><a href="#">New Homes</a></li>
						</ul>
						<ul>
							<li><a href="#">Lifestyles</a></li>
							<li><a href="#">Mountain</a></li>
							<li><a href="#">Water</a></li>
							<li><a href="#">Metro</a></li>
							<li><a href="#">Ranch</a></li>
						</ul>
						<ul>
							<li><a href="#">Company</a></li>
							<li><a href="#">About Us</a></li>
							<li><a href="#">Team</a></li>
							<li><a href="#">Blog</a></li>
							<li><a href="#">Press Release</a></li>
						</ul>
					</div>
					<div class="col-sm-4 hidden-xs">
						<div class="get-in-touch">
							<h5>Get in Touch</h5>
							<a href="#" class="location-link"><i class="fa fa-map-marker" aria-hidden="true"></i>Stanford, CA</a>
							<span class="clearfix"></span>
							<a href="mailto:info@Propbidder.com" class="mail-link"><i class="fa fa-envelope" aria-hidden="true"></i> info@Propbidder.com</a>
						</div>
					</div>
				</div>
			</div>
		</div>
		<div class="footer-bottom">
			<div class="container">
				<div class="row"> 
					<div class="col-sm-3 pull-right col-xs-12">
						<ul class="social-media">
							<li><a href="#"><i class="fa fa-facebook" aria-hidden="true"></i></a></li>
							<li><a href="#"><i class="fa fa-linkedin" aria-hidden="true"></i></a></li>
							<li><a href="#"><i class="fa fa-google-plus" aria-hidden="true"></i></a></li>
						</ul>
					</div>
					<div class="col-sm-6 col-sm-offset-3 text-center col-xs-12">
						<p class="copy-right">&copy; 2017 Propbidder, Inc.</p>
					</div>					
				</div>
			</div>
		</div>
	</footer>	<!-- footer end here -->
<!--</div>-->

<div class="error-page">
	<div class="error-content">
		<div class="container">
			<h1>404</h1>
			<p>Oops couldn't find the page <br/>Sorry the page you requested might have been moved or deleted</p>
			<a href="">HOME PAGE</a>
		</div>
	</div>
</div>



<script src="http://ajax.googleapis.com/ajax/libs/jquery/1.10.2/jquery.min.js"></script>
<script src="../front/js/bootstrap.min.js"></script>
<script src="../front/js/slick.min.js"></script>
<script src="../front/js/animation.js"></script>
<script src="../front/js/custom.js"></script>
<script>
	$('.logo-slider').slick({
		dots: false,
		infinite: true,
		speed: 300,
		slidesToShow: 4,
		slidesToScroll: 1,
		responsive: [
			{
			  breakpoint: 991,
			  settings: {
			    slidesToShow: 3,
			    slidesToScroll: 1,
			  }
			},
			{
			  breakpoint: 600,
			  settings: {
			    slidesToShow: 2,
			    slidesToScroll: 1
			  }
			},
			{
			  breakpoint: 479,
			  settings: {
			    slidesToShow: 1,
			    slidesToScroll: 1,
			  }
			}
		]
	});
	$('.technology-slider').slick({
		dots: false,
		infinite: true,
		speed: 300,
		slidesToShow: 3,
		slidesToScroll: 1,
		responsive: [
			{
			  breakpoint: 991,
			  settings: {
			    slidesToShow: 2,
			    slidesToScroll: 1,
			  }
			},
			{
			  breakpoint: 767,
			  settings: {
			    slidesToShow: 1,
			    slidesToScroll: 1
			  }
			}
		]
	});
	$('.serve-slider').slick({
		dots: false,
		infinite: true,
		speed: 300,
		slidesToShow: 3,
		slidesToScroll: 1,
		responsive: [
			{
			  breakpoint: 991,
			  settings: {
			    slidesToShow: 2,
			    slidesToScroll: 1,
			  }
			},
			{
			  breakpoint: 767,
			  settings: {
			    slidesToShow: 1,
			    slidesToScroll: 1
			  }
			}
		]
	});
</script>

</body> 
</html>   
