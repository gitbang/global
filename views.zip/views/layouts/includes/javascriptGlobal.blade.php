<script>
window.baseurl='<?php echo  url() . '/' . $langprefix;?>';
window.getCheckoutUrl = "{!! URL::Route('property.getCheckout') !!}";
window.limit_upd_image="{{Config::get('constants.limit_upd_image')}}";
window.currency=JSON.parse('<?php echo json_encode(Config::get("constants.currency"),JSON_FORCE_OBJECT)?>');
window.default_currency = '{{ Config::get("constants.DEFAULT_CURRENCY") }}';
window.getSuccessUrl = "{!! URL::Route('home.success') !!}";

</script>