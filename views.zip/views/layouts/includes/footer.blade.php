<!-- Footer start -->
{{--*/ $sessionValues = Session::get('auth_user'); /*--}}


    <!-- footer start from here -->
    <footer id="footer">
        <div class="footer-menu">
            <div class="container">
                <div class="row">
                    <div class="col-sm-8 hidden-xs">
                        <ul>
                            <li><h5>Buy</h5></li>
                            <li><a href="{{ URL::route('property.index') }}">View All Homes</a></li>
                            <li><a href="{!! URL::route('market.index') !!}">Markets</a></li>
                            <li><a href="{!! URL::route('property.newhome') !!}">New Homes</a></li>
                            <li><a href="{!! URL::route('property.existinghome') !!}">New Condos</a></li>
                            
                        </ul>
                       
                        <ul>
                            <li><h5>Company</h5></li>
                            <li><a href="{!! URL::route('home.about') !!}">About Us</a></li>
                            
                            <li><a href="{!! URL::route('blogs.index') !!}">Blog</a></li>
                            
                        </ul>
                    </div>
                    <div class="col-sm-4 hidden-xs">
                        <div class="get-in-touch">
                            <h5>Get in Touch</h5>
                            <a href="https://www.google.com/maps/place/Knight+Management+Center/@37.3216564,-122.1538185,10.5z/data=!4m5!3m4!1s0x0:0x18fe9f3c7b2c2106!8m2!3d37.4281449!4d-122.1623136" target="_blank" class="location-link"><i class="fa fa-map-marker" aria-hidden="true"></i>Stanford, CA</a>
                            <span class="clearfix"></span>
                            <a href="mailto:info@propbidder.com" class="mail-link"><i class="fa fa-envelope" aria-hidden="true"></i> info@propbidder.com</a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="footer-bottom">
            <div class="container">
                <div class="row"> 
                    <div class="col-sm-3 pull-right col-xs-12">
                        <ul class="social-media">
                            <li><a href="javascript:void(0)" target="_blank"><i class="fa fa-facebook" aria-hidden="true"></i></a></li>
                            <li><a href="javascript:void(0)" target="_blank"><i class="fa fa-linkedin" aria-hidden="true"></i></a></li>
                            <li><a href="javascript:void(0)" target="_blank"><i class="fa fa-google-plus" aria-hidden="true"></i></a></li>
                        </ul>
                    </div>
                    <div class="col-sm-6 col-sm-offset-3 text-center col-xs-12">
                        <p class="copy-right">&copy; 2017 Propbidder, Inc.</p>
                    </div>                  
                </div>
            </div>
        </div>
    </footer>   <!-- footer end here -->











