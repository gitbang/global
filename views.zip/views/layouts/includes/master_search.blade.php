<form id="propertyFilertForm" method="get" action="{{URL::route('property.rent')}}" class="banner-form">
    <div class="col-xs-12 col-sm-10 col-sm-offset-1 no_pad_lt_rt">
        <div class="hybrid-tabs">
            <a class="tab  property_type_filetr" data="0" href="javascript:void(0);">{!! Lang::get('common.buy'); !!}</a>    
            <a class="tab  active property_type_filetr" data="1" href="javascript:void(0);">{!! Lang::get('common.rent'); !!}</a>

        </div>
        <input type="hidden" value='1' class=" "  id="type" name="type" >
        <div class="row_dv">
            <div class="fieldset_block">

                <div class="col-xs-12 col-sm-4">
                    <input type="text" value='' class="propertyFilter  "  id="city" name="city" >
                </div>

                <div class="col-xs-12 col-sm-3">
                    <input type="text" value=""  id="property_type"  name="property_type">
                </div>

                <div class="col-xs-12 col-sm-3" >

                    <div id="budget_dropdown" class="row_dv form-control">
                        <span class="budet_tigger"></span>
                        <span class="value_number" id="showValueData">{{trans("common.budget")}}</span>
                    </div>  

                    <div class="budget_search" id="budgetDivMain" style="display: none;">
                        <div class="row_dv min_max_dv">
                            <div class="min_dv"><span id="arrowIdmin" class="triangle-down"></span> <label>{{trans('common.min')}}</label><input type="text" readonly id='minpriceInput'  placeholder="{{trans('common.min')}}" class="numeric form-control"></div>
                            <div class="min_gap">-</div>
                            <div class="max_dv"><span style="display:none" id="arrowIdmax" class="triangle-down"></span> <label>{{trans('common.max')}}</label><input type="text" readonly id='maxpriceInput' placeholder="{{trans('common.max')}}" class="numeric form-control"></div>
                        </div>
                        <input type="hidden" class="" name="minprice" id="minprice">
                        <input type="hidden" class="" name="maxprice" id="maxprice">
                        <div class="row_dv value_bar">
                            <ul class="value_list for_min" id='minpriceLi'>

                            </ul>

                            <ul class="value_list for_max maxAlign" id="maxpriceLi" style='display:none'>

                            </ul>

                        </div>

                    </div>


                </div>


                <div class="col-xs-12 col-sm-2">
                    <button type="button" id="HomePageSubmit" class="btn btn-primary btn-block search_btn"><i class="fa fa-search"></i> {!! Lang::get('common.search'); !!}</button>
                </div>

            </div>
            <div class="fieldset_block" id="filter_search_hide">
                <div class="col-xs-6 col-sm-3">


                    <input type="text" class="" name="suburb" id="suburb">


                </div>
                <div class="col-xs-6 col-sm-3">

                    <select class="select2menu" name="bedroom">
                        <option value="">{!! trans('common.bedroom') !!}</option>

                        @if(!empty($constantDataFile['beadroom']))
                        @foreach(Config::get('constants.beadroom') as $key=>$data)
                        <option   value="{{$key}}" >  {{$data}}</option>
                        @endforeach
                        @endif
                    </select>
                </div>
                <div class="col-xs-6 col-sm-3">


                    <select class="select2menu" name="bathroom">
                        <option value="">{!! trans('common.bathroom') !!}</option>

                        @if(!empty($constantDataFile['bathroom']))
                        @foreach(Config::get('constants.bathroom') as $key=>$data)
                        <option   value="{{$key}}" >  {{$data}}</option>
                        @endforeach
                        @endif
                    </select>

                </div>
                <div class="col-xs-6 col-sm-3" id="furnishedDiv">
                    <div class="row_dv checkbox checkbox-primary marg_left">
                        <input type="checkbox" name="furnished" id="furnished" value="1">
                        <label for="furnished" class="semibold" style="color:white">{!! trans('common.furnished') !!}</label>
                    </div>
                </div>

            </div>

            <div class="advanced-search-btn">
                <i class="fa fa-plus-square"></i> {!! Lang::get('common.advance_search'); !!}
            </div>
        </div>
    </div>
</form>

<script>
    $(document).ready(function () {
        
        
        /*-----------------------------
         Hide Budget if click on body
         ------------------------------*/
        $("#budgetDivMain").click(function (e) {
            e.stopPropagation();
        });

        $("#budget_dropdown").click(function (e) {
            e.stopPropagation();
        });

        $(document.body).on("click",function () {
            $("#budgetDivMain").hide();
        });

        /*-----end here-----------*/

        $('#HomePageSubmit').on('click', function (e) {
            var purpose = $("#type").val();
            var city = $("#city").val();
            var dynamicurl = '';

            if (city)
                dynamicurl += '/' + city;

            if (purpose == '0') {
                $("#propertyFilertForm").attr("action", "{!! URL::route('property.sell') !!}" + dynamicurl);
            }
            else
                $("#propertyFilertForm").attr("action", "{!! URL::route('property.rent') !!}" + dynamicurl)
            $("#city").removeAttr("name");
            $("#type").removeAttr("name");
            submitFormManual()

        });

        /*----------------------------
         Remove empty field 
         ---------------------------*/
        function submitFormManual() {
            //get name search form
            var SearchForm = $("#propertyFilertForm");
            SearchForm.find('input[name], select[name]').each(function () {
                if (!$(this).val()) {
                    $(this).removeAttr('name');
                }
            });
            //form submit
            $("#city").removeAttr("name");
            $("#type").removeAttr("name");
            SearchForm.submit();
        }

        $("#budget_dropdown").click(function () {
            $(".budget_search").slideToggle();
        });

        var protypedata = $("#type").val();
        var currency = ($.cookie('currency') == null) ? window.default_currency : $.cookie('currency');
          var currency_val = $.cookie('currency');
           
            if (protypedata == "1") {
                  if(currency_val == '$'){
                    var vardata = CreateLIArray(priceRentArray);
                   }
                   else{
                     var vardata = CreateLIArray(priceRentMZArray); 
                   }
            } else {
                 if(currency_val == '$'){
                    var vardata = CreateLIArray(priceArray);
                   }
                   else{
                     var vardata = CreateLIArray(priceMZArray);
                   }
            }

        $("#minpriceLi").html(vardata);
        $("#maxpriceLi").html(vardata);

        $("#maxpriceInput").on("click", function () {
            $(".budget_search").show();
            var $this = $(this);
            $("#arrowIdmax").show();
            $("#arrowIdmin").hide();
            $("#minpriceLi").hide();
            $("#maxpriceLi").show();
            if ($this.val()) {
                $("#maxprice").val($this.val());
                showDataPrice();
            }
            $this.val(($this.val()));
        })


        $("#maxpriceInput").on("change", function () {
            $(".budget_search").show();
            var $this = $(this);
            $("#arrowIdmax").show();
            $("#arrowIdmin").hide();
            $("#minpriceLi").hide();
            $("#maxpriceLi").show();
            if ($this.val()) {
                showDataPrice();
            }
            $this.val(($this.val()));
        })


        $("#minpriceInput").on("change", function () {
            $(".budget_search").show();
            var $this = $(this);
            $("#arrowIdmin").show();

            $("#arrowIdmax").hide();
            $("#maxpriceLi").hide();

            $("#minpriceLi").show();

            if ($this.val()) {
                $("#minprice").val($this.val())
                showDataPrice();
            }

            $this.val(($this.val()));

        })


        $("#minpriceInput").on("click", function () {
            $(".budget_search").show();
            var $this = $(this);
            $("#arrowIdmin").show();

            $("#arrowIdmax").hide();
            $("#maxpriceLi").hide();

            $("#minpriceLi").show();

            if ($this.val()) {
                // $("#minprice").val($this.val())
                showDataPrice();
            }

            $this.val(($this.val()));

        })


        $("#budgetDivMain").on("click", "#minpriceLi li,#maxpriceLi li", function () {

            var $this = $(this);
            $("#maxpriceLi li").removeClass("selected");
            $("#minpriceLi li").removeClass("selected");
            $(this).addClass("selected");
            var dataValue = "";
            var curId = $this.parent().attr("id");
            if (curId == "minpriceLi") {

                $("#minprice").val($this.attr("data-val"));
                $("#minpriceInput").val(nFormatter($this.attr("data-val")))
                $("#maxpriceInput").val("")
                $("#maxprice").val("")

                var protypedata = $("#type").val();
                  var currency_val = $.cookie('currency');
           
                if (protypedata == "1") {
                      if(currency_val == '$'){
                        var vardata = CreateLIArray(priceRentArray,1);
                       }
                       else{
                         var vardata = CreateLIArray(priceRentMZArray,1); 
                       }
                } else {
                     if(currency_val == '$'){
                        var vardata = CreateLIArray(priceArray,1);
                       }
                       else{
                         var vardata = CreateLIArray(priceMZArray,1);
                       }
                }
                $("#maxpriceLi").html("");
                $("#maxpriceLi").html(vardata);

                $("#arrowIdmax").show();

                $("#arrowIdmin").hide();
                $("#maxpriceLi").show();
                $("#minpriceLi").hide();


            }

            if (curId == "maxpriceLi") {

                $("#maxpriceInput").val(($this.attr("data-val")))
                $("#maxprice").val($this.attr("data-val"))
                $(".budget_search").hide();



            }
            showDataPrice();


        })

        function showDataPrice(minprice, maxprice) {
            var showData;
            var minprice = $("#minprice").val();
            var maxprice = $("#maxprice").val();
            if (maxprice && minprice) {
                showData = currency + ' ' + (minprice) + "-" + currency + ' ' + (maxprice);
            } else if (minprice) {
                showData = currency + ' ' + minprice + " - " + "Max";
            } else if (maxprice) {
                showData = "Min" + " - " + currency + ' ' + maxprice;
            } else {
                showData = "Budget";
            }
            $("#showValueData").text(showData);

        }


        /*---add value property type----*/
        $(".property_type_filetr").on("click", function () {


            $(".property_type_filetr").removeClass("active");
            $(this).addClass("active");
            var typedata = $(this).attr("data");
            $("#type").val(typedata);
            if (typedata == "1") {
                $("#furnished").prop("checked", false);
                $("#furnishedDiv").show();
            } else {
                $("#furnishedDiv").hide();
            }

        })



        /**********************Property city data******************************/
        Utility.select2utilityChar2("#city", window.baseurl + '/utility/homeautocomplete?enc=1', "{!! Lang::get('common.search_by_location_text'); !!}" ,'#type');

        /**********************Property type data******************************/
        Utility.select2utility("#property_type", window.baseurl + '/utility/propertytype', "{!! Lang::get('common.propertytype'); !!}");

        /**********************Property suburb data******************************/
        Utility.select2Labeldeputility("#suburb", window.baseurl + '/utility/suburb?enc=1', "{!! trans('common.select_suburb') !!}", "city");

        /*-------add other field--------*/
        $("#city").on("change", function () {

            try {
                var suburbid = $("#city").select2("data").suburb;
                var suburbname = $("#city").select2("data").suburb_name;
                if (suburbname && suburbid)
                    $("#suburb").select2("data", {id: suburbid, text: suburbname});

            } catch (e) {
                console.log("Error!!!!");
            }

        })


        $(".advanced-search-btn").on("click", function () {
            $(".advanced-search-btn i").toggleClass("fa-plus-square fa-minus-square")
            $("#filter_search_hide").slideToggle();
        })
        
        
        /*----changes price----*/
         $(".property_type_filetr").on("click", function () {
            //change price filter
            $("#maxpriceInput").val("")
            $("#minpriceInput").val("")
            $("#maxprice").val("")
            $("#minprice").val("")
            $(".budget_search").show();
            //end code here
            
            var protypedata = $("#type").val();
            var currency_val = $.cookie('currency');
           
            if (protypedata == "1") {
                  if(currency_val == '$'){
                    var vardata = CreateLIArray(priceRentArray);
                   }
                   else{
                     var vardata = CreateLIArray(priceRentMZArray); 
                   }
            } else {
                 if(currency_val == '$'){
                    var vardata = CreateLIArray(priceArray);
                   }
                   else{
                     var vardata = CreateLIArray(priceMZArray);
                   }
            }
            
            $("#minpriceLi").html(vardata);
            $("#maxpriceLi").html(vardata);
            $("#showValueData").text("Budget");
            
            $("#arrowIdmax").hide();

            $("#arrowIdmin").show();
            $("#maxpriceLi").hide();
            $("#minpriceLi").show();

        });
        
         $("#propertyFilertForm").on("select2-opening",function(){
             $("#budgetDivMain").hide();
         
      })

    })
</script>