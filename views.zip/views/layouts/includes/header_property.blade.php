<!-- header start -->
<?php $current_action = Route::currentRouteName(); ?>
<header id="header">
    <div class="container-fluid">
        <div class="row">
            <div class="col-sm-3 col-xs-4">
                <h1>
					<a href="{!! URL::to("/") !!}" class="logo"><img src="../front/images/logo.png" alt="logo" /></a>
					<a href="{!! URL::to("/") !!}" class="mb-logo"><img src="../front/images/mb-logo.png" alt="mb-logo" /></a>
				</h1>
            </div>
            <div class="col-sm-9 col-xs-8">
                <nav class="header-menu">
                    <ul class="nav-menu">
                        <li class="<?php echo $current_action =='property.index' || $current_action =='property.savealert' || $current_action =='market.index' ? 'active' : '' ?>"><a href="#">Buy<i class="fa fa-caret-down" aria-hidden="true"></i></a>
                            <ul class="submenu">
                                <li><a "><a href='{!! URL::route("property.index") !!}'>View All Homes</a></li>
                                <li><a href="{!! URL::route('market.index') !!}">Markets</a></li>
                                <li><a href="#">Existing Homes</a></li>
                                <li><a href="#">New Homes</a></li>
                            </ul>
                        </li>
                        <li class="<?php echo $current_action =='sell.index' ? 'active' : '' ?>"><a href="{!! URL::route('sell.index') !!}">Sell</a></li>
                        <!--li><a href="#">Buy</a></li>
                        <li><a href="#">Calender</a></li-->
                         <li class="<?php echo $current_action =='blogs.index' ? 'active' : '' ?>"><a href="{!! URL::route('blogs.index') !!}">Blog</a></li>
                        <li><a href="#">About Us<!--i class="fa fa-caret-down" aria-hidden="true"></i></a>
                            <ul class="submenu">
                                <li><a href="#">View All Auctions</a></li>
                                <li><a href="#">Markets</a></li>
                                <li><a href="#">Existing Homes</a></li>
                                <li><a href="#">New Homes</a></li>
                            </ul--></a>
                        </li>
                    </ul>
                    <div class="signUp">
                        @if (!Session::get('auth_user'))
                            <ul>
                                <li><a href="#" data-openbox="#login" class="popup-name"><i class="material-icons dp48">lock</i>Sign in</a></li>
                            </ul>

                        @else
                            <ul>
                            <li>
                                <a href="#">
                                    {{ Session::get('auth_user')['name'] }} 
                                    <i class="fa fa-caret-down" aria-hidden="true"></i>
                                </a>

                                <ul class="submenu">
                                
                                    <li><a href='{!! URL::route("users.getprofile") !!}'>Profile</a></li>
                                    
                                     
                                    <!--li><a href='{!! URL::route("users.index") !!}'>Dashboard</a></li-->
                                    
                                    <li><a href='{!! URL::route("home.logout") !!}'>Logout</a></li>
                                </ul>
                            </li> 
                            </ul>

                        @endif
						<a href="#" class="mb-menu-icon">
							<span></span>
							<span></span>
							<span></span>
						</a>
                    </div>
                </nav>  
            </div>
        </div>
    </div>
</header>
<!-- header end -->