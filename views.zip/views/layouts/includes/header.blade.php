<!-- header start -->
<?php $current_action = Route::currentRouteName(); ?>
<header id="header">
    <div class="container-fluid">
        <div class="row">
            <div class="col-sm-3 col-xs-4">
                 <h1>
                    
                    @if(isset($listing["admindetail"]["image"]) && $listing["admindetail"]["image"]!="")
                        <a href="{!! URL::to("/") !!}" class="logo admin-logo"><img src="{{ asset(Config::get('constantsUrl.apiurlmediaUrl').$listing['admindetail']['image']) }}" alt="logo" /></a>
                        <a href="{!! URL::to("/") !!}" class="mb-logo admin-logo"><img src="{{ asset(Config::get('constantsUrl.apiurlmediaUrl').$listing['admindetail']['image']) }}" alt="mb-logo" /></a> 
                    @elseif(isset($bidDetail["admindetail"]["image"]) && $bidDetail["admindetail"]["image"]!="")
                        <a href="{!! URL::to("/") !!}" class="logo admin-logo"><img src="{{ asset(Config::get('constantsUrl.apiurlmediaUrl').$bidDetail['admindetail']['image']) }}" alt="logo" /></a>
                        <a href="{!! URL::to("/") !!}" class="mb-logo admin-logo"><img src="{{ asset(Config::get('constantsUrl.apiurlmediaUrl').$bidDetail['admindetail']['image']) }}" alt="mb-logo" /></a>                         
                        
                    @else

					   <a href="{!! URL::to("/") !!}" class="logo"><img src="{{ asset('front/images/logo1.png') }}" alt="logo" /></a>
					   <a href="{!! URL::to("/") !!}" class="mb-logo"><img src="{{ asset('front/images/mb-logo.png') }}" alt="mb-logo" /></a>
                    @endif
				</h1>
            </div>
            <div class="col-sm-9 col-xs-8 static-posi">
                <nav class="header-menu">
                    <ul class="nav-menu">
                        <li class="<?php echo $current_action =='property.index' || $current_action =='property.savealert' || $current_action == 'market.index'? 'active' : '' ?>"><a href="#">Buy<i class="fa fa-caret-down" aria-hidden="true"></i></a>
                            <ul class="submenu">
                                <li><a href="{!! URL::route('property.index') !!}">View All Homes</a></li>
                                <li><a href="{!! URL::route('market.index') !!}">Markets</a></li>                                
                                <li><a href="{!! URL::route('property.newhome') !!}">New Homes</a></li>
                                <li><a href="{!! URL::route('property.existinghome') !!}">New Condos</a></li>
                            </ul>
                        </li>
                        <li class="<?php echo $current_action =='sell.index' ? 'active' : '' ?>"><a href="{!! URL::route('sell.index') !!}">Sell</a></li>
                        <!--li><a href="#">Buy</a></li>
                        <li><a href="#">Calender</a></li-->
                         <li class="<?php echo $current_action =='blogs.index'  || $current_action =='blogs.details'? 'active' : '' ?>"><a href="{!! URL::route('blogs.index') !!}">Blog</a></li>
                        <li class="<?php echo $current_action =='home.about' ? 'active' : '' ?>"><a href="{!! URL::route('home.about') !!}">About Us</a>
                        </li>
                        <!--li><a href="#">Bid<i class="fa fa-caret-down" aria-hidden="true"></i></a>
                            <ul class="submenu">
                                <li><a href="{!! URL::to('bid/register') !!}"> Registration</a></li>
                                <li><a href="{!! URL::to('auction') !!}">Live Auction</a></li>
                            </ul></a>
                        </li-->                        
                    </ul>
                    <div class="signUp">
                        @if (!Session::get('auth_user'))
                            <ul>
                                <li><a href="#" data-openbox="#login" class="popup-name"><i class="material-icons dp48">lock</i>Sign in</a></li>
                            </ul>

                        @else
                            <ul>
                            <li>
                                <a href="#">
                                    {{ Session::get('auth_user')['name'] }} 
                                    <i class="fa fa-caret-down" aria-hidden="true"></i>
                                </a>

                                <ul class="submenu">
                                
                                    <li><a href='{!! URL::route("users.getprofile") !!}'>Profile</a></li>
                                    
                                     
                                    <li><a href="{!! URL::route('users.userauction') !!}">My Bids</a></li>
                                    
                                    <li><a href='{!! URL::route("home.logout") !!}'>Logout</a></li>
                                </ul>
                            </li> 
                            </ul>

                        @endif
						<a href="#" class="mb-menu-icon">
							<span></span>
							<span></span>
							<span></span>
						</a>


                    </div>
                </nav>  
            </div>
        </div>
    </div>
</header>

<!-- header end -->