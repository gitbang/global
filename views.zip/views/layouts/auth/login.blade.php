<!-- popup start from here -->

<div class="popUpBox" id="login">
    <div class="modal-dialog popup-container">    
        <!-- Modal content-->
        <div class="popup-content">
            <div class="left-content">
                <h3>BidWorks</h3>
                <ul>
                    <li>BidWorks is an online bidding platform for buying and selling the best new homes and condos on the market.</li>
                    <li>Bid real-time, anywhere in the world on desktop or mobile device. Or bid onsite of the home being sold or absentee.</li>
                </ul>
            </div>
            <div class="right-content">
                <div class="form-heading">
                    <h5>LOGIN</h5>
                    <p>Enter Email and Password to Login.</p>
                </div>

                @if(Session::has('loginmsg'))
                    {!! Session::get('loginmsg') !!}
                @endif


                {!! Form::open(array('id'=>'form_login','route' => 'home.postlogin', 'method' => 'post')) !!}  
                    <div class="form-group">
                        <label class="common-lable-style">Email</label>
                        {!! Form::email('email',null,['id'=>'email','class'=>'form-control common-input-style']) !!}
                    </div>

                    <div class="form-group">
                        <label class="common-lable-style">Password</label>
                        
                        {!! Form::password('password',['id'=>'password','class'=>'form-control common-input-style'])!!}  
                    </div>
                    <input type="hidden" name="timezone" class="timezone" />
                    <input type="hidden" name="timezone_name" class="timezone_name" />
                    
                    <div class="form-group creat-new-acc">
                        <a href="#" data-openbox="#register" class="popup-name">Create new account</a>
                    </div>
                    <div class="form-group btn-block">
                        <button>SIGN IN</button>
                         
                        <a href="#" data-openbox="#forgot" class="popup-name">Forgot Password</a>
                    </div>
                </form>
            </div>
            <button type="button" class="close-popup" data-closebox=".popUpBox">&times;</button>
        </div>   
        
    </div>
</div>

