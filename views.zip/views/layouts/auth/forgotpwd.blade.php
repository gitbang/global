
<!-- popup start from here -->

<div class="popUpBox" id="forgot" role="dialog">
    <div class="modal-dialog popup-container">    
        <!-- Modal content-->
        <div class="popup-content">
            <div class="left-content">
                <h3>BidWorks</h3>
                <ul>
                    <li>BidWorks is an online bidding platform for buying and selling the best new homes and condos on the market.</li>
                    <li>Bid real-time, anywhere in the world on desktop or mobile device. Or bid onsite of the home being sold or absentee.</li>
                </ul>
            </div>
            <div class="right-content">
                <div class="form-heading">
                    <h5>Forget Password</h5>
                    <p>Enter your registered email address and Get Link in your inbox</p>
                </div>
                
                @if(Session::has('forgetmsg'))
                    {!! Session::get('forgetmsg') !!}
                @endif
                

                {!! Form::open(array('id'=>'form_forgot','route' => 'home.postforget', 'method' => 'post')) !!}  


                    <div class="form-group">
                        <label class="common-lable-style">Email</label>
                        {!! Form::email('email',null,['id'=>'email','class'=>'form-control common-input-style']) !!}
                    </div>
                 

                    <div class="form-group btn-block">
                        <button>Submit</button>
                         
                        
                    </div>
                </form>
            </div>
            <button type="button"  class="close-popup" data-closebox=".popUpBox">&times;</button>
        </div>   
        
    </div>
</div>

