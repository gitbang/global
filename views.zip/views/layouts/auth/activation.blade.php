<div class="popUpBox" id="activation" role="dialog">
    <div class="modal-dialog popup-container" style="max-width: 600px;">    
        <!-- Modal content-->
        <div class="popup-content" style="min-height: initial;">
            <div class="right-content">               
                <div class="row">
                    <div class="col-xs-12 col-sm-12">
                        @if(Session::has('authmsgact'))
                           {!! Session::get('authmsgact') !!}
                        @endif
                    </div>
                </div>
                {!! Form::open(array('id'=>'form_activation')) !!}
                    <div class="form-group btn-block">
                        <a href="#" data-openbox="#login" class="activation-btn popup-name">SIGN IN</a>   
                    </div>
                </form>
            </div>
            <button type="button"  class="close-popup" data-closebox=".popUpBox">&times;</button>
        </div>  
    </div>
</div>

