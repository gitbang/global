<!-- popup start from here -->

<div class="popUpBox" id="register">
    <div class="modal-dialog popup-container">    
        <!-- Modal content-->
        <div class="popup-content">
            <!--div class="left-content">
                <h3>BidWorks</h3>
                <ul>
                    <li>BidWorks is a home auction marketplace for non-distressed, mainstream real estate.</li>
                    <li>Bid real- time, anywhere in the world from your desktop or mobile device via the BidWorks app, or participate in-person at the BidWorks-sponsored live auction event</li>
                </ul>
            </div-->
            <div class="right-content auto-width-div">
                <div class="form-heading">
                    <h5>Sign Up</h5>
                    <p>Sign Up, It's Free</p>
                </div>

                @if(Session::has('registermsg'))
                    {!! Session::get('registermsg') !!}
                @endif

                {!! Form::open(array('id'=>'register_form','route' => 'home.saveregister', 'method' => 'post')) !!}  
                    
                 
                <div class="form-group">

                    <label class="radio-inline">
                      <input type="radio" class="usertype" {{ (Input::old('profile_type')=='')?"checked":"" }} name="profile_type" value="4">Homebuilder 
                    </label>

                    <label class="radio-inline">
                      <input type="radio" class="usertype" {{ (Input::old('profile_type')=='3')?"checked":"" }} name="profile_type" value="3">Agent
                    </label> 

                    <label class="radio-inline">
                      <input type="radio" value="1" {{ (Input::old('profile_type')=='1')?"checked":"" }} name="profile_type">Buyer
                    </label>
                    <label class="radio-inline">
                      <input type="radio" value="2" {{ (Input::old('profile_type')=='2')?"checked":"" }} name="profile_type">Seller
                    </label>
                    <label class="radio-inline">
                      <input type="radio" value="5" {{ (Input::old('profile_type')=='5')?"checked":"" }} name="profile_type">Interested Consumer
                    </label>

                </div>
      


                
                    <div class="form-group homebuilder {{ (Input::old('profile_type')=='4' || Input::old('profile_type')=='')?'':'hide' }}">
                        <label class="common-lable-style">Homebuilder Name</label>
                        {!! Form::text('client_name',null,['id'=>'client_name','class'=>'form-control common-input-style']) !!}
                    </div>
                

                
                    <div class="form-group agent {{ (Input::old('profile_type')!='3')?'hide':'' }}">
                        <label class="common-lable-style">Brokerage name</label>
                        {!! Form::text('brokerage_name',null,['id'=>'brokerage_name','class'=>'form-control common-input-style']) !!}
                    </div>
               
               
                    <div class="form-group agent {{ (Input::get('profile_type')!='3')?'hide':'' }}">
                        <label class="common-lable-style">Agent License number</label>
                        {!! Form::text('agent_license',null,['id'=>'agent_license','class'=>'form-control common-input-style']) !!}
                    </div>
                                                        
                    

                    <div class="form-group">
                        <label class="common-lable-style">First Name</label>
                        {!! Form::text('first_name',null,['id'=>'first_name','class'=>'form-control common-input-style']) !!}
                    </div>

                    <div class="form-group">
                        <label class="common-lable-style">Last Name</label>
                        {!! Form::text('last_name',null,['id'=>'last_name','class'=>'form-control common-input-style']) !!}
                    </div>

                    <div class="form-group">
                        <label class="common-lable-style">Email</label>
                        {!! Form::email('email',null,['id'=>'email','class'=>'form-control common-input-style']) !!}
                    </div>
                    <div class="form-group">
                        <label class="common-lable-style">Password</label>
                        
                        {!! Form::password('password',['id'=>'password','class'=>'form-control common-input-style'])!!}  
                    </div>

                    <div class="form-group">
                        <label class="common-lable-style">Confirm Password</label>
                        
                        {!! Form::password('confirm_password',['id'=>'confirm_password','class'=>'form-control common-input-style'])!!}  
                    </div>                    

                    <div class="form-group btn-block">
                        <button>REGISTER</button>
                         
                        
                    </div>
                </form>
            </div>
            <button type="button" class="close-popup" data-closebox=".popUpBox">&times;</button>
        </div>   
        
    </div>
</div>

<script>
    
$("input:radio[name=profile_type]").click(function() {
    var value = $(this).val();
    if(value == "4"){
        $(".homebuilder").removeClass("hide")
        $(".agent").addClass("hide")
    }
    else if(value == "3"){
        $(".homebuilder").addClass("hide")
        $(".agent").removeClass("hide")
    }else{
        $(".homebuilder").addClass("hide")
        $(".agent").addClass("hide")        
    }
});    
</script>