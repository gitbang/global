<!-- popup start from here -->

<div class="popUpBox" id="reset" role="dialog">
    <div class="modal-dialog popup-container">    
        <!-- Modal content-->
        <div class="popup-content">
            <div class="left-content">
                <h3>BidWorks</h3>
                <ul>
                    <li>BidWorks is an online bidding platform for buying and selling the best new homes and condos on the market.</li>
                    <li>Bid real-time, anywhere in the world on desktop or mobile device. Or bid onsite of the home being sold or absentee.</li>
                </ul>
            </div>
            <div class="right-content">
                <div class="form-heading">
                    <h5>Reset Password</h5>
                    <!--p>Lorem ipsum dolor sit amet, consectetur adipiscing elit.</p-->
                </div>

                        @if(Session::has('resetmsg'))
                            {!! Session::get('resetmsg') !!}
                        @endif

                        @if(Session::get('showForm'))
                            {!! Form::open(array('id'=>'form_reset','route' => 'home.reset', 'method' => 'post')) !!}  
                            
                            <div class="form-group">
                                <label class="common-lable-style">Password</label>
                                {!! Form::password('password',['id'=>'password','class'=>'form-control common-input-style'])!!} 
                            </div>  
                            
                            <div class="form-group">
                                <label class="common-lable-style">Confirm Password</label>
                                {!! Form::password('c_password',['id'=>'c_password','class'=>'form-control common-input-style'])!!} 
                            </div>  

                            <div class="form-group btn-block">
                                <button>Submit</button>
                                                                 
                            </div>

                            {!! Form::close() !!}
                            {!! Session::forget('showForm') !!} 
                        @endif
            </div>
            <button type="button" class="close-popup" data-closebox=".popUpBox">&times;</button>
        </div>   
        
    </div>
</div>


<!---add login javascript ---->
