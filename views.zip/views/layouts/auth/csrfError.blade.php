<div class="modal fade" id="csrfError" tabindex="-1" role="dialog" aria-labelledby="myModalLabel">
            <div class="modal-dialog move_popup" role="document">
                <div class="modal-content">

                    <div class="modal-header">
                        <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
                       <h4 id="Labelcsrf" class="modal-title">Error !!!</h4>
                    </div>

                    <div class="modal-body">
                        <div class="row">
                            <div class="col-xs-12 col-sm-12">

                                <div class="alertVis alert-danger" id="error_msg"> @if(Session::has('csrfError'))
                                   {!! Session::get('csrfError') !!}
                                @endif
                                
                                
                                </div>
                               
                            </div>
                        </div>
                    </div>
                        
                    </div>

                </div>
            </div>
        </div>