<!DOCTYPE html>
<html lang="en">
    @include('layouts.includes.head')
    
   
<style>
    .error{
        color : red;
        font-size : 12px;
    }
</style>
<body>
<div id="sb-site" class="wrapper">
     @include('layouts.includes.header')
	 <div class="body-content header-margin">
		<div class="profile1-page">
            <aside class="left-side-bar">
                <h2>Propbidder</h2>
                <div class="list-section">
                <?php $current_action = Route::currentRouteName(); ?>
                    <ul>
                        <li class="" ><a class="prof list <?php echo ($current_action =='users.getprofile' || $current_action =='users.changePwd') ? 'active' : '' ?>" href="{{ URL::route('users.getprofile') }}">Profile</a></li>
                        <!--li><a class="fav list" href="javascript:void(0)">Favourites</a></li-->
                        <li><a class="fav list <?php echo ($current_action =='users.userauction') ? 'active' : '' ?>" href="{{ URL::route('users.userauction') }}">My Bids</a></li>                        

                        <li><a class="emalert list <?php echo ($current_action =='users.alertinfo') ? 'active' : '' ?>" href="{{ URL::route('users.alertinfo') }}">Email Alert</a></li>
                    </ul>
                </div>
            </aside>
            <section class="profile-right-section">     
                @yield('content')
            </section>    
		</div>
	</div>

</div>
 @include('layouts.includes.footer') 

<div class="overlay"></div>

<script src="http://ajax.googleapis.com/ajax/libs/jquery/1.10.2/jquery.min.js"></script>
<script src="{{ asset('front/js/bootstrap.min.js') }}"></script>
<script src="{{ asset('front/js/jquery.validate.js') }}"></script>
<script src="{{ asset('common/jquery.blockUI.js') }}"></script>
<script src="{{ asset('common/jqueryvalidation.js') }}"></script>
<script src="{{ asset('front/js/animation.js') }}"></script>
<script src="{{ asset('front/js/custom.js') }}"></script>
<script src="{{ asset('front/js/jquery-ui.js') }}"></script>
<script src="{{ asset('front/js/moment.min.js') }}"></script>
{!! HTML::script('front/js/jstz-1.0.4.min.js'); !!}
<script>
    var baseurl = "{!! URL::to('/') !!}";
</script>
@yield('scriptinclude')
     
   
        
<script>
    $(document).ready(function () {
        <?php if (Session::has('name')) : ?>
                CustomModal.openmodal("{!! Session::get('name') !!}");  
            <?php Session::forget('name');
        elseif (isset($name)):
            ?>
            CustomModal.openmodal('{!! $name !!}');   
        <?php endif; ?>
                    
    })
</script>
      

