<!DOCTYPE html>
<html lang="en">
    @include('layouts.includes.head')
    
   

<body>
<div id="sb-site" class="wrapper">
     @include('layouts.includes.header')
    
	<div class="body-content header-margin">
		@yield('content')
	</div>
    <!-- Footer start -->
    @include('layouts.includes.footer')            
    <!-- Footer end -->
	<div class="overlay"></div>
</div>




<script src="http://ajax.googleapis.com/ajax/libs/jquery/1.10.2/jquery.min.js"></script>
<script src="{{ asset('front/js/bootstrap.min.js') }}"></script>
<script src="{{ asset('front/js/jquery.validate.js') }}"></script>
<script src="{{ asset('common/jquery.blockUI.js') }}"></script>
<script src="{{ asset('front/js/slick.min.js') }}"></script>
<script src="{{ asset('common/jqueryvalidation.js') }}"></script>
<script src="{{ asset('front/js/animation.js') }}"></script>
<script src="{{ asset('front/js/custom.js') }}"></script>
<script src="{{ asset('front/js/moment.min.js') }}"></script>
{!! HTML::script('front/js/jstz-1.0.4.min.js'); !!}
@yield('scriptinclude')
</body> 
</html>   



           

            

       
        <!-- wapper end -->
        @if (!Session::get('auth_user'))    
        <!-- Register Popup -->
        @include('layouts.auth.register')          
        <!-- Register Popup -->

        <!-- Login Popup -->
        @include('layouts.auth.login')        
        <!-- Login Popup -->

        <!-- Change Password Popup -->
        @include('layouts.auth.forgotpwd')
        <!-- Change Password Popup -->

        <!---check activation page-->
        @if(Session::has('activation_page'))
        @include('layouts.auth.activation')

        @endif

        <!---check Password reset page-->
        @if(Session::has('reset_page'))
        @include('layouts.auth.resetpwd')
        {!! Session::forget('reset_page') !!} 
        @endif
        
   
        <script>
            $(document).ready(function () {
                <?php if (Session::has('name')) : ?>
                        CustomModal.openmodal("{!! Session::get('name') !!}");  
                    <?php Session::forget('name');
                elseif (isset($name)):
                    ?>
                    CustomModal.openmodal('{!! $name !!}');   
                <?php endif; ?>
                            
            })
        </script>
      
        <script src="{{ asset('front/js/authvalidation/authvalidation.js') }}"></script>
        @endif
        

    </body>
</html>
