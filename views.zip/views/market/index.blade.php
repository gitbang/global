@extends('layouts.inner_property',["footer"=>true])
@section('title', trans('seocontent.sell_title'))
@section('meta_title', trans('seocontent.sell_meta_title'))
@section('meta_description', trans('seocontent.sell_desc'))
@section('content')        

<section class="banner">
	<div class="market-page-banner">                                
		<figure>
			<img src="../front/images/market-page-banner.jpg" alt="" />
		</figure>
		<div class="banner-content">
			<div class="container">
				<h2 class="animated" data-animation="appeared fadeInUp" data-animation-delay="100">Propbidder operates in the best markets <span class="animated" data-animation="appeared fadeInUp" data-animation-delay="300"> throughout California</span></h2>
			</div>
		</div>              
	</div>
</section>
<section class="best-bidwrok-area">
	<div class="inner-container">
		<h3 class="animated" data-animation="appeared fadeInUp" data-animation-delay="100">Get to know some of <span>Propbidder</span> best suburbs and areas.<br/>
Browse. Find. Explore.</h3>
		<div class="row">
			<div class="col-sm-6 col-xs-12">
				<div class="area-block">
					<figure>
						<img src="../front/images/best-area-img1.jpg" alt="" />
						<figcaption><span class="animated" data-animation="appeared fadeInDown" data-animation-delay="200">SAN</span> <span class="animated" data-animation="appeared fadeInUp" data-animation-delay="200">FRANCISCO</span></figcaption>
					</figure>                           
					<a href="{{ URL::to('/property') }}?city=San Francisco"></a>
				</div>
			</div>
			<div class="col-sm-6 col-xs-12">
				<div class="area-block">
					<figure>
						<img src="../front/images/best-area-img2.jpg" alt="" />
						<figcaption><span class="animated" data-animation="appeared fadeInDown" data-animation-delay="300">LOS</span><span class="animated" data-animation="appeared fadeInUp" data-animation-delay="300">ANGELES</span></figcaption>
					</figure>                           
					<a href="{{ URL::to('/property') }}?city=Los Angeles"></a>
				</div>
			</div>
			<div class="col-sm-6 col-xs-12">
				<div class="area-block">
					<figure>
						<img src="../front/images/best-area-img3.jpg" alt="" />
						<figcaption><span class="animated" data-animation="appeared fadeInDown" data-animation-delay="400">SILICON</span> <span class="animated" data-animation="appeared fadeInUp" data-animation-delay="400">VALLEY</span></figcaption>
					</figure>                           
					<a href="{{ URL::to('/property') }}?city=Silicon Valley"></a>
				</div>
			</div>
			<div class="col-sm-6 col-xs-12">
				<div class="area-block">
					<figure>
						<img src="../front/images/best-area-img4.jpg" alt="" />
						<figcaption><span class="animated" data-animation="appeared fadeInDown" data-animation-delay="500">ORANGE</span><span class="animated" data-animation="appeared fadeInUp" data-animation-delay="500"> COUNTY</span></figcaption>
					</figure>                           
					<a href="{{ URL::to('/property') }}?city=Orange County"></a>
				</div>
			</div>
		</div>
	</div>
</section>
@stop