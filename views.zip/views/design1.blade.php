<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="utf-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=0">
        <!-- The above 3 meta tags *must* come first in the head; any other head content must come *after* these tags -->
        <title>Propbidder</title>
		<!-- font libray -->
		<link href="https://fonts.googleapis.com/css?family=Lato:300,400,700" rel="stylesheet">
		<link href="https://fonts.googleapis.com/css?family=Raleway:300,400,700" rel="stylesheet">
		
		<!-- css files -->
		<link rel="stylesheet" type="text/css" href="http://maxcdn.bootstrapcdn.com/font-awesome/4.5.0/css/font-awesome.min.css">
		<link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet" type="text/css" />
		<link rel="stylesheet" type="text/css" href="../front/css/style.css" />
		
		<!-- HTML5 Shim and Respond.js IE8 support of HTML5 elements and media queries -->
		<!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
		<!--about-us.html-->

		<!--[if lt IE 9]>
		<script src="https://oss.maxcdn.com/html5shiv/3.7.2/html5shiv.min.js"></script>
		<script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
		<![endif]-->
    </head>
<body>
<div class="wrapper">
	<!-- header start -->
	<header id="header" class="head-fixed">
		<div class="container-fluid">
			<div class="row">
				<div class="col-sm-3 col-xs-6">
					<h1><a href="#" class="logo"><img src="../front/images/logo.png" alt="logo" /></a></h1>
				</div>
				<div class="col-sm-9 col-xs-6">
					<nav class="header-menu">
						<ul class="nav-menu">
							<li><a href="#" class="active">Auctions<i class="fa fa-caret-down" aria-hidden="true"></i></a>
								<ul class="submenu">
									<li><a href="#">View All Auctions</a></li>
									<li><a href="#">Markets</a></li>
									<li><a href="#">Existing Homes</a></li>
									<li><a href="#">New Homes</a></li>
								</ul>
							</li>
							<li><a href="#">Sell</a></li>
							<li><a href="#">Buy</a></li>
							<li><a href="#">Calender</a></li>
							<li><a href="#">Blog</a></li>
							<li><a href="#">About Us<i class="fa fa-caret-down" aria-hidden="true"></i></a>
								<ul class="submenu">
									<li><a href="#">View All Auctions</a></li>
									<li><a href="#">Markets</a></li>
									<li><a href="#">Existing Homes</a></li>
									<li><a href="#">New Homes</a></li>
								</ul>
							</li>
						</ul>
						<div class="signUp">
							<ul>
								<li><a href="#" data-toggle="modal" data-target="#myModal"><i class="material-icons dp48">lock</i>Sign in</a></li>
							</ul>
						</div>
					</nav>	
				</div>
			</div>
		</div>
	</header>
	<!-- header end -->
	<!-- start map page here -->
	<div class="map-page">
		<div class="container-fluid">
			<div class="row">
				<div class="col-md-5">
					<div class="map-section">
						<div class="map">
							<iframe src="https://www.google.com/maps/embed?pb=!1m14!1m8!1m3!1d14024.586629780526!2d77.0850959!3d28.505235!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x0%3A0x12e71803eb09ac16!2sClavax+Technologies!5e0!3m2!1sen!2sin!4v1495633155495" width="100%" height="800" frameborder="0" style="border:0" allowfullscreen></iframe>
							<div class="map-btn">
								<div>
									<a href="javascript:void(0)">My Location</a>
									<a href="javascript:void(0)">Full Screen</a>
								</div>
							</div>
						</div>
					</div>
						
				</div>
				<div class="col-md-7">
					<div class="row">
						<section class="form-section fullWidth">
							<form>
								<div class="form-row1 fullWidth">
									<div class="col-md-6 col-sm-6 col-xs-12">
										<div class="">
											<input type="text" class="form-control common-input-style" placeholder="Enter Keyword">
										</div>
									</div>
									<div class="col-md-6 col-sm-6 col-xs-12">
										<div class="">
											<input type="text" class="form-control common-input-style" placeholder="Location">
										</div>
									</div>
									<div class="col-md-4 col-sm-6 col-xs-12">
										<div class="form-group selectbox-wrapper">
											<select class="form-control common-input-style">
												<option>All Status</option>
												<option>Option 1</option>
												<option>Option 2</option>
												<option>Option 3</option>
											</select>
										</div>
									</div>
									<div class="col-md-4 col-sm-6 col-xs-12">
										<div class="form-group selectbox-wrapper">
											<select class="form-control common-input-style">
												<option>All Types</option>
												<option>Option 1</option>
												<option>Option 2</option>
												<option>Option 3</option>
											</select>
										</div>
									</div>
									<div class="col-md-4 col-sm-6 col-xs-12">
										<div class="form-group selectbox-wrapper">
											<select class="form-control common-input-style">
												<option>Bedrooms</option>
												<option>Option 1</option>
												<option>Option 2</option>
												<option>Option 3</option>
											</select>
										</div>
									</div>
									<div class="col-md-4 col-sm-6 col-xs-12">
										<div class="form-group selectbox-wrapper">
											<select class="form-control common-input-style">
												<option>Min Area</option>
												<option>Option 1</option>
												<option>Option 2</option>
												<option>Option 3</option>
											</select>
										</div>
									</div>
									<div class="col-md-4 col-sm-6 col-xs-12">
										<div class="form-group selectbox-wrapper">
											<select class="form-control common-input-style">
												<option>Max Area</option>
												<option>Option 1</option>
												<option>Option 2</option>
												<option>Option 3</option>
											</select>
										</div>
									</div>
									<div class="col-md-4 col-sm-6 col-xs-12">
										<div class="form-group rangeSlider fullWidth">
											<label>Price</label>
											<input type="range" min="10" max="100">
											<div class="price-range">
												<div class="range-start">$1,554</div>
												<div class="range-end">$6,665,465</div>
											</div>
										</div>
									</div>
								</div>
								<div class="form-row2 fullWidth">
									<div class="">
										<button type="button" value="save" class="save-btn">SAVE</button>
										<button type="button" value="save" class="form-control update-btn" data-text="UPDATE">UPDATE</button>
									</div>
								</div>
							</form>
						</section>
						<section class="property-block fullWidth">
							<div class="col-sm-6 col-xs-12">
								<div class="property-desc">
									<div class="property-image">
										<figure><img src="../front/images/map-building1.jpg" alt="img" /></figure>
										<div class="building-price">$1,250,000</div>
										<div class="section-overlay"></div>

									</div>
									<div class="propetry-feature">
										<span>Belvedere - 4 Beds, 4.5 Baths</span>
										<span>Villages of Irvine (Irvine Pacific)</span>
									</div>
									<div class="property-loc">
										Irvin, CA
									</div>
									<div class="bid-info">
										<div class="property-opening-bid">
										             Est. Opening Bid: $1,100,000
										</div>
										<div class="property-bid-date"><span><i class="fa fa-calendar"></i></span>3rd July</div>
									</div>
									
								</div>
							</div>
							<div class="col-sm-6 col-xs-12">
								<div class="property-desc">
									<div class="property-image">
										<figure><img src="../front/images/map-building1.jpg" alt="img" /></figure>
										<div class="building-price">$1,250,000</div>
										<div class="section-overlay"></div>
									</div>
									<div class="propetry-feature">
										<span>Belvedere - 4 Beds, 4.5 Baths</span>
										<span>Villages of Irvine (Irvine Pacific)</span>
									</div>
									<div class="property-loc">
										Irvin, CA
									</div>
									<div class="bid-info">
										<div class="property-opening-bid">
										             Est. Opening Bid: $1,100,000
										</div>
										<div class="property-bid-date"><span><i class="fa fa-calendar"></i></span>3rd July</div>
									</div>
									
								</div>
							</div>
							<div class="col-sm-6 col-xs-12">
								<div class="property-desc">
									<div class="property-image">
										<figure><img src="../front/images/map-building1.jpg" alt="img" /></figure>
										<div class="building-price">$1,250,000</div>
										<div class="section-overlay"></div>
									</div>
									<div class="propetry-feature">
										<span>Belvedere - 4 Beds, 4.5 Baths</span>
										<span>Villages of Irvine (Irvine Pacific)</span>
									</div>
									<div class="property-loc">
										Irvin, CA
									</div>
									<div class="bid-info">
										<div class="property-opening-bid">
										             Est. Opening Bid: $1,100,000
										</div>
										<div class="property-bid-date"><span><i class="fa fa-calendar"></i></span>3rd July</div>
									</div>
									
								</div>
							</div>
							<div class="col-sm-6 col-xs-12">
								<div class="property-desc">
									<div class="property-image">
										<figure><img src="../front/images/map-building1.jpg" alt="img" /></figure>
										<div class="building-price">$1,250,000</div>
										<div class="section-overlay"></div>
									</div>
									<div class="propetry-feature">
										<span>Belvedere - 4 Beds, 4.5 Baths</span>
										<span>Villages of Irvine (Irvine Pacific)</span>
									</div>
									<div class="property-loc">
										Irvin, CA
									</div>
									<div class="bid-info">
										<div class="property-opening-bid">
										             Est. Opening Bid: $1,100,000
										</div>
										<div class="property-bid-date"><span><i class="fa fa-calendar"></i></span>3rd July</div>
									</div>
									
								</div>
							</div>
							<div class="col-sm-6 col-xs-12">
								<div class="property-desc">
									<div class="property-image">
										<figure><img src="../front/images/map-building1.jpg" alt="img" /></figure>
										<div class="building-price">$1,250,000</div>
										<div class="section-overlay"></div>
									</div>
									<div class="propetry-feature">
										<span>Belvedere - 4 Beds, 4.5 Baths</span>
										<span>Villages of Irvine (Irvine Pacific)</span>
									</div>
									<div class="property-loc">
										Irvin, CA
									</div>
									<div class="bid-info">
										<div class="property-opening-bid">
										             Est. Opening Bid: $1,100,000
										</div>
										<div class="property-bid-date"><span><i class="fa fa-calendar"></i></span>3rd July</div>
									</div>
									
								</div>
							</div>

						</section>


					</div>
				</div>
			</div>
		</div>
	</div>

	<!-- end map page here -->

</div>





<script src="http://ajax.googleapis.com/ajax/libs/jquery/1.10.2/jquery.min.js"></script>
<script src="../front/js/bootstrap.min.js"></script>
<script src="../front/js/slick.min.js"></script>
<script src="../front/js/custom.js"></script>
<script>
	$('.home-page-slider').slick({
		dots: true,
		infinite: true,
		speed: 500,
		fade: true,
		autoplay: true,
		cssEase: 'linear'
	});
</script>
</body> 
</html>   
