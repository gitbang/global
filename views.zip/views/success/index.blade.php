<?php
/* * *****************************************************
  Success message
  @Author Anil Yadav
  Created Date 5-8-2016 12:17
 * ***************************************************** */
?>
@extends('layouts.inner')
@section('title'){{trans("common.success_message")}}@stop
@section('content')
<link href="{{ asset('front/css/404css.css') }}" rel="stylesheet">

<style>
    .mid-content.after_login{padding-bottom:0;}
    .thanks_pg h2,
    .thanks_pg h3{color:#fff;}
</style>

<!-- List property step-1 page start -->
<div class="container_full background-image_success" id="successmessage">
  <div class="overlay container">

    <div class="center_block text-center thanks_pg">

        <div class="logo fadeInUp animated">
        <!-- <img alt="Launchify Brand Logo" src="{{ asset('front/images/logo_404.png') }}"> -->
        
        </div>
        <h3>{!! Lang::get('common.success_message_head'); !!}</h3>
        <p>{!! Lang::get('common.success_message_message'); !!}</p>
        
        <h4><span><a href="{{ URL::previous() }}"  class="continue_web">{!! Lang::get('common.continue_to_website'); !!}</a></span> </h4>
      </div>

    </div><!-- overlay end -->
</div>



<script type="text/javascript">
function handleResize() {
var h = $(window).height();
        $('.container_full').css({'height':h+'px'});
}
$(function(){
        handleResize();

        $(window).resize(function(){
        handleResize();
    });
});
</script>


@endsection
