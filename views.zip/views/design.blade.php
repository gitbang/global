<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="utf-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=0">
        <!-- The above 3 meta tags *must* come first in the head; any other head content must come *after* these tags -->
        <title>Propbidder</title>
		<!-- font libray -->
		<link href="https://fonts.googleapis.com/css?family=Lato:300,400,700" rel="stylesheet">
		<link href="https://fonts.googleapis.com/css?family=Raleway:300,400,600,700" rel="stylesheet">
		
		<!-- css files -->
		<link rel="stylesheet" type="text/css" href="http://maxcdn.bootstrapcdn.com/font-awesome/4.5.0/css/font-awesome.min.css">

		<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/fancybox/3.0.47/jquery.fancybox.min.css" />

		<link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet" type="text/css" />
		<link rel="stylesheet" type="text/css" href="../front/css/style.css" />
		
		<!-- HTML5 Shim and Respond.js IE8 support of HTML5 elements and media queries -->
		<!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
		<!--about-us.html-->

		<!--[if lt IE 9]>
		<script src="https://oss.maxcdn.com/html5shiv/3.7.2/html5shiv.min.js"></script>
		<script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
		<![endif]-->
    </head>
<body>
<div class="wrapper">
	<!-- header start -->
	<header id="header">
		<div class="container-fluid">
			<div class="row">
				<div class="col-sm-3 col-xs-5">
					<h1>
						<a href="#" class="logo"><img src="../front/images/logo.png" alt="logo" /></a>
						<a href="#" class="mb-logo"><img src="../front/images/mb-logo.png" alt="mb-logo" /></a>
					</h1>
				</div>
				<div class="col-sm-9 col-xs-7">
					<nav class="header-menu">
						
						<ul class="nav-menu">
							<li class="active"><a href="#">Auctions<i class="fa fa-caret-down" aria-hidden="true"></i></a>
								<ul class="submenu">
									<li><a href="#">View All Auctions</a></li>
									<li><a href="#">Markets</a></li>
									<li><a href="#">Existing Homes</a></li>
									<li><a href="#">New Homes</a><ul class="submenu">
									<li><a href="#">View All Auctions</a></li>
									<li><a href="#">Markets</a></li>
									<li><a href="#">Existing Homes</a></li>
									<li><a href="#">New Homes</a></li>
								</ul></li>
								</ul>
							</li>
							<li><a href="#">Sell</a></li>
							<li><a href="#">Buy</a></li>
							<li><a href="#">Calender</a></li>
							<li><a href="#">Blog</a></li>
							<li><a href="#">About Us<i class="fa fa-caret-down" aria-hidden="true"></i></a>
								<ul class="submenu">
									<li><a href="#">View All Auctions</a></li>
									<li><a href="#">Markets</a></li>
									<li><a href="#">Existing Homes</a></li>
									<li><a href="#">New Homes</a></li>
								</ul>
							</li>
						</ul>
						<div class="signUp">
							<ul>
								<li><a href="#" data-toggle="modal" data-target="#myModal"><i class="material-icons dp48">lock</i>Sign in</a>
									<ul class="submenu">
										<li><a href="#">View All Auctions</a></li>
										<li><a href="#">Markets</a></li>
										<li><a href="#">Existing Homes</a></li>
										<li><a href="#">New Homes</a></li>
									</ul>
								</li>
							</ul>
							<a href="#" class="mb-menu-icon">
								<span></span>
								<span></span>
								<span></span>
							</a>
						</div>
					</nav>	
				</div>
			</div>
		</div>
	</header>
	<!-- header end -->
	<div class="body-content">
		<!-- banner slider start -->
		<!--<section class="banner">
			<div class="home-page-slider">
				<div>
					<div class="slide-item">					
						<figure>
							<img src="../front/images/home-slide1.jpg" alt="logo" />
						</figure>
						<div class="banner-content">
							<div class="container">
								<h2>Home Auctions</h2>
								<h3><span>For Mainstream</span> REAL ESTATE</h3>
								<a href="#" data-text="View Auctions" class="btn">View Auctions</a>
							</div>
						</div>
					</div>
				</div>
				<div>
					<div class="slide-item">					
						<figure>
							<img src="../front/images/home-slide2.jpg" alt="logo" />
						</figure>
						<div class="banner-content">
							<div class="container">
								<h2>Home Auctions</h2>
								<h3><span>For Mainstream</span> REAL ESTATE</h3>
								<a href="#" data-text="View Auctions" class="btn">View Auctions</a>
							</div>
						</div>
					</div>
				</div>
				<div>
					<div class="slide-item">					
						<figure>
							<img src="../front/images/home-slide1.jpg" alt="logo" />
						</figure>
						<div class="banner-content">
							<div class="container">
								<h2>Home Auctions</h2>
								<h3><span>For Mainstream</span> REAL ESTATE</h3>
								<a href="#" data-text="View Auctions" class="btn">View Auctions</a>
							</div>
						</div>
					</div>
				</div>
				<div>
					<div class="slide-item">					
						<figure>
							<img src="../front/images/home-slide2.jpg" alt="logo" />
						</figure>
						<div class="banner-content">
							<div class="container">
								<h2>Home Auctions</h2>
								<h3><span>For Mainstream</span> REAL ESTATE</h3>
								<a href="#" data-text="View Auctions" class="btn">View Auctions</a>
							</div>
						</div>
					</div>
				</div>
			</div>
		</section>
		<!-- banner slider end -->
		
		<!-- start register block -->
		<!--<section class="register-here-block">
			<div class="container">
				<h3>Register Here</h3>
				<ul class="registration-link">
					<li><a href="#" class="active">Agents</a></li>
					<li><a href="#">Developers</a></li>
					<li><a href="#">Buyers</a></li>
					<li><a href="#">Sellers</a></li>
				</ul>
			</div>
		</section><!-- end register block -->
		
		<!-- start dreem home -->
		<!--<section class="start-dream-home">
			<div class="container">
				<h3>Start Bidding On Your Dream Home</h3>
				<p>Propbidder is a home auction marketplace for non-distressed, mainstream real estate.<br/>Bid real- time, anywhere in the world from your desktop or mobile device via the Propbidder app, or participate in-person at the Propbidder-sponsored live auction event</p>
				<a href="#" class="btn" data-text="Sign up to get started">Sign up to get started</a>
			</div>
		</section><!-- end dreem home -->
		
		<!--<div class="profile1-page inner-page">
			<section class="profile-left-section-wraper">
				<div class="profile-left-section">
					<h2>bid works</h2>
					<div class="list-section">
						<ul>
							<li><a class="prof list" href="javascript:void(0)">Profile</a></li>
							<li><a class="fav list" href="javascript:void(0)">Favourites</a></li>
							<li><a class="hist list" href="javascript:void(0)">History</a></li>
							<li><a class="emalert list" href="javascript:void(0)">Email Alerts</a></li>
						</ul>
					</div>
				</div>
			</section>
			<div class="container-fluid">
				<section class="profile-right-section-wraper">
					<div class="profile-right-section">
						<h2 class="page-title">Profile<a href="javascript:void(0)">Change Password</a></h2>
						<div class="profile-image-section fullWidth">
							<div class="profile-image">
								<a href="javascript:void(0)"><img src="../front/images/profile-pic.png"></a>
							</div>
							<div class="profile-image-desc">
								<div class="profile-name">Admin Clavax</div>
								<div class="add-remove-photo">
									<a href="javascript:void(0)">Remove Photo</a>
									<a href="javascript:void(0)">Browse Photo</a>
								</div>
							</div>


						</div>
						<div class="usr-info fullWidth">
							<div class="row">
								<div class="col-md-12"><h2>User Info</h2></div>
								<form>
									<div class="col-sm-6 col-xs-12">
										<div class="form-group">
											<label>First Name</label>
											<input type="text" name="firstname" placeholder="Admin" class="form-control">
										</div>
									</div>
									<div class="col-sm-6 col-xs-12">
										<div class="form-group">
											<label>Last Name</label>
											<input type="text" name="lastname" placeholder="Clavax" class="form-control">
										</div>
									</div>
									<div class="col-sm-6 col-xs-12">
										<div class="form-group">
											<label>Date Of Birth</label>
											<input type="text" name="dob" placeholder="DOB" class="form-control">
										</div>
									</div>
									<div class="col-sm-6 col-xs-12">
										<div class="form-group">
											<label>Contact Number</label>
											<input type="number" name="cnumber" placeholder="NA" class="form-control">
										</div>
									</div>
									<div class="col-sm-6 col-xs-12">
										<div class="form-group">
											<label>Country</label>
											<div class="form-group selectbox-wrapper">
												<select class="form-control common-input-style">
													<option>Country</option>
													<option>Option 1</option>
													<option>Option 2</option>
													<option>Option 3</option>
												</select>
											</div>
										</div>
									</div>
									<div class="col-sm-6 col-xs-12">
										<div class="form-group">
											<label>State</label>
											<div class="form-group selectbox-wrapper">
												<select class="form-control common-input-style">
													<option>Delhi</option>
													<option>Option 1</option>
													<option>Option 2</option>
													<option>Option 3</option>
												</select>
											</div>
										</div>
									</div>
									<div class="col-sm-6 col-xs-12">
										<div class="form-group">
											<label>Street</label>
											<div class="form-group selectbox-wrapper">
												<select class="form-control common-input-style">
													<option>Street</option>
													<option>Option 1</option>
													<option>Option 2</option>
													<option>Option 3</option>
												</select>
											</div>
										</div>
									</div>
									<div class="col-sm-6 col-xs-12">
										<div class="form-group">
											<label>City</label>
											<div class="form-group selectbox-wrapper">
												<select class="form-control common-input-style">
													<option>City</option>
													<option>Option 1</option>
													<option>Option 2</option>
													<option>Option 3</option>
												</select>
											</div>
										</div>
									</div>
									<div class="col-sm-6 col-xs-12">
										<button type="submit" value="Submit">Submit</button>
									</div>
								</form>
							</div>
						</div>
					</div>
				</section>
			</div>
		</div>-->	
		
		<!-- property page -->
		
		<section class="banner">
			<div class="property-page-slider">
				<div>
					<div class="slide-item">					
						<figure>
							<img src="../front/images/property-slide1.jpg" alt="" />
						</figure>
						<div class="banner-content">
							<div class="container">
								<h2>660 Douglass Street</h2>
								<h5>Noe Valley, San Francisco, California</h5>
							</div>
						</div>
					</div>
				</div>
				<div>
					<div class="slide-item">					
						<figure>
							<img src="../front/images/property-slide2.jpg" alt="" />
						</figure>
						<div class="banner-content">
							<div class="container">
								<h2>660 Douglass Street</h2>
								<h5>Noe Valley, San Francisco, California</h5>
							</div>
						</div>
					</div>
				</div>
				<div>
					<div class="slide-item">					
						<figure>
							<img src="../front/images/property-slide1.jpg" alt="" />
						</figure>
						<div class="banner-content">
							<div class="container">
								<h2>660 Douglass Street</h2>
								<h5>Noe Valley, San Francisco, California</h5>
							</div>
						</div>
					</div>
				</div>
				<div>
					<div class="slide-item">					
						<figure>
							<img src="../front/images/property-slide2.jpg" alt="" />
						</figure>
						<div class="banner-content">
							<div class="container">
								<h2>660 Douglass Street</h2>
								<h5>Noe Valley, San Francisco, California</h5>
							</div>
						</div>
					</div>
				</div>
			</div>
			<a href="#" class="premium-lot">Premium Lot<span>500 Extra Square Feet</span></a>
		</section>
		<section class="property-page-content">
			<aside class="auction-info-sidebar">
				<h3>Auction Info</h3>
				<ul>
					<li>
						<span class="icon1"></span>
						<h5>PRICE INFO</h5>
						<p>Selling with Published Reserve</p>
					</li>
					<li>
						<span class="icon2"></span>
						<h5>DATE & TIME</h5>
						<p>June 20, 2017<br/>2 PM PST</p>
					</li>
					<li>
						<span class="icon3"></span>
						<h5>AUCTION LOCATION</h5>
						<p>On-Site & Online</p>
					</li>
				</ul>
				<button class="add-calender">ADD TO CALENDER</button>
			</aside>
			<div class="container-fluid">
				<div class="property-des">
					<h3>Property Description</h3>
					<div class="property-info">
						<div class="location">							
							<p><span>Locations</span>656-660 Douglass Street, San Francisco, CA 94114</p>
							<strong>7 beds, 5.5 baths (3,857 Square Feet)</strong>
						</div>
						<div class="agent-listing">
							<span>Agent Listing</span>
							<strong>$2,995,000</strong>
						</div>
					</div>
					<ul class="property-det-list">
						<li>Main residence with 5 Bedrooms, 3.5 Baths, Two Decks</li>
						<li>Legal Second Unit with 2 Bedrooms, 2 Baths, Deck, Patio</li>
						<li>2 Car Side-by-Side Garage</li>
						<li>Private Elevator</li>
						<li>Beautiful Garden with Multiple Outdoor Living Areas</li>
					</ul>
					<p>This beautifully renovated Victorian residence on a prime Noe Valley block is fabulously grand, yet exudes a warmth and intimacy ideal for family living. Located just steps away from Noe Valley’s 24th Street coffee shops, restaurants and shopping, this 7-bedroom, 5.5-bath home includes a 2 bed/2 bath legal second unit that’s perfect for an au-pair, your extended family compound, or supplemental rental income. A private elevator flows between the large two-car garage to both the home’s main living area and the second unit, allowing easy access between all levels for maximum flexibility.</p>
					<p>The main residence’s modern, open and spacious floor plan features a bright living room with tall windows, lovely views and a gas fireplace, and opens gracefully to the well-equipped Chef’s kitchen and formal dining room. The kitchen’s Viking appliances, marble countertops, custom cabinetry and elegant, airy feel make cooking and entertaining a pleasure. A main level Master Suite with tranquil backyard outlook leads to the home’s lovely and green outside spaces: a landscaped garden along with decks off of both the main and upstairs levels provide an easy, natural indoor/outdoor flow throughout the property.</p>
					<p>Upstairs are 4 bedrooms on one level, a rare find, and two full baths. Extraordinary natural light and comfortable, character-filled spaces make the home absolutely unique and ideally suited for families and entertainers alike.</p>
					<div class="main-facts">
						<h3>Main Facts</h3>
						<div class="main-facts-slider">
							<div>
								<div class="proerty-facts">
									<span>Type</span>
									<small>Single Family</small>
								</div>
							</div>
							<div>
								<div class="proerty-facts">
									<span>Year Built</span>
									<small>1900</small>
								</div>
							</div>
							<div>
								<div class="proerty-facts">
									<span>Cooling</span>
									<small>Central A/C</small>
								</div>
							</div>
							<div>
								<div class="proerty-facts">
									<span>Parking</span>
									<small>Garage (2 spaces)</small>
								</div>
							</div>	

						</div>
					</div>
					<div class="interior-features">
						<h3>Interior Features</h3>
						<div class="features-list">
							<h5>Bedroom</h5>
							<ul>
								<li># of Bedrooms: 7</li>
								<li>4 Bedrooms on Upper Level</li>
								<li>2 Bedrooms on Lower Level</li>
								<li>Master Suite on Main Level</li>
							</ul>
						</div>
						<div class="features-list">
							<h5>Bathroom</h5>
							<ul>
								<li># of Baths: 5.5</li>
								<li>2 Baths on Upper Level</li>
								<li>1.5 Baths on Main Level</li>
								<li>2 Baths on Lower Level</li>
							</ul>
						</div>
						<div class="features-list">
							<h5>Other Interior Features</h5>
							<ul>
								<li>Hardwood Floors</li>
								<li>Bay Windows</li>
								<li>Storage Areas</li>
							</ul>
						</div>						
					</div>
					<div class="photo-gallary">
						<div class="gallary-item">
							<a href="#"><span>Virtual Tour</span></a>
						</div>
						<div class="gallary-item">
							<a href="#"  data-openbox="#gallery2" class="popup-name"><span>Floorplan</span></a>
						</div>
						<div class="gallary-item">
							
							<a href="#" data-openbox="#gallery" class="popup-name"><span>Photo Gallery</span></a>
						</div>
					</div>
					<div class="more-facts">
						<a href="#">See More Facts and Features</a>
					</div>
				</div>
				<aside class="agent-info">
					<h3>Agent Info</h3>
					<div class="user-block">
						<figure>
							<img src="../front/images/agent-img1.jpg" alt="" />
						</figure>
						<h6>Ron Abta <br/>Recent Sales</h6>
						<span>Ron Abta</span>
						<span>Recent Sales</span>
						<ul>
							<li></li>
							<li></li>
							<li></li>
							<li></li>
							<li></li>
						</ul>
						<button class="email-agent">Email Agent</button>
					</div>
				</aside>
			</div>
		</section>
		<section class="ask-property-block">
			<div class="container">
				<div class="row">
					<div class="col-sm-5 col-sm-offset-1 col-xs-12">
						<h4>Pre-Qualify & Get Approved</h4>
						<button>Register Here</button>
					</div>
					<div class="col-sm-5 col-xs-12">
						<h4>Ask Property Question</h4>
						<button>Contact Us</button>
					</div>
				</div>
			</div>
		</section>

		<!-- market page -->
		<!--<section class="banner">
			<div class="market-page-banner">								
				<figure>
					<img src="../front/images/market-page-banner.jpg" alt="" />
				</figure>
				<div class="banner-content">
					<div class="container">
						<h2>Propbidder operates in the best markets <span> throughout California</span></h2>
					</div>
				</div>				
			</div>
		</section>
		<section class="best-bidwrok-area">
			<div class="inner-container">
				<h3>Get to know some of <span>Propbidder</span> best suburbs and areas.<br/>
Browse. Find. Explore.</h3>
				<div class="row">
					<div class="col-sm-6 col-xs-12">
						<div class="area-block">
							<figure>
								<img src="../front/images/best-area-img1.jpg" alt="" />
								<figcaption>SAN <br/>FRANCISCO</figcaption>
							</figure>							
							<a href="#"></a>
						</div>
					</div>
					<div class="col-sm-6 col-xs-12">
						<div class="area-block">
							<figure>
								<img src="../front/images/best-area-img2.jpg" alt="" />
								<figcaption>LOS <br/>ANGELES</figcaption>
							</figure>							
							<a href="#"></a>
						</div>
					</div>
					<div class="col-sm-6 col-xs-12">
						<div class="area-block">
							<figure>
								<img src="../front/images/best-area-img3.jpg" alt="" />
								<figcaption>SILICON <br/>VALLEY</figcaption>
							</figure>							
							<a href="#"></a>
						</div>
					</div>
					<div class="col-sm-6 col-xs-12">
						<div class="area-block">
							<figure>
								<img src="../front/images/best-area-img4.jpg" alt="" />
								<figcaption>ORANGE <br/>COUNTY</figcaption>
							</figure>							
							<a href="#"></a>
						</div>
					</div>
				</div>
			</div>
		</section>-->
		
	</div>
	<!-- footer start from here -->
	<footer id="footer">
		<div class="footer-menu">
			<div class="container">
				<div class="row">
					<div class="col-sm-8 hidden-xs">
						<ul>
							<li><a href="#">Auctions</a></li>
							<li><a href="#">View All Auctions</a></li>
							<li><a href="#">Markets</a></li>
							<li><a href="#">Existing Home</a></li>
							<li><a href="#">New Homes</a></li>
						</ul>
						<ul>
							<li><a href="#">Lifestyles</a></li>
							<li><a href="#">Mountain</a></li>
							<li><a href="#">Water</a></li>
							<li><a href="#">Metro</a></li>
							<li><a href="#">Ranch</a></li>
						</ul>
						<ul>
							<li><a href="#">Company</a></li>
							<li><a href="#">About Us</a></li>
							<li><a href="#">Team</a></li>
							<li><a href="#">Blog</a></li>
							<li><a href="#">Press Release</a></li>
						</ul>
					</div>
					<div class="col-sm-4 hidden-xs">
						<div class="get-in-touch">
							<h5>Get in Touch</h5>
							<a href="#" class="location-link"><i class="fa fa-map-marker" aria-hidden="true"></i>Stanford, CA</a>
							<span class="clearfix"></span>
							<a href="mailto:info@Propbidder.com" class="mail-link"><i class="fa fa-envelope" aria-hidden="true"></i> info@Propbidder.com</a>
						</div>
					</div>
				</div>
			</div>
		</div>
		<div class="footer-bottom">
			<div class="container">
				<div class="row"> 
					<div class="col-sm-3 pull-right col-xs-12">
						<ul class="social-media">
							<li><a href="#"><i class="fa fa-facebook" aria-hidden="true"></i></a></li>
							<li><a href="#"><i class="fa fa-linkedin" aria-hidden="true"></i></a></li>
							<li><a href="#"><i class="fa fa-google-plus" aria-hidden="true"></i></a></li>
						</ul>
					</div>
					<div class="col-sm-6 col-sm-offset-3 text-center col-xs-12">
						<p class="copy-right">&copy; 2017 Propbidder, Inc.</p>
					</div>					
				</div>
			</div>
		</div>
	</footer>	<!-- footer end here -->
	<div class="overlay"></div>
</div>


<!-- popup start from here -->

<div class="modal fade popUpBox" id="myModal" role="dialog">
    <div class="modal-dialog popup-container">    
		<!-- Modal content-->
		<div class="popup-content">
			<div class="left-content">
				<h3>Propbidder</h3>
				<ul>
					<li>Lorem ipsum dolor sit amet, consectetur adipiscing elit</li>
					<li>Lorem ipsum dolor sit amet, consectetur adipiscing elit</li>
					<li>Lorem ipsum dolor sit amet, consectetur adipiscing elit</li>
				</ul>
			</div>
			<div class="right-content">
				<div class="form-heading">
					<h5>LOGIN</h5>
					<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit.</p>
				</div>
				<form>
					<div class="form-group">
						<label class="common-lable-style">Email</label>
						<input type="email" class="form-control common-input-style" />
					</div>
					<div class="form-group">
						<label class="common-lable-style">Password</label>
						<input type="password" class="form-control common-input-style" />
					</div>
					<div class="form-group creat-new-acc">
						<a href="#">Create new account</a>
					</div>
					<div class="form-group btn-block">
						<button type="button">SIGN IN</button>
						<a href="#">Forgot Password</a>
					</div>
				</form>
			</div>
			<button type="button" class="close-popup" data-dismiss="modal">&times;</button>
		</div>   
		
	</div>
</div>

<div class="popUpBox gallary-popup" id="gallery" >
    <div class="modal-dialog popup-container">    
        <div class="popup-content">
			<div class="gallary-slider">
				<div>
					<div class="proerty-facts">
						<figure><img src="../front/images/property-slide1.jpg" alt="" /></figure>
					</div>
				</div>
				<div>
					<div class="proerty-facts">
						<figure><img src="../front/images/property-slide2.jpg" alt="" /></figure>
					</div>
				</div>
			</div>
			<button type="button" class="close-popup" data-closebox=".popUpBox">×</button>
		</div>
	</div>
</div>

<div class="popUpBox gallary-popup" id="gallery2" >
    <div class="modal-dialog popup-container">    
        <div class="popup-content">
			<div class="gallary-slider1">
				<div>
					<div class="proerty-facts">
						<figure><img src="../front/images/property-slide1.jpg" alt="" /></figure>
					</div>
				</div>
				<div>
					<div class="proerty-facts">
						<figure><img src="../front/images/property-slide2.jpg" alt="" /></figure>
					</div>
				</div>
				<div>
					<div class="proerty-facts">
						<figure><img src="../front/images/property-slide1.jpg" alt="" /></figure>
					</div>
				</div>
				<div>
					<div class="proerty-facts">
						<figure><img src="../front/images/property-slide2.jpg" alt="" /></figure>
					</div>
				</div>
			</div>
			<div class="gallary-slider2">
				<div>
					<div class="proerty-facts">
						<figure><img src="../front/images/property-slide1.jpg" alt="" /></figure>
					</div>
				</div>
				<div>
					<div class="proerty-facts">
						<figure><img src="../front/images/property-slide2.jpg" alt="" /></figure>
					</div>
				</div>
				<div>
					<div class="proerty-facts">
						<figure><img src="../front/images/property-slide1.jpg" alt="" /></figure>
					</div>
				</div>
				<div>
					<div class="proerty-facts">
						<figure><img src="../front/images/property-slide2.jpg" alt="" /></figure>
					</div>
				</div>
			</div>
			<button type="button" class="close-popup" data-closebox=".popUpBox">×</button>
		</div>
	</div>
</div>

<!-- <script src="http://ajax.googleapis.com/ajax/libs/jquery/1.10.2/jquery.min.js"></script> -->
<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/2.1.4/jquery.min.js"></script>
<script src="../front/js/bootstrap.min.js"></script>
<script src="../front/js/slick.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/fancybox/3.0.47/jquery.fancybox.min.js"></script>
<script src="../front/js/custom.js"></script>
<script>
	 
	 $('.gallary-slider').slick({
		dots: false,
		infinite: true,
		speed: 300,
		slidesToShow: 1,
		slidesToScroll: 1,		
	});

	$('.home-page-slider').slick({
		dots: true,
		infinite: true,
		speed: 500,
		fade: true,
		autoplay: true,
		cssEase: 'linear'
	});
	$('.property-page-slider').slick({
		dots: true,
		infinite: true,
		speed: 500,
		fade: true,
		autoplay: true,
		cssEase: 'linear'
	});
	$('.main-facts-slider').slick({
		dots: false,
		infinite: true,
		speed: 300,
		slidesToShow: 4,
		slidesToScroll: 1,
		responsive: [
			{
			  breakpoint: 1400,
			  settings: {
			    slidesToShow: 3,
			    slidesToScroll: 1,
			  }
			},
			{
			  breakpoint: 991,
			  settings: {
			    slidesToShow: 2,
			    slidesToScroll: 1,
			  }
			},
			{
			  breakpoint: 767,
			  settings: {
			    slidesToShow: 1,
			    slidesToScroll: 1
			  }
			}
		]
	});






	$(document).ready(function(){
		$('.mb-menu-icon').click(function(){
			$('.overlay').toggleClass('show');
			$(this).toggleClass('close-menu');
			$('.nav-menu').slideToggle(600);
		});
		$('.nav-menu li a i').click(function(){
			$(this).parents('li').siblings().find('.submenu').slideUp();	
			$(this).parent().next().slideToggle();			
					
		});
	});
</script>
</body> 
</html>   
