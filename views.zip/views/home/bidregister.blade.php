@extends('layouts.master')
@section('title', trans('seocontent.home_title'))
@section('meta_title', trans('seocontent.home_meta_title'))
@section('meta_description', trans('seocontent.home_desc'))
@section('sidebar')
@parent
@endsection
@section('content')


<?php
$constantDataFile = Config::get('constants');
?> 


<section class="banner inner-page-banner">
	<div class="banner-content">
		<div class="container">
			<h2 class="animated" data-animation="appeared fadeInUp" data-animation-delay="200">Home Auctions</h2>
			<h3 class="animated" data-animation="appeared fadeInUp" data-animation-delay="400"><span>For Mainstream</span> REAL ESTATE</h3>             
		</div>
	</div>
</section>
<section class="bid-registration-page">
	<div class="container">
		<h3 class="animated" data-animation="appeared fadeInUp" data-animation-delay="200">Bidding Registration</h3>
		<div class="form-section">
			<form id="bid_form" name="bid_form" action="{{ URL::route('bid.savebidregistration') }}" method="POST" enctype='multipart/form-data'>
				<input type="hidden" id="_token" name="_token" value="{{ csrf_token() }}">
				<h4 class="animated" data-animation="appeared fadeInUp" data-animation-delay="300">Buyer Information</h4>
				<div class="buyar-info gray-bg">
					<div class="row">
						<div class="col-sm-6 col-xs-12 padding-right">
							<div class="form-group animated" data-animation="appeared fadeInDown" data-animation-delay="100">
								<label>Registrant Name<sup>*</sup></label>
								{!! Form::text('registrant_name',"",['class'=>'form-control',"id"=>"registrant_name"] ) !!}
							</div>
						</div>
						<div class="col-sm-6 col-xs-12 padding-left">
							<div class="form-group animated" data-animation="appeared fadeInDown" data-animation-delay="200">
								<label>Buyer Name (if different)</label>
								{!! Form::text('name',"", ['class'=>'form-control',"id"=>"name"] ) !!}
							</div>
						</div>
					</div>
					<div class="row">
						<div class="col-sm-6 col-xs-12 padding-right">
							<div class="form-group animated" data-animation="appeared fadeInDown" data-animation-delay="300">
								<label>Email<sup>*</sup></label>
								{!! Form::text('email',"", ['class'=>'form-control',"id"=>"email"] ) !!}
							</div>
						</div>
						<div class="col-sm-6 col-xs-12 padding-left">
							<div class="form-group animated" data-animation="appeared fadeInDown" data-animation-delay="400">
								<label>Mobile Number<sup>*</sup></label>
								{!! Form::text('contact_number',"", ['class'=>'form-control',"id"=>"contact_number"] ) !!}
							</div>
						</div>
					</div>  
					<div class="row">
						<div class="col-sm-6 col-xs-12 padding-right">
							<div class="form-group animated" data-animation="appeared fadeInDown" data-animation-delay="500">
								<label>Office Number<sup>*</sup></label>
								{!! Form::text('office_number',"", ['class'=>'form-control',"id"=>"office_number"] ) !!}
							</div>
						</div>
						<div class="col-sm-6 col-xs-12 padding-left">
							<div class="form-group animated" data-animation="appeared fadeInDown" data-animation-delay="600">
								<label>Extension</label>
								{!! Form::text('extension',"", ['class'=>'form-control',"id"=>"extension"] ) !!}
							</div>
						</div>
					</div>  
					<div class="row">
						<div class="col-sm-6 col-xs-12 padding-right">
							<div class="form-group animated" data-animation="appeared fadeInDown" data-animation-delay="700">
								<label>Address Line 1<sup>*</sup></label>
								{!! Form::text('addressline',"", ['class'=>'form-control',"id"=>"addressline"] ) !!}
							</div>
						</div>
						<div class="col-sm-6 col-xs-12 padding-left">
							<div class="form-group animated" data-animation="appeared fadeInDown" data-animation-delay="800">
								<label>Address Line 2</label>
								{!! Form::text('addressline2',"", ['class'=>'form-control',"id"=>"addressline2"] ) !!}
							</div>
						</div>
					</div>
					<div class="row">
						<div class="col-sm-6 col-xs-12 padding-right">
							<div class="form-group animated" data-animation="appeared fadeInDown" data-animation-delay="800">
								<label>City<sup>*</sup></label>
								{!! Form::select('city',[''=>'Please Select']+$city_list,"", ['class'=>'form-control',"id"=>"city"] ) !!} 
							</div>
						</div>
						<div class="col-sm-6 col-xs-12 padding-left">
							<div class="form-group animated" data-animation="appeared fadeInDown" data-animation-delay="800">
								<label>Zip Code<sup>*</sup></label>
								{!! Form::text('zipcode',"", ['class'=>'form-control',"id"=>"zipcode"] ) !!}
							</div>
						</div>
					</div>
					<div class="row">
						<div class="col-sm-6 col-xs-12 padding-right">
							<div class="form-group animated" data-animation="appeared fadeInDown" data-animation-delay="800">
								<label>Country<sup>*</sup></label>
                                {!! Form::select('country',[''=>'Please Select']+$country_list,"", ["class"=> "form-control","id"=>"country"] ) !!}
							</div>
						</div>
						<div class="col-sm-6 col-xs-12 padding-left">
							<div class="form-group animated" data-animation="appeared fadeInDown" data-animation-delay="800">
								<label>State<sup>*</sup></label>
                                {!! Form::select('state',[''=>'Please Select']+$state_list,"", ["class"=> "form-control","id"=>"state"] ) !!}
							</div>
						</div>
					</div>
										
				</div>
				<h4 class="animated" data-animation="appeared fadeInUp" data-animation-delay="400">Select one or more properties to bid</h4>
				<div class="purchase-info gray-bg">
					<div class="row">
						<div class="col-xs-12">
							<div class="form-group multiselectOption animated" data-animation="appeared fadeInDown" data-animation-delay="200">
								<label>Property<sup>*</sup> {{ Input::get("id") }}</label>
								<select id="prop" name="prop" multiple="true" class="form-control">									
								@if(!empty($bid_property))
									@foreach($bid_property as $val)
									<option val="{{ $val["id"] }}" {{ @($property_id==$val["id"])?'selected':'' }}>{{ $val["name"] }}</option>
									@endforeach
								@endif
								</select>
                               
							</div>
						</div>                              
					</div>
				</div>                      
				<h4 class="animated" data-animation="appeared fadeInUp" data-animation-delay="400">Proof of funds</h4>
				<div class="funds-info gray-bg">
					<div class="row">
						<div class="col-md-6 col-sm-12 col-xs-12 padding-right">
							<div class="form-group animated" data-animation="appeared fadeInDown" data-animation-delay="300">
								<label>Requested Bid Limit<sup>*</sup></label>
								{!! Form::text('amount',"", ['class'=>'form-control',"id"=>"amount"] ) !!}
							</div>
						</div>                              
					</div>
					<div class="row">
						<div class="col-sm-12 col-xs-12">
							<p class="animated" data-animation="appeared fadeInUp" data-animation-delay="500">Please provide proof of funds or a bank financing letter to demonstrate your ability to bid up to your requested limit.</p>
						</div>
						<div class="col-md-6 col-sm-12 col-xs-12 padding-right">                                    
							<select class="form-control animated" data-animation="appeared fadeInDown" data-animation-delay="500">
							 @if(!empty($constantDataFile['DOCUMENT_LIST']))
                              @foreach(Config::get('constants.DOCUMENT_LIST') as $key=>$data)
                                <option value="{{ $key }}">{{$data}}</option>
                              @endforeach
                            @endif
							</select>
						</div>      
						<div class="col-md-6 col-sm-12 col-xs-12 padding-left add-row"> 
							<div class="brouse-file choose-file  animated" data-animation="appeared fadeInDown" data-animation-delay="600">
								<input type="file" name="profileimg" id="profileimg" onchange="checkimagetype(this.id)" data-targetimg="imageTag" class="custom-file-input">                                
								<label for="profileimg"><span>Choose File</span><span class="file-text">no file chosen</span></label>
							</div>
							<button class="btn addMore">Add More</button>                                   
						</div>                              
					</div>
					<div class="row">
						<div class="col-sm-12 col-xs-12 text-center">
							<div class="btn-block">
								<button class="btn submitBtn animated" data-animation="appeared bounceInUp" data-animation-delay="600">Submit</button>
							</div>
						</div>
					</div>
				</div>
				
			</form>
		</div>              
	</div>
</section>



@stop
@section('scriptinclude')
<script src="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-multiselect/0.9.13/js/bootstrap-multiselect.js"></script>
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-multiselect/0.9.13/css/bootstrap-multiselect.css">
<script src="{{ asset('front/js/bid/bidregistration.js') }}"></script>
<script>
    $("#state_id").change(function(){
        
        var stateid = $("#state").val()

        $.ajax({
            url: '{{ URL::route("utility.city") }}',
            data : {"state":stateid},
            dataType: 'json',
            success : function(data){console.log(data)
                var html = "<option>Select City</option>";
                $.each(data.items,function(key,value){
                    html += "<option value='"+value.id+"''>"+value.text+"</option>";
                });
                $("#city").html(html)                
            }
        });
        
    });


    $("#country_id").change(function(){
        var country = $("#country").val()
        $.ajax({
            url: '{{ URL::route("utility.state") }}',
            data : {"country":country},
            dataType: 'json',
            success : function(data){
                console.log(data)
                var html = "<option>Select State</option>";
                $.each(data.items,function(key,value){
                    html += "<option value='"+value.id+"''>"+value.text+"</option>";
                });
                $("#state").html(html)
            }
        });
    });

</script>

@stop
