<?php $data_arr = !empty($data['data']) ? $data['data'] : ''; ?>

@extends('layouts.inner')
@section('title') {{(!empty($data_arr['seo_title']) ? $data_arr['seo_title'] : '')}} @stop
@section('meta_description'){{(!empty($data_arr['seo_description']) ? $data_arr['seo_description'] : '')}}@stop
@section('meta_title'){{(!empty($data_arr['seo_title']) ? $data_arr['seo_title'] : '')}}@stop
@section('sidebar')
@parent
@endsection
@section('content')

<style type="text/css">
    .mid-content.after_login{padding-bottom:0;}
</style>

<!-- About, Contact, Feedback  Page html start -->
<div class="row_dv">

    <header class="row_dv content_page_header">
     <div class="center-block">
        <h1 class="term_head">{!! (!empty($data_arr['title']) ? ucfirst($data_arr['title']) : '') !!}</h1>
              <p>Please fill out our form and we will get back to you.</p>
              </div>
        <figure>
            <img class="banner_desktop" src="{{ asset('front/images/banner_contactus.jpg') }}" alt="{!! (!empty($data_arr['title']) ? $data_arr['title'] : '') !!}">
            <img class="banner_mobile" src="{{ asset('front/images/banner_contactus_mobile.jpg') }}" alt="{!! (!empty($data_arr['title']) ? $data_arr['title'] : '') !!}">
        </figure>
       
    </header>
    <section class="row_dv feedback_nav_bar">
        <div class="container">
            <ul class="feedback_nav text-center">
                <li><a href="{{URL::route('home.about')}}" >{!! trans('footer.about_us') !!}</a></li>
                <li><a href="{{URL::route('home.contact')}}" class="active">{!! trans('footer.contact_us') !!}</a></li>
                <li><a href="javascript:void(0);" data-toggle="modal" data-target="#myModal">{!! trans('common.feedback') !!}</a></li>
            </ul>
        </div>
    </section>


    <section class="row_dv pad_bot about_info white_body">
        <div class="container feedback_content">
            <div class="row_dv white_page_base low_gap">
            @if(Session::has('pagemsg'))
              {!! Session::get('pagemsg') !!}
            @endif

            <div class="row">
                <div class="col-sm-12 contact_head">
                   <h2><span>{!! trans('common.casamozambique_ltd') !!}</span></h2>
                </div>
            </div>
            <div class="row">

             <aside class="col-xs-12 col-sm-4 contact_info">
                    <div class="row_dv"><?php echo!empty($data_arr['content']) ? $data_arr['content'] : ''; ?></div>
                </aside>

            <div class="col-xs-12 col-sm-8  contact_us_right">
            <h3 class="panel-title">{!! trans('common.send_enquiry') !!}</h3>
                    {!! Form::open(array('id'=>'contactus','route' => 'home.contact', 'method' => 'post')) !!}  
                    <input type="hidden" id="csrftoken" name="_token" value="{{ csrf_token() }}">

                    <div class="row">
                    <div class="col-sm-6 form-group">
                       <!--  {!! Form::label('name',trans("common.name").'*:') !!} -->
                        {!! Form::text('name',Session::get('auth_user')['name'], ['class' => 'form-control', 'placeholder' => trans("common.name")]) !!}

                    </div>

                    <div class="col-sm-6 form-group">

                       <!--  {!! Form::label('email',trans("common.email").'*:') !!} -->
                        {!! Form::email('email',Session::get('auth_user')['email'], ['class' => 'form-control', 'placeholder' => trans("common.email")]) !!}


                    </div>
                    </div>


                    <div class="form-group">
                        <!-- {!! Form::label('message',trans("common.message").'*:') !!} -->
                        {!! Form::textarea('message',null, ['class' => 'form-control', "rows"=>"4","cols"=>"50", 'placeholder' => trans("common.message")]) !!}

                    </div>

                    <div class="form-group">
                <!--         <label for="message">{{trans("common.captcha")}}<span>*</span>
                        </label> -->
                        <div class="row">
                            <div class="col-sm-4">
                                <div class="g-recaptcha" data-sitekey="{{Config::get('constantsUrl.site_key')}}"></div>
                                <input type="hidden" class="hiddenRecaptcha required" name="hiddenRecaptcha" id="hiddenRecaptcha">


                            </div>
                            <div class="col-sm-8 form-group pull-right contact_btn">

                        {!! Form::submit(trans('common.submit'), ['id'=>'contactus_btn','class'=>'btn btn-primary btn-pad btn-lg'])!!}
                    </div>

                        </div>
                    </div>

                    
                    {!! Form::close() !!}
                </div>

                <div class="col-sm-12 contact_map">
                  <img alt="contact" src="{{ asset('front/images/contact_map.jpg') }}" >                 
                </div>
               

                </div>
            </div>
        </div>
    </section>



</div>

</div>
@stop
@section('scriptinclude')
<!---add javascript ---->
<script src='https://www.google.com/recaptcha/api.js'></script>
<script src="{{ asset('front/js/pages/contactus.js') }}"></script>
@stop