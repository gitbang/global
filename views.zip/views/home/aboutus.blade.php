@extends('layouts.inner_property')
@section('title') {{ (!empty($data_arr['seo_title']) ? $data_arr['seo_title'] : '') }} @stop
@section('meta_description'){{(!empty($data_arr['seo_description']) ? $data_arr['seo_description'] : '')}}@stop
@section('meta_title'){{(!empty($data_arr['seo_title']) ? $data_arr['seo_title'] : '')}}@stop

@section('content')

        <section class="banner about-us-banner">
            <div class="banner-content">
                <div class="container">
                    <h2>An Online Bidding Platform</h2>
                    <h3><span>For transacting the best </span>NEW HOMES <span> and </span> CONDOS <span> on the market </span></h3>                
                </div>
            </div>
        </section>
        <section class="about-us-block">
            <div class="container">
                <h3> About Us</h3>
                <!-- <ul>
                    <li>If you thought home auctions were just for distressed or ultra-luxury properties, THINK AGAIN!</li>
                    <li>Propbidder is a disruptive online home auction marketplace for new and existing homes.</li>
                    <li>We work with homebuilders and real estate agents to improve (not replace) the traditional sales process. For buyers, sellers,<br/> and other consumers, Propbidder is the dominant discovery and bidding latform or mainstream, non-distressed home auctions.</li>
                </ul> -->
				<div class="how-does-it-work">
					<h6>Propbidder, Inc. ("Propbidder") is an online bidding and offer platform for buying and selling highly differentiated new homes and condos. We work with the nation's most elite real estate developers to provide homebuyers (and their agents) the ability to bid on the best new homes and condos on the market, located in the best cities, in the best neighborhoods, and in the best school districts.</h6>
					<h3>How does it work</h3>
					<p>Propbidder allows homebuyers (and their agents) the ability to bid on new construction homes and condos in real-time anywhere in the world on their mobile or desktop devices using the Propbidder website or app. Propbidder simultaneously hosts an offline bidding option on-site of a model home or via absentee bid.</p>
					<p>By integrating with real estate developers, Propbidder can provide homebuyers (and their buying agents) with a revolutionarily fast and transparent transaction process that can be carried out in 30 days or less. Through our close relationships with builders, we also provide consumers with the latest, best new home and condo inventory on the market, a feat unmatched by any other online real estate platform.</p>
				</div>
            </div>
        </section>
        <section class="who-we-serve">
            <div class="container">
                <h3>Who We Serve</h3>
                <div class="serve-slider">
                    <div>
                        <div class="img-block">
                            <figure>
                                <img src="../front/images/serve-img1.jpg" alt="" />
                            </figure>                           
                        </div>
                        <h4>Homebuilders</h4>
                        <p>Efficient Price-Setting <span>Sustain Buyer Momentum</span> Facilitate Foreign Audiences</p>
                    </div>
                    <div>
                        <div class="img-block">
                            <figure>
                                <img src="../front/images/serve-img2.jpg" alt="" />
                            </figure>                           
                        </div>
                        <h4>Agents & Brokers</h4>
                        <p>Work On Client's Behalf<span>Save Time on Negotiations</span> Capture Only Motivated Parties</p>
                    </div>
                    <div>
                        <div class="img-block">
                            <figure>
                                <img src="../front/images/serve-img3.jpg" alt="" />
                            </figure>                           
                        </div>
                        <h4>Buyers</h4>
                        <p>Transact Faster <span>Increase Offer Transparency</span> Discover A Market's Best Homes</p>
                    </div>
                </div>
            </div>          
        </section>
        <section class="real-state-domain">
            <div class="container">
                <h3>Strong Real Estate Domain & Tech Expertise Among <br/>Founding Team, Mentors, & Advisors</h3>
                <div class="row">
                    <div class="col-xs-12">
                        <div class="logo-slider">
                            <div>
                                <div class="slide-item"><img src="../front/images/logo/Christies.png" alt="" /></div>
								<div class="slide-item"><img src="../front/images/logo/3.png" alt="" /></div>
                            </div>
                            
                            <div>
                                <div class="slide-item"><img src="../front/images/logo/8.png" alt="" /></div>
                           
                                <div class="slide-item"><img src="../front/images/logo/10.png" alt="" /></div>
                            </div>
                            <div>
                                <div class="slide-item"><img src="../front/images/logo/11.png" alt="" /></div>                            
                                <div class="slide-item"><img src="../front/images/logo/12.png" alt="" /></div>
                            </div>
                            <div>
                                <div class="slide-item"><img src="../front/images/logo/16.png" alt="" /></div>                           
                                <div class="slide-item"><img src="../front/images/logo/15.png" alt="" /></div>
                            </div>

                            <div>
                                <div class="slide-item"><img src="../front/images/logo/1.png" alt="" /></div>                            
                                <div class="slide-item"><img src="../front/images/logo/2.png" alt="" /></div>
                            </div>
                            <div>
                                <div class="slide-item"><img src="../front/images/logo/4.png" alt="" /></div>                            
                                <div class="slide-item"><img src="../front/images/logo/5.png" alt="" /></div>
                            </div>
                            <div>
                                <div class="slide-item"><img src="../front/images/logo/6.png" alt="" /></div>                            
                                <div class="slide-item"><img src="../front/images/logo/7.png" alt="" /></div>
                            </div>
                            <div>
                                <div class="slide-item"><img src="../front/images/logo/9.png" alt="" /></div>                            
                                <div class="slide-item"><img src="../front/images/logo/13.png" alt="" /></div>
                            </div>   
                            <!--<div>
                                <div class="slide-item"><img src="../front/images/logo/17.png" alt="" /></div>
                            </div>-->                                                                               
                        </div>

                    </div>
                </div>
            </div>
        </section>
        <section class="combine-technology">
            <div class="container">
                <h3>A Rare Combination Of Real Estate & Technology</h3>
                <div class="technology-slider">             
                    <div>
                        <div class="technology-info">
                            <figure>
                                <img src="../front/images/technology-user1.jpg" alt="" />
                            </figure>
                            <h4>Mikael Hastrup<span>CEO, Founder</span></h4>
                            <ul>
                                <li>Stanford GSB 17 , UC Irvine 12</li>
                                <li>RE Tech Investor @ Fifth Wall</li>
                                <li>Growth @ Matterport</li>
                                <li>Strategy @ irvine Company</li>
                                <li>TMT IB @ Deutsche Bank</li>
                            </ul>
                        </div>
                    </div>
                    <div>
                        <div class="technology-info">
                            <figure>
                                <img src="../front/images/technology-user2.jpg" alt="" />
                            </figure>
                            <h4>Akshay Rampuria<span>CTO, Co-Founder</span></h4>
                            <ul>
                                <li>Stanford Computer Science '17</li>
                                <li>President @ Stanford VC Club</li>
                                <li>Full Stack Engineer @ Various Early Stage Startups</li>
                                <li>Experienced with Deep Learning</li>
                            </ul>
                        </div>
                    </div>
                    <div>
                        <div class="technology-info">
                            <figure>
                                <img src="../front/images/technology-user3.jpg" alt="" />
                            </figure>
                            <h4>Erin Allard<span>Product, Co-Founder</span></h4>
                            <ul>
                                <li>MS Int’l RE @ FIU, Mills ‘12</li>
                                <li>Licensed RE Broker</li>
                                <li>RE Investor @ Rockford</li>
                                <li>Instructor @ Girls Who Code</li>
                                <li>CS Fellow @ Hackbright</li>
                            </ul>
                        </div>
                    </div>
                </div>
            </div>
        </section>  
		
        <section class="get-in-touch-footer">
            <div class="container">
                <h3>GET IN TOUCH</h3>
                <div class="row">
                    <div class="col-xs-12 col-sm-6">
                        <a href="https://www.google.com/maps/place/Knight+Management+Center/@37.3216564,-122.1538185,10.5z/data=!4m5!3m4!1s0x0:0x18fe9f3c7b2c2106!8m2!3d37.4281449!4d-122.1623136" target="_blank" class="location-link">Stanford, CA</a>
                    </div>
                    <div class="col-xs-12 col-sm-6 border-left">
                        <a href="mailto:info@propbidder.com" class="mail-link">info@propbidder.com</a>
                    </div>
                </div>
            </div>
        </section>      


@stop

@section('scriptinclude')
<script>
    $('.logo-slider').slick({
        dots: false,
        infinite: true,
        speed: 300,
        slidesToShow: 4,
        slidesToScroll: 1,
        responsive: [
            {
              breakpoint: 991,
              settings: {
                slidesToShow: 3,
                slidesToScroll: 1,
              }
            },
            {
              breakpoint: 600,
              settings: {
                slidesToShow: 2,
                slidesToScroll: 1
              }
            },
            {
              breakpoint: 479,
              settings: {
                slidesToShow: 1,
                slidesToScroll: 1,
              }
            }
        ]
    });
    $('.technology-slider').slick({
        dots: false,
        infinite: true,
        speed: 300,
        slidesToShow: 3,
        slidesToScroll: 1,
        responsive: [
            {
              breakpoint: 991,
              settings: {
                slidesToShow: 2,
                slidesToScroll: 1,
              }
            },
            {
              breakpoint: 767,
              settings: {
                slidesToShow: 1,
                slidesToScroll: 1
              }
            }
        ]
    });
    $('.serve-slider').slick({
        dots: false,
        infinite: true,
        speed: 300,
        slidesToShow: 3,
        slidesToScroll: 1,
        responsive: [
            {
              breakpoint: 991,
              settings: {
                slidesToShow: 2,
                slidesToScroll: 1,
              }
            },
            {
              breakpoint: 767,
              settings: {
                slidesToShow: 1,
                slidesToScroll: 1
              }
            }
        ]
    });
</script>
@stop
