@extends('layouts.master')
@section('title', trans('seocontent.home_title'))
@section('meta_title', trans('seocontent.home_meta_title'))
@section('meta_description', trans('seocontent.home_desc'))
@section('sidebar')
@parent
@endsection
@section('content')




    <!-- banner slider start -->
    <section class="banner">
        <div class="home-page-slider">
            <div>
                <div class="slide-item">                    
                    <figure>
                        <img src="../front/images/home-slide1.jpg" alt="logo" />
                    </figure>
                    <div class="banner-content">
                        <div class="container">
                            <h2 class="animated" data-animation="appeared fadeInUp" data-animation-delay="200">An Online Bidding Platform</h2>
                            <h3 class="animated" data-animation="appeared fadeInUp" data-animation-delay="400"><span>For transacting the best </span>NEW HOMES <span> and </span> CONDOS <span> on the market </span></h3>   
                            <a href="{!! URL::route("property.index") !!}" data-text="View Homes" class="btn animated" data-animation="appeared fadeInUp" data-animation-delay="500">View Homes</a>
                        </div>
                    </div>
                </div>
            </div>
            <div>
                <div class="slide-item">                    
                    <figure>
                        <img src="../front/images/home-slide2.jpg" alt="logo" />
                    </figure>
                    <div class="banner-content">
                       <div class="container">
                            <h2 class="animated" data-animation="appeared fadeInUp" data-animation-delay="100">An Online Bidding Platform</h2>
                            <h3 class="animated" data-animation="appeared fadeInUp" data-animation-delay="200"><span>For transacting the best </span>NEW HOMES <span> and </span> CONDOS <span> on the market </span></h3>
                            <a href="{!! URL::route("property.index") !!}" data-text="View Homes" class="btn animated" data-animation="appeared fadeInUp" data-animation-delay="300">View Homes</a>
                        </div>
                    </div>
                </div>
            </div>
            <div>
                <div class="slide-item">                    
                    <figure>
                        <img src="../front/images/home-slide3.jpg" alt="logo" />
                    </figure>
                    <div class="banner-content">
                        <div class="container">
                            <h2 class="animated" data-animation="appeared fadeInUp" data-animation-delay="100">An Online Bidding Platform</h2>
                            <h3 class="animated" data-animation="appeared fadeInUp" data-animation-delay="200"><span>For transacting the best </span>NEW HOMES <span> and </span> CONDOS <span> on the market </span></h3>
                            <a href="{!! URL::route("property.index") !!}" data-text="View Homes" class="btn animated" data-animation="appeared fadeInUp" data-animation-delay="300">View Homes</a>
                        </div>
                    </div>
                </div>
            </div>
            <div>
                <div class="slide-item">                    
                    <figure>
                        <img src="../front/images/home-slide4.jpg" alt="logo" />
                    </figure>
                    <div class="banner-content">
                        <div class="container">
                            <h2 class="animated" data-animation="appeared fadeInUp" data-animation-delay="100">An Online Bidding Platform</h2>
                            <h3 class="animated" data-animation="appeared fadeInUp" data-animation-delay="200"><span>For transacting the best </span>NEW HOMES <span> and </span> CONDOS <span> on the market </span></h3>
                            <a href="{!! URL::route("property.index") !!}" data-text="View Homes" class="btn animated" data-animation="appeared fadeInUp" data-animation-delay="300">View Homes</a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <!-- banner slider end -->
    
    <!-- start register block -->
    <section class="register-here-block">
        <div class="container">
            <h3  class="animated" data-animation="appeared fadeInUp" data-animation-delay="100">Register Here</h3>
            <ul class="registration-link">
                @if (!Session::get('auth_user'))
                    <li><a href="#" data-openbox="#register" class="popup-name animated" data-animation="appeared fadeInUp" data-animation-delay="100">Agents</a></li>
                    <li><a href="#"  data-openbox="#register" class="popup-name animated" data-animation="appeared fadeInUp" data-animation-delay="200">Homebuilders</a></li>
                    <li><a href="#"  data-openbox="#register" class="popup-name animated" data-animation="appeared fadeInUp" data-animation-delay="300">Buyers</a></li>
                    <li><a href="#"  data-openbox="#register" class="popup-name animated" data-animation="appeared fadeInUp" data-animation-delay="400">Sellers</a></li>
                @else
                <li><a href="#" class="animated" data-animation="appeared fadeInUp" data-animation-delay="100">Agents</a></li>
                    <li><a href="#"  class="animated" data-animation="appeared fadeInUp" data-animation-delay="200">Homebuilders</a></li>
                    <li><a href="#"  class="animated" data-animation="appeared fadeInUp" data-animation-delay="300">Buyers</a></li>
                    <li><a href="#"  class="animated" data-animation="appeared fadeInUp" data-animation-delay="400">Sellers</a>
                    </li>

                @endif
            </ul>
        </div>
    </section><!-- end register block -->
    
    <!-- start dreem home -->
    <section class="start-dream-home">
        <div class="container">
            <h3  class="animated" data-animation="appeared fadeInUp" data-animation-delay="100">Start Bidding On Your Dream Home</h3>
            <p  class="animated" data-animation="appeared fadeInUp" data-animation-delay="300">Propbidder, Inc. (www.propbidder.com) is an online bidding platform for buying and selling highly differentiated new homes and condos. <br/> We work with the nation's most elite real estate developers to provide homebuyers (and their agents) the ability to bid on the best new homes and condos on the market, located in the best cities, in the best neighborhoods, and in the best school districts.</p>
            @if (!Session::get('auth_user'))
                <a href="#" data-openbox="#register" class="popup-name btn animated" data-animation="appeared bounceInUp" data-animation-delay="500" data-text="Sign up to get started">Sign up to get started</a>
            @endif
        </div>
    </section><!-- end dreem home -->





@stop
@section('scriptinclude')

<script>
	$(document).ready(function(){		
	   $('.home-page-slider').slick({
			dots: true,
			infinite: true,
			speed: 500,
			fade: true,
			autoplay: true,
			autoplaySpeed : 3000,
			cssEase: 'linear'
		}); 
		$( ".slick-dots li button" ).mouseleave(function() {	
			$('.home-page-slider').slick('slickPlay');
		});
	});
	$(window).load(function(){
		$('.home-page-slider').css({'max-height' : 'initial'});
	});
</script>
@stop
