<?php $data_arr = !empty($data['data']) ? $data['data'] : '' ; ?>

@extends('layouts.inner')
@section('title') {{(!empty($data_arr['seo_title']) ? $data_arr['seo_title'] . ' | Casa Mozambique' : '')}} @stop
@section('meta_description'){{(!empty($data_arr['seo_description']) ? trim_text($data_arr['seo_description'], '140', '') : '')}}@stop
@section('meta_title'){{(!empty($data_arr['seo_title']) ? $data_arr['seo_title'] : '')}}@stop
@section('sidebar')
@parent
@endsection
@section('content')

<style type="text/css">
    .mid-content.after_login{padding-bottom:0;}
</style>

@if(Route::currentRouteName()=="home.guides")
<!--  Open Page code -->

<section class="row_dv inner_page_banner">
    <div class="search_bar neighbourhood_bnr">
        <div class="container">
            <div class="col-md-10 col-md-offset-1">
                <div class="row_dv">
                    <div class="fieldset_block">
                        <h1 class="banner_tiltle text-center">{!! (!empty($data_arr['title']) ? ucfirst($data_arr['title']) : '') !!}</h1>
                    </div>
                </div>
            </div>
        </div>
    </div>
    
    <img class="img-responsive banner_desktop" src="{{asset('front/images/neighbourhood_banner.jpg')}}" alt="{!! (!empty($data_arr['title']) ? ucfirst($data_arr['title']) : '') !!}">
    <img class="img-responsive banner_mobile" src="{{asset('front/images/neighbourhood_banner_mobile.jpg')}}" alt="{!! (!empty($data_arr['title']) ? ucfirst($data_arr['title']) : '') !!}">
</section>
@else
    <header class="row_dv content_page_header">
        <h1 class="term_head">{!! (!empty($data_arr['title']) ? ucfirst($data_arr['title']) : '') !!}</h1>
        <figure>
            <img class="banner_desktop" src="{!! !empty($data_arr['caption'])?asset('front/images/banner_'.$data_arr['caption'].'.jpg'):asset('front/images/banner_default.jpg') !!}" alt="{!! (!empty($data_arr['title']) ? ucfirst($data_arr['title']) : '') !!}">
            <img class="banner_mobile" src="{!! !empty($data_arr['caption'])?asset('front/images/banner_'.$data_arr['caption'].'_mobile.jpg'):asset('front/images/banner_default_mobile.jpg') !!}" alt="{!! (!empty($data_arr['title']) ? ucfirst($data_arr['title']) : '') !!}">
        </figure>
    </header>

@endif

   
{{--*/ $current_action = Route::currentRouteName() /*--}}




@if($current_action == 'home.howitwork')
    @include('home.howitwork')   
@else








<section class="row_dv white_body">
    <div class="container">
        <div class="row widgets_base">
            <div class="col-xs-12 col-sm-12 col-md-12">
                <div class="col-xs-12 pad_top content_page low_gap">
                    @if(Session::has('pagemsg'))
                        {!! Session::get('pagemsg') !!}
                    @endif
                    {!! !empty($data_arr['content'])? $data_arr['content'] : '' !!}
                </div>
            </div>
        </div>
    </div>
</section>
@endif


@endsection
