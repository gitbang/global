@extends('layouts.master')
@section('title', trans('seocontent.home_title'))
@section('meta_title', trans('seocontent.home_meta_title'))
@section('meta_description', trans('seocontent.home_desc'))
@section('sidebar')
@parent
@endsection
@section('content')




<section class="banner bid-detail-banner">
	<div class="banner-content">
		<div class="container">
            <h2 class="animated" data-animation="appeared fadeInUp" data-animation-delay="200">An Online Bidding Platform</h2>
            <h3 class="animated" data-animation="appeared fadeInUp" data-animation-delay="400"><span>For transacting the best </span>NEW HOMES <span> and </span> CONDOS <span> on the market </span></h3>          
		</div>
	</div>
</section>

<section class="bid-detail-page">
	<section class="place-bid-fixed">
		<div class="container">		
			<div class="row">
				<div class="col-md-10 col-md-offset-1 col-sm-12">
					<div class="time-head">
					 		<h4>Friday, October 7, 2017</h5>
					 		<h5>Start Time : 10 AM</h5>
					 		<h5>Planned End Time : 10:30 AM</h5>
					 </div>
					<div class="time-counter">
						
						  <div>
							<span class="minutes">58</span>
							<div class="smalltext">Minutes</div>
						  </div>
						  <div>
							<span class="seconds">57</span>
							<div class="smalltext">Seconds</div>
						  </div>
						  <div class="timer-alert">
						<span>57</span>
					</div>
					</div>
					<div class="place-bid-form">
						<form>
							<div class="form-group">
								<input type="text" name="" class="form-control" >
								<button class="bidBtn">PLACE BID</button>
							</div>
						</form>									
						<a href="" class="minus-btn"><span>-</span></a>
						<a href="" class="plus-btn"><span>+</span></a>
					</div>
				</div>
			</div>
		</div>
	</section>
	<div class="container">		
		<div class="row">
			<div class="col-md-10 col-md-offset-1 col-sm-12">	
				<h3 class="animated" data-animation="appeared fadeInUp" data-animation-delay="200">Bid Details</h3>
				<div class="clearfix"></div>
				<div class="time-head">
					 		<h4>Friday, October 7, 2017</h5>
					 		<h5>Start Time : 10 AM</h5>
					 		<h5>Planned End Time : 10:30 AM</h5>
					 	</div>
				<div class="time-counter">
					<div>
						<span class="minutes">58</span>
						<div class="smalltext">Minutes</div>
					</div>
					<div>
						<span class="seconds">57</span>
						<div class="smalltext">Seconds</div>
					</div>
					<div class="timer-alert">
						<span>57</span>
					</div>
				</div>
				<div class="place-bid-form" id="place-bid">
					<form>
						<div class="form-group">
							<input type="text" name="" class="form-control" >
							<button class="bidBtn">PLACE BID</button>
						</div>								
					</form>	
					<a href="" class="minus-btn"><span>-</span></a>
					<a href="" class="plus-btn"><span>+</span></a>
				</div>
				<div class="bid-detail-block">
					<div class="bid-left-content">
						<div class="property-pic">
							<figure>
								<img src="../front/images/property-img1.jpg" alt="" />
							</figure>
							<h4  class="animated" data-animation="appeared fadeInUp" data-animation-delay="300">660 Douglass Street...</h4>
							<h5  class="animated" data-animation="appeared fadeInUp" data-animation-delay="500">Noe Valley, San Francisco, California</h5>
						</div>
						<div class="bid-value">												
							<ul class="animated" data-animation="appeared fadeInUp" data-animation-delay="500">
								<li>Current Bid: <span>3,990,000</span></li>								
								<li>Min Bid Increment: <span>5,000</span></li>
								<li>Bid Status: <span>OutBid</span></li>
								<li>No. of Bid: <span>25</span></li>
								<li>Active Bid: <span>10</span></li>
							</ul>
						</div>
					</div>
					<div class="bid-history-content">
						<h4 class="history-heading animated" data-animation="appeared fadeInUp" data-animation-delay="100">History</h4>
						<div class="history-list animated" data-animation="appeared fadeInUp" data-animation-delay="400">
							<table>
								<tr>
									<th>Time</th>
									<th>Amount</th>
									<th>Bidder</th>
								</tr>
								<tr>
									<td><span class="date"><i class="fa fa-calendar" aria-hidden="true"></i>January 5, 2017</span><span class="time">12:45 PM</span></td>
									<td>3,990,000</td>
									<td>User 3</td>
								</tr>
								<tr>
									<td><span class="date"><i class="fa fa-calendar" aria-hidden="true"></i>January 5, 2017</span><span class="time">12:45 PM</span></td>
									<td>3,990,000</td>
									<td>User 3</td>
								</tr>
								<tr>
									<td><span class="date"><i class="fa fa-calendar" aria-hidden="true"></i>January 5, 2017</span><span class="time">12:45 PM</span></td>
									<td>3,990,000</td>
									<td>User 3</td>
								</tr>
								<tr>
									<td><span class="date"><i class="fa fa-calendar" aria-hidden="true"></i>January 5, 2017</span><span class="time">12:45 PM</span></td>
									<td>3,990,000</td>
									<td>User 3</td>
								</tr>
								<tr>
									<td><span class="date"><i class="fa fa-calendar" aria-hidden="true"></i>January 5, 2017</span><span class="time">12:45 PM</span></td>
									<td>3,990,000</td>
									<td>User 3</td>
								</tr>
								<tr>
									<td><span class="date"><i class="fa fa-calendar" aria-hidden="true"></i>January 5, 2017</span><span class="time">12:45 PM</span></td>
									<td>3,990,000</td>
									<td>User 3</td>
								</tr>
								<tr>
									<td><span class="date"><i class="fa fa-calendar" aria-hidden="true"></i>January 5, 2017</span><span class="time">12:45 PM</span></td>
									<td>3,990,000</td>
									<td>User 3</td>
								</tr>
								<tr>
									<td><span class="date"><i class="fa fa-calendar" aria-hidden="true"></i>January 5, 2017</span><span class="time">12:45 PM</span></td>
									<td>3,990,000</td>
									<td>User 3</td>
								</tr>
								<tr>
									<td><span class="date"><i class="fa fa-calendar" aria-hidden="true"></i>January 5, 2017</span><span class="time">12:45 PM</span></td>
									<td>3,990,000</td>
									<td>User 3</td>
								</tr>
								<tr>
									<td><span class="date"><i class="fa fa-calendar" aria-hidden="true"></i>January 5, 2017</span><span class="time">12:45 PM</span></td>
									<td>3,990,000</td>
									<td>User 3</td>
								</tr>
								<tr>
									<td><span class="date"><i class="fa fa-calendar" aria-hidden="true"></i>January 5, 2017</span><span class="time">12:45 PM</span></td>
									<td>3,990,000</td>
									<td>User 3</td>
								</tr>
								<tr>
									<td><span class="date"><i class="fa fa-calendar" aria-hidden="true"></i>January 5, 2017</span><span class="time">12:45 PM</span></td>
									<td>3,990,000</td>
									<td>User 3</td>
								</tr>
								<tr>
									<td><span class="date"><i class="fa fa-calendar" aria-hidden="true"></i>January 5, 2017</span><span class="time">12:45 PM</span></td>
									<td>3,990,000</td>
									<td>User 3</td>
								</tr>
							</table>
						</div>
					</div>
				</div>          
			</div>          
		</div>          
	</div>
</section>



@stop
@section('scriptinclude')


@stop
