<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="utf-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=0">
        <!-- The above 3 meta tags *must* come first in the head; any other head content must come *after* these tags -->
    	<link rel="icon" href="{{ asset('front/images/favicon.ico') }}" type="image/x-icon">        
        <title>Propbidder</title>
		<!-- font libray -->
		<link href="https://fonts.googleapis.com/css?family=Lato:300,400,700" rel="stylesheet">
		<link href="https://fonts.googleapis.com/css?family=Raleway:300,400,700" rel="stylesheet">
		
		<!-- css files -->
		<link rel="stylesheet" type="text/css" href="http://maxcdn.bootstrapcdn.com/font-awesome/4.5.0/css/font-awesome.min.css">
		<link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet" type="text/css" />
		<link rel="stylesheet" type="text/css" href="../front/css/style.css" />
		
		<!-- HTML5 Shim and Respond.js IE8 support of HTML5 elements and media queries -->
		<!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
		<!--about-us.html-->

		<!--[if lt IE 9]>
		<script src="https://oss.maxcdn.com/html5shiv/3.7.2/html5shiv.min.js"></script>
		<script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
		<![endif]-->


		<script>
		!function(f,b,e,v,n,t,s)
		{if(f.fbq)return;n=f.fbq=function(){n.callMethod?
		n.callMethod.apply(n,arguments):n.queue.push(arguments)};
		if(!f._fbq)f._fbq=n;n.push=n;n.loaded=!0;n.version='2.0';
		n.queue=[];t=b.createElement(e);t.async=!0;
		t.src=v;s=b.getElementsByTagName(e)[0];
		s.parentNode.insertBefore(t,s)}(window,document,'script',
		'https://connect.facebook.net/en_US/fbevents.js');
		 fbq('init', '286346641779600'); 
		fbq('track', 'PageView');
		</script>
		<noscript>
		 <img height="1" width="1" 
		src="https://www.facebook.com/tr?id=286346641779600&ev=PageView
		&noscript=1"/>
		</noscript>

		
    </head>
    <script type="text/javascript">    	
	  (function(i,s,o,g,r,a,m){i['GoogleAnalyticsObject']=r;i[r]=i[r]||function(){
	  (i[r].q=i[r].q||[]).push(arguments)},i[r].l=1*new Date();a=s.createElement(o),
	  m=s.getElementsByTagName(o)[0];a.async=1;a.src=g;m.parentNode.insertBefore(a,m)
	  })(window,document,'script','https://www.google-analytics.com/analytics.js','ga');

	  ga('create', 'UA-100555320-1', 'auto');
	  ga('send', 'pageview');
    </script>

    <style type="text/css">
    	.popUpBox.in .popup-container {
   				top: 5%;
   		}

   		.radio-inline, .checkbox-inline{    font: 300 14px/18px "Lato", sans-serif;    color: #424242;}
   		.error {font-size:12px;color:red;}
    </style>
    
<body>
<div class="wrapper">
	<!-- header start -->
	<!--header id="header">
		<div class="container-fluid">
			<div class="row">
				<div class="col-sm-3 col-xs-6">
					<h1><a href="#" class="logo"><img src="../front/images/logo.png" alt="logo" /></a></h1>
				</div>
				<div class="col-sm-9 col-xs-6">
					<nav class="header-menu">
						
						<ul class="nav-menu">
							<li><a href="#" class="active">Auctions<i class="fa fa-caret-down" aria-hidden="true"></i></a>
								<ul class="submenu">
									<li><a href="#">View All Auctions</a></li>
									<li><a href="#">Markets</a></li>
									<li><a href="#">Existing Homes</a></li>
									<li><a href="#">New Homes</a></li>
								</ul>
							</li>
							<li><a href="#">Sell</a></li>
							<li><a href="#">Buy</a></li>
							<li><a href="#">Calender</a></li>
							<li><a href="#">Blog</a></li>
							<li><a href="#">About Us<i class="fa fa-caret-down" aria-hidden="true"></i></a>
								<ul class="submenu">
									<li><a href="#">View All Auctions</a></li>
									<li><a href="#">Markets</a></li>
									<li><a href="#">Existing Homes</a></li>
									<li><a href="#">New Homes</a></li>
								</ul>
							</li>
						</ul>
						<div class="signUp">
							<ul>
								<li><a href="#" data-toggle="modal" data-target="#myModal"><i class="material-icons dp48">lock</i>Sign in</a>
									<ul class="submenu">
									<li><a href="#">View All Auctions</a></li>
									<li><a href="#">Markets</a></li>
									<li><a href="#">Existing Homes</a></li>
									<li><a href="#">New Homes</a></li>
								</ul>
								</li>
							</ul>
						</div>
					</nav>	
				</div>
			</div>
		</div>
	</header-->
	<!-- header end -->
	<div class="body-content">
		<!-- banner slider start -->
		<section class="banner engage-banner ">		
			<div class="home-page-slider">		
				<figure class="banner-img">
					<img src="../front/images/home-slide1.jpg" alt="logo" />
				</figure>
				<div class="banner-content text-center">
					<div class="container">
						<figure>
							<img src="../front/images/splash_logo.png" alt="logo" />
						</figure>
						<h2>Home Auctions</h2>
						<h3><span>For Mainstream</span> REAL ESTATE</h3>
						<h5>Coming SUMMER 2017</h5>
					</div>
				</div>
			</div>
		</section>
		<!-- banner slider end -->
		
		<!-- start register block -->
		<section class="register-here-block engage_block">
			<div class="container">
				<h3>ENGAGE NOW</h3>
				<ul class="registration-link">
					<li><a href="#" data-toggle="modal" class="model_load" data-target="#myModal1">Submit a Property Request</a></li>
					<li><a href="#" data-toggle="modal" class="model_load active" data-target="#myModal2">Register for Early Access</a></li>				
				</ul>
			</div>
		</section><!-- end register block -->
		
		<!-- start dreem home -->
		<section class="splash_about">
			<div class="container">
				<h3>ABOUT US</h3>
				<p class="icon_diamond">If you thought home auctions were just for distressed or ultra-luxury properties, THINK AGAIN!</p>
				<p class="icon_diamond">Propbidder is a disruptive online home auction marketplace for new and existing homes.</p>
				<p class="icon_diamond">We work with homebuilders and real estate agents to improve (not replace) the traditional sales process.<br/> For buyers, sellers, and other consumers, Propbidder is the dominant discovery and bidding platform for mainstream, non-distressed home auctions.</p>			
			</div>
		</section><!-- end dreem home -->


		<!-- start dreem home -->
		<section class="splash-serve">
			<div class="container">
				<h3>WHO WE SERVE</h3>
				<div class="row">
					<div class="col-xs-12 col-sm-4">
						<figure>
							<img src="../front/images/fig1.jpg " />
						</figure>
						<h4>Homebuilders</h4>
						<p>Efficient Price-Setting</p><p> Sustain Buyer Momentum</p><p> Facilitate Foreign Audiences</p>		
					</div>
					<div class="col-xs-12 col-sm-4">
						<figure>
							<img src="../front/images/fig2.jpg " />
						</figure>
						<h4>Agents & Brokers</h4>
						<p>Protect Commissions</p><p> Save Time on Negotiations</p><p> Capture Motivated Buyers & Sellers</p>				
					</div>
					<div class="col-xs-12 col-sm-4">
						<figure>
							<img src="../front/images/fig3.jpg " />
						</figure>
						<h4>Buyers & Sellers</h4>
						<p>Transact Faster</p><p> Increase Offer Transparency</p><p> Discover Best Homes on Market</p>			
					</div>
				</div>
			</div>
		</section><!-- end dreem home -->
	</div>
	<!-- footer start from here -->
	<footer id="footer" class="get-in-touch-footer">
		<div class="footer-menu">
			<div class="container">
				<div class="row">				
					<div class="col-xs-12">
						<div class="get-in-touch get-in-touch-splash">
							<h3>Get in Touch</h3>
							<ul>
								<li><a href="https://www.google.com/maps/place/Knight+Management+Center/@37.4281449,-122.1623136,15z/data=!4m2!3m1!1s0x0:0x18fe9f3c7b2c2106?sa=X&ved=0ahUKEwisrOTnsZnUAhUHllQKHXpkCPkQ_BIIgAEwCg" class="location-link" target="_new"><i class="fa fa-map-marker" aria-hidden="true"></i><span>Stanford, CA</span></a></li>
								<li>
									<a href="mailto:info@propbidder.com" class="mail-link"><i class="fa fa-envelope" aria-hidden="true"></i><span>mikael@propbidder.com</span></a>
								</li>
							</ul>						
						</div>
					</div>
				</div>
			</div>
		</div>
	</footer>	<!-- footer end here -->
</div>


<!-- popup start from here -->

<div class="modal fade popUpBox" id="myModal1" role="dialog">
    <div class="modal-dialog popup-container">    
		<!-- Modal content-->
		<div class="popup-content">
			<div class="right-content" style="width:auto;">
				<div class="form-heading">
					<h5>Submit a Property Request</h5>
					
				</div>
                @if(Session::has('registermsg'))
                    {!! Session::get('requestmsg') !!}
                @endif

                {!! Form::open(array('id'=>'request_form','route' => 'home.savesplashrequest', 'method' => 'post')) !!}  
                <div class="row">
                	<div class="col-sm-12">
	                    <div class="form-group">
	                        <label class="common-lable-style">Choose</label>
						    <label class="radio-inline">
						      <input type="radio" class="usertype" checked name="usertype" value="Homebuilder">Homebuilder
						    </label>
						    <label class="radio-inline">
						      <input type="radio" class="usertype" name="usertype" value="Agent">Agent
						    </label>
						    <label class="radio-inline">
						      <input type="radio" class="usertype" name="usertype" value="Seller">Seller
						    </label>					    						    
	                    </div>
                    </div> 

                	<div class="homebuilder">
	                	<div class="col-sm-12">
		                    <div class="form-group">
		                        <label class="common-lable-style">Homebuilder name</label>
		                        {!! Form::text('homebuilder_name',null,['id'=>'homebuilder_name','class'=>'form-control common-input-style']) !!}
		                    </div>
	                    </div>
                    </div>

                	<div class="agent hide">
	                	
	                	<div class="col-sm-6">
		                    <div class="form-group">
		                        <label class="common-lable-style">Brokerage name</label>
		                        {!! Form::text('brokerage_name',null,['id'=>'brokerage_name','class'=>'form-control common-input-style']) !!}
		                    </div>
	                    </div>

	                	<div class="col-sm-6">
		                    <div class="form-group">
		                        <label class="common-lable-style">Agent License number</label>
		                        {!! Form::text('agent_license_number',null,['id'=>'agent_license_number','class'=>'form-control common-input-style']) !!}
		                    </div>
	                    </div>	                    	                    
                    </div>

                	<div class="col-sm-6">
	                    <div class="form-group">
	                        <label class="common-lable-style">First Name</label>
	                        {!! Form::text('first_name',null,['id'=>'first_name','class'=>'form-control common-input-style']) !!}
	                    </div>
                    </div>

                    <div class="col-sm-6">
	                    <div class="form-group">
	                        <label class="common-lable-style">Last Name</label>
	                        {!! Form::text('last_name',null,['id'=>'last_name','class'=>'form-control common-input-style']) !!}
	                    </div>
                    </div>

                    <div class="col-sm-6">
	                    <div class="form-group">
	                        <label class="common-lable-style">Email</label>
	                        {!! Form::email('email',Cookie::get('email')?Cookie::get('email'):null,['id'=>'email','class'=>'form-control common-input-style']) !!}
	                    </div>
                    </div>

                    <div class="col-sm-6">
	                    <div class="form-group">
	                        <label class="common-lable-style">Contact Number</label>
	                        
	                        {!! Form::text('contact_number',null,['id'=>'contact_number','class'=>'form-control common-input-style'])!!}  
	                    </div>     
                    </div>

                    <div class="col-sm-6">
	                    <div class="form-group">
	                        <label class="common-lable-style">Provide a link to your property's website</label>
	                        
	                        {!! Form::text('website',null,['id'=>'website','class'=>'form-control common-input-style'])!!}  
	                    </div>     
                    </div>

                	<div class="col-sm-6">
	                    <div class="form-group">
	                        <label class="common-lable-style">Choose</label>
						    <label class="radio-inline">
						      <input type="radio" name="request_type" checked value="New Home">New Home
						    </label>
						    <label class="radio-inline">
						      <input type="radio" name="request_type" value="Existing Home">Existing Home
						    </label>				    						    
	                    </div>
                    </div> 

                    <div class="col-sm-12">
	                    <div class="form-group">
	                        <label class="common-lable-style">Property Address</label>
	                        
	                        {!! Form::textarea('address',null,['id'=>'address','class'=>'form-control common-input-style',"rows"=>3])!!}  
	                    </div>     
                    </div>

                    <div class="col-sm-6">
	                    <div class="form-group">
	                        <label class="common-lable-style">Estimated Value or Current Offer Price</label>
	                        
	                        {!! Form::text('price',null,['id'=>'price','class'=>'form-control common-input-style'])!!}  
	                    </div>     
                    </div>

                    <div class="col-sm-6">
	                    <div class="form-group">
	                        <label class="common-lable-style">Desired # of buyers/bidders</label>
	                        
	                        {!! Form::text('desired',null,['id'=>'desired','class'=>'form-control common-input-style'])!!}  
	                    </div>     
                    </div>

                    <div class="col-sm-12">

                    <div class="form-group">
                        <label class="common-lable-style">Message</label>
                        
                        {!! Form::textarea('cmessage',null,['id'=>'cmessage','class'=>'form-control common-input-style',"rows"=>3])!!}  
                    </div>
               		</div>

               		<div class="col-sm-12">
                    <div class="form-group btn-block">
                        <button>SUBMIT</button>
                         
                        </div>
                    </div>
                    </div></form>
			</div>
			<button type="button" class="close-popup" data-dismiss="modal">&times;</button>
		</div>   
		
	</div>
</div>


<div class="modal fade popUpBox" id="myModal2" role="dialog">
    <div class="modal-dialog popup-container">    
		<!-- Modal content-->
		<div class="popup-content">

			<div class="right-content" style="width:auto;">
				<div class="form-heading">
					<h5>Register for Early Access</h5>
					
				</div>
                @if(Session::has('registermsg'))
                    {!! Session::get('registermsg') !!}
                @endif

                {!! Form::open(array('id'=>'register_form','route' => 'home.savesplashregister', 'method' => 'post')) !!}  
                <div class="row">
                	<div class="col-sm-12">
	                    <div class="form-group">
	                        <label class="common-lable-style">Choose</label>
						    <label class="radio-inline">
						      <input type="radio" value="Homebuilder" checked name="usertype">Homebuilder
						    </label>
						    <label class="radio-inline">
						      <input type="radio" value="Agent" name="usertype">Agent
						    </label>
						    <label class="radio-inline">
						      <input type="radio" value="Buyer" name="usertype">Buyer
						    </label>
						    <label class="radio-inline">
						      <input type="radio" value="Seller" name="usertype">Seller
						    </label>
						    <label class="radio-inline">
						      <input type="radio" value="Interested Consumer" name="usertype">Interested Consumer
						    </label>						    						    
	                    </div>
                    </div> 
                	
                	<div class="homebuilder">
	                	<div class="col-sm-12">
		                    <div class="form-group">
		                        <label class="common-lable-style">Homebuilder name</label>
		                        {!! Form::text('homebuilder_name',null,['id'=>'homebuilder_name','class'=>'form-control common-input-style']) !!}
		                    </div>
	                    </div>
                    </div>

                	<div class="agent hide">
	                	
	                	<div class="col-sm-6">
		                    <div class="form-group">
		                        <label class="common-lable-style">Brokerage name</label>
		                        {!! Form::text('brokerage_name',null,['id'=>'brokerage_name','class'=>'form-control common-input-style']) !!}
		                    </div>
	                    </div>

	                	<div class="col-sm-6">
		                    <div class="form-group">
		                        <label class="common-lable-style">Agent License number</label>
		                        {!! Form::text('agent_license_number',null,['id'=>'agent_license_number','class'=>'form-control common-input-style']) !!}
		                    </div>
	                    </div>	                    	                    
                    </div>


                	<div class="col-sm-6">
	                    <div class="form-group">
	                        <label class="common-lable-style">First Name</label>
	                        {!! Form::text('first_name',null,['id'=>'first_name','class'=>'form-control common-input-style']) !!}
	                    </div>
                    </div>

                    <div class="col-sm-6">
	                    <div class="form-group">
	                        <label class="common-lable-style">Last Name</label>
	                        {!! Form::text('last_name',null,['id'=>'last_name','class'=>'form-control common-input-style']) !!}
	                    </div>
                    </div>

                    <div class="col-sm-6">
	                    <div class="form-group">
	                        <label class="common-lable-style">Email</label>
	                        {!! Form::email('email',Cookie::get('email')?Cookie::get('email'):null,['id'=>'email','class'=>'form-control common-input-style']) !!}
	                    </div>
                    </div>

                    <div class="col-sm-6">
	                    <div class="form-group">
	                        <label class="common-lable-style">Contact Number</label>
	                        
	                        {!! Form::text('contact_number',null,['id'=>'contact_number','class'=>'form-control common-input-style'])!!}  
	                    </div>     
                    </div>
                    

               		<div class="col-sm-12">
                    <div class="form-group btn-block">
                        <button>REGISTER</button>
                         
                        
                    </div>
                    </div>
                    </div>
                </form>    
			</div>
			<button type="button" class="close-popup" data-dismiss="modal">&times;</button>
		</div>   
		
	</div>
</div>

<script src="http://ajax.googleapis.com/ajax/libs/jquery/1.10.2/jquery.min.js"></script>
<script src="../front/js/bootstrap.min.js"></script>
<script src="{{ asset('front/js/jquery.validate.js') }}"></script>
<script src="{{ asset('common/jquery.blockUI.js') }}"></script>
<script src="{{ asset('common/jqueryvalidation.js') }}"></script>
<script src="../front/js/custom.js"></script>
<script>
	console.log("sdsdfsdfsdf")
    $("#register_form").validate({
        wrapper: "p",
        errorElement: "span",
        rules: {
            first_name: {
                required: true,
            },
            last_name: {
                required: true,
            },
            email: {
                required: true,
                email: true,
            },
            contact_number: {
                required: true
            },/*
            cmessage: {
                required: true
            }*/                        
        }
    });


    $("#request_form").validate({
        wrapper: "p",
        errorElement: "span",
        rules: {
            first_name: {
                required: true,
            },
            last_name: {
                required: true,
            },
            email: {
                required: true,
                email: true,
            },
            contact_number: {
                required: true
            },
            cmessage: {
                required: true
            },
            website: {
                required: true
            },
            desired: {
                required: true,
                number : true
            },
            address: {
                required: true
            }, 
            price: {
                required: true,
                number : true
            },                                                                              
        }
    });

$("input:radio[name=usertype]").click(function() {
    var value = $(this).val();
    if(value == "Homebuilder"){
    	$(".homebuilder").removeClass("hide")
    	$(".agent").addClass("hide")
    }
    else if(value == "Agent"){
    	$(".homebuilder").addClass("hide")
    	$(".agent").removeClass("hide")
    }else{
    	$(".homebuilder").addClass("hide")
    	$(".agent").addClass("hide")    	
    }
});
<?php if (Session::has('name')) : ?>
                    $("#" + "{!! Session::get('name') !!}").modal('show')
    <?php Session::forget('name');
elseif (isset($name)):
    ?>
                    $("#" + '{!! $name !!}').modal('show')
<?php endif; ?>    
</script>
</body> 
</html>   
