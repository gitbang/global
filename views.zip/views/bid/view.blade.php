@extends('layouts.master')
@section('title', trans('seocontent.home_title'))
@section('meta_title', trans('seocontent.home_meta_title'))
@section('meta_description', trans('seocontent.home_desc'))
@section('sidebar')
@parent
@endsection
@section('content')


<?php 
    $constantDataFile = Config::get('constants');
    $constantUrlFile = Config::get('constantsUrl');
    $logged_in = (!empty($auth_user))?$auth_user["id"]:"";
?>

<!--section class="banner bid-detail-banner">
	<div class="banner-content">
		<div class="container">
		   <h2 class="animated" data-animation="appeared fadeInUp" data-animation-delay="200">Online Bidding</h2>
			<h3 class="animated" data-animation="appeared fadeInUp" data-animation-delay="400"><span>To transact the best </span>NEW HOMES <span> and </span> CONDOS <span> on market</h3>         
		</div>
	</div>
</section-->
<section class="bid-detail-page">
	<div class="container">
		<h3 class="animated" data-animation="appeared fadeInUp" data-animation-delay="200">Bid Details</h3>
		<div class="bid-detail-block">


		@if(isset($errormsg) && !empty($errormsg))
			{!! $errormsg !!}
		@else
			<div class="bid-detail-block">
				<div class="bid-left-content">
                <div id="msg_section"></div>
                


                        <div class="property-pic">
                            <figure>
                                <img src="{!! !empty($bidDetail['property_image']) ? asset(Config::get('constantsUrl.apiurlmediaUrl').$bidDetail['property_image']) : asset('front/images/map-building1.jpg'); !!}"" alt="" />
                            </figure>
                            <h4  class="animated" data-animation="appeared fadeInUp" data-animation-delay="300">{{ $bidDetail['name'] }}</h4>
                            <h5  class="animated" data-animation="appeared fadeInUp" data-animation-delay="500">{!! (!empty($bidDetail['address']['house_num']) && $bidDetail['address']['house_num']!="")?$bidDetail['address']['house_num']." ":'' !!}{!! !empty($bidDetail['address']['street'])?$bidDetail['address']['street'].", ":'' !!}{{--*/ $addComb =makeAddress("",!empty($bidDetail['address']['city_name'])?$bidDetail['address']['city_name']:'',!empty($bidDetail['address']['state_code'])?$bidDetail['address']['state_code']:'')/*--}}
                                                        {{ $addComb }}</h5>
                        </div>
                        <div class="bid-value">
   
                                           
                            <ul class="animated" data-animation="appeared fadeInUp" data-animation-delay="500">
                                <li>Current Bid: <span id="bid_current">{!! (isset($bidDetail['current_bid']) && $bidDetail['current_bid']!=0) ? "$ ". addSeprator($bidDetail['current_bid']) :"N/A" !!}</span></li>
                                <!--li>Next Bid: <span id="bid_next">${!! addSeprator($bidDetail['current_bid'] + $bidDetail['bid_increment']) !!}</span></li-->
                                <li>
                                    Min Bid Increment: <span>${!! isset($bidDetail['bid_increment']) ? addSeprator($bidDetail['bid_increment']) :"" !!}
                                    </span>
                                </li>
                                
                                <li>Bid Status: <span id="bid_status">{{ @$constantDataFile['BID_STATUS'][$bidDetail['bid_status']] }}</span></li>
                                <li>No. of Bidders: <span>{{ isset($bidDetail['bidder_count'])?$bidDetail['bidder_count']:'' }}</span></li>
                                <li>Active Bids: <span id="bid_count">{!! isset($bidDetail['bid_count']) ? $bidDetail['bid_count'] :"" !!}</span></li>
                            </ul>
                        </div>    
			<div class="bid-history-content">
				<h4 class="history-heading animated" data-animation="appeared fadeInUp" data-animation-delay="100">History</h4>
				<div id="bid_history" class="history-list animated" data-animation="appeared fadeInUp" data-animation-delay="400">
					<table>
						<tr>
							<th>Time</th>
							<th>Amount</th>
							<th>Bidder</th>
						</tr>
                        
                        @if(!empty($bidDetail["bid"]))
                            @foreach($bidDetail["bid"] as $bid)
                            <tr>
                                <td><span class="date"><i class="fa fa-calendar" aria-hidden="true"></i>{{ date("F j,Y",strtotime($bid['created_date'])) }}</span><span class="time">{{ date("G:i A",strtotime($bid['created_date'])) }}</span></td>
                                <td>${{ addSeprator($bid['amount']) }}</td>
                                <td>
                                    @if($logged_in==$bid['user'])
                                        Myself
                                    @else
                                        User {{ $bid['user'] }}
                                    @endif    
                                </td>
                            </tr>                      
                            @endforeach
                        @else
                        <tr style="height: 300px;text-align: center;">
                            <td colspan="3">No Bid found</td>
                        </tr>
                        @endif
					</table>
				</div>
			</div>
		@endif	
		</div>  
		</div>        
	</div>
</section>



@stop
@section('scriptinclude')


@stop
