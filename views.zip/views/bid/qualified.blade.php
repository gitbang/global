            <form id="bid_form" name="bid_form" action="{{ URL::route('bid.editbidregistration') }}" method="POST" enctype='multipart/form-data'>

                <input type="hidden" id="_token" name="_token" value="{{ csrf_token() }}">
                <h4>Buyer Information</h4>

                <div class="buyar-info gray-bg">
                    <div class="row">
                        <div class="col-sm-6 col-xs-12 padding-right">
                            <div class="form-group ">
                                <label>Registrant Name<sup>*</sup></label>
                                {!! Form::text('registrant_name',$bidDetail['registrant_name'],['class'=>'form-control',"disabled"=>true,"id"=>"registrant_name"] ) !!}
                            </div>
                        </div>
                        <div class="col-sm-6 col-xs-12 padding-left">
                            <div class="form-group" >
                                <label>Buyer Name (if different)</label>
                                {!! Form::text('name',$bidDetail['name'], ['class'=>'form-control',"disabled"=>true,"id"=>"name"] ) !!}
                            </div>
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-sm-6 col-xs-12 padding-right">
                            <div class="form-group">
                                <label>Email<sup>*</sup></label>
                                {!! Form::text('email',$bidDetail['email'], ['class'=>'form-control',"disabled"=>true,"id"=>"email"] ) !!}
                            </div>
                        </div>
                        <div class="col-sm-6 col-xs-12 padding-left">
                            <div class="form-group">
                                <label>Mobile Number<sup>*</sup></label>
                                {!! Form::text('contact_number',$bidDetail['contact_number'], ['class'=>'form-control',"disabled"=>true,"id"=>"contact_number"] ) !!}
                            </div>
                        </div>
                    </div>  
                    <div class="row">
                        <div class="col-sm-6 col-xs-12 padding-right">
                            <div class="form-group">
                                <label>Office Number</label>
                                {!! Form::text('office_number',$bidDetail['office_number'], ['class'=>'form-control',"disabled"=>true,"id"=>"office_number"] ) !!}
                            </div>
                        </div>
                        <div class="col-sm-6 col-xs-12 padding-left">
                            <div class="form-group">
                                <label>Extension</label>
                                {!! Form::text('extension',$bidDetail['extension'], ['class'=>'form-control',"disabled"=>true,"id"=>"extension"] ) !!}
                            </div>
                        </div>
                    </div>  
                    <div class="row">
                        <div class="col-sm-6 col-xs-12 padding-right">
                            <div class="form-group">
                                <label>Address Line 1<sup>*</sup></label>
                                {!! Form::text('addressline',$bidDetail['addressline'], ['class'=>'form-control',"disabled"=>true,"id"=>"addressline"] ) !!}
                            </div>
                        </div>
                        <div class="col-sm-6 col-xs-12 padding-left">
                            <div class="form-group">
                                <label>Address Line 2</label>
                                {!! Form::text('addressline2',$bidDetail['addressline2'], ['class'=>'form-control',"disabled"=>true,"id"=>"addressline2"] ) !!}
                            </div>
                        </div>
                    </div>

                    <div class="row">
                        <div class="col-sm-6 col-xs-12 padding-right">
                            <div class="form-group">
                                <label>Country<sup>*</sup></label>
                                {!! Form::select('country',[''=>'Please Select']+$country_list,$bidDetail['country'], ["class"=> "form-control","disabled"=>true,"id"=>"country"] ) !!}
                            </div>
                        </div>
                        <div class="col-sm-6 col-xs-12 padding-left">
                            <div class="form-group">
                                <label>State<sup>*</sup></label>
                                {!! Form::select('state',[''=>'Please Select']+$state_list,$bidDetail['state'], ["class"=> "form-control","disabled"=>true,"id"=>"state"] ) !!}
                            </div>
                        </div>
                    </div>

                    <div class="row">
                        <div class="col-sm-6 col-xs-12 padding-right">
                            <div class="form-group">
                                <label>City<sup>*</sup></label>
                                {!! Form::text('city',$bidDetail['city_name'], ['class'=>'form-control',"disabled"=>true,"id"=>"city"] ) !!} 
                            </div>
                        </div>
                        <div class="col-sm-6 col-xs-12 padding-left">
                            <div class="form-group">
                                <label>Zip Code<sup>*</sup></label>
                                {!! Form::text('zipcode',$bidDetail['zipcode'], ['class'=>'form-control',"disabled"=>true,"id"=>"zipcode"] ) !!}
                            </div>
                        </div>
                    </div>

                                        
                </div>

                <h4 class="animated" data-animation="appeared fadeInUp" data-animation-delay="400">Agent Information</h4>
                <div class="purchase-info gray-bg autobids-block">
                    <div class="row">

                        <div class="col-md-6 col-sm-12 col-xs-12 padding-right">
                            <div class="form-group check-label animated" data-animation="appeared fadeInDown" data-animation-delay="300">
                                <label>Are you working with an agent? </label>
                                {!! Form::checkbox('is_agent',1,$bidDetail['is_agent'],['class'=>'',"disabled"=>true,"id"=>"is_agent"] ) !!}
                            </div>
                        </div> 

                        @if(isset($bidDetail['is_agent']) && $bidDetail['is_agent']=="1")
                            <div class="col-sm-6 col-xs-12 padding-left agent_section ">
                                <div class="form-group animated" data-animation="appeared fadeInDown" data-animation-delay="300">
                                    <label> Name of Agent <sup>*</sup></label>
                                    {!! Form::text('agent_name',$bidDetail['agent_name'], ['class'=>'form-control',"disabled"=>true,"id"=>"agent_name"] ) !!}
                                </div>
                            </div>
                        @endif

                    </div>

                    @if(isset($bidDetail['is_agent']) && $bidDetail['is_agent']=="1")
                    <div class="row agent_section">
                        <div class="col-sm-6 col-xs-12 padding-right">
                            <div class="form-group animated" data-animation="appeared fadeInDown" data-animation-delay="800">
                                <label>Email of Agent<sup>*</sup></label>
                                {!! Form::text('agent_email',$bidDetail['agent_email'], ['class'=>'form-control',"disabled"=>true,"id"=>"agent_email"] ) !!}
                            </div>
                        </div>
                        <div class="col-sm-6 col-xs-12 padding-left">
                            <div class="form-group animated" data-animation="appeared fadeInDown" data-animation-delay="800">
                                <label>License #</label>
                                {!! Form::text('license_number',$bidDetail['license_number'], ['class'=>'form-control',"disabled"=>true,"id"=>"license_number"] ) !!}
                            </div>
                        </div>                         
                    </div>                            
                    @endif
                   
                </div>   

                <h4>Property to bid</h4>
                <?php 
                    $amount = 0;
                    $bidamount = 0;
                    $property_arr = array();
                    if(!empty($bidDetail['bid_detail'])){
                        foreach($bidDetail['bid_detail'] as $val){
                            $amount = $val['amount'];
                            $bidamount = $val['auto_bid_amount'];
                            $property_arr[$val['prop']] = $val['prop'];
                        }
                    }

                ?>
                <div class="purchase-info gray-bg property-info-block">
                    <div class="row">
                        <div class="col-xs-12">
                            <div class="form-group multiselectOption">
                                <label>Property </label>
                               
                                                                 
                                <?php  
                                    $propObj = array();
                                    if(!empty($bid_property)){
                                        foreach($bid_property as $val){
                                            if($prop_id==$val["id"]){
                                                $propObj = $val;
                                                break;
                                            }
                                        }
                                        
                                    }
                                ?>
                                
                                <p>
                                    {{ @$propObj['name'] }}
                                </p>
                               
                            </div>
                        </div>                              
                    </div>
                </div>     
                
                <h4>My Autobid Preferences</h4>
                <div class="purchase-info gray-bg autobids-block">
                    <div class="row">

                        <div class="col-md-6 col-sm-12 col-xs-12 padding-right">
                            <div class="form-group check-label animated" data-animation="appeared fadeInDown" data-animation-delay="300">
                                <label>I would like to elect Autobid </label>
                                {!! Form::checkbox('auto_bid_allowed',"1",$bidDetail['auto_bid_allowed'], ['class'=>'',"disabled"=>true,"id"=>"auto_bid_allowed"]) !!}
                            </div>
                        </div> 

                    </div>


                    @if(isset($bidDetail['auto_bid_allowed']) && $bidDetail['auto_bid_allowed']=="1")
                    <div class="row">
                        <div id="auto_bid_section" class="col-md-6 col-sm-12 col-xs-12 padding-right">
                            <div class="form-group animated" data-animation="appeared fadeInDown" data-animation-delay="300">
                                <label class="add-autobid"> I would like to add Autobids </label>
                                {!! Form::text('auto_bid_amount',"$".addSeprator($bidamount), ['class'=>'form-control',"disabled"=>true,"id"=>"auto_bid_amount"] ) !!}
                            </div>
                        </div> 

                        <div class="col-md-6 col-sm-12 col-xs-12 padding-right">
                            <div class="form-group animated" data-animation="appeared fadeInDown" data-animation-delay="300">
                                <label class="allow-autobid">
                                    Note : 
                                        Autobids allow you to bid automatically upto this amount 
                                        <!--li> AutoBid increment by $1,000 at each automatic bid </li-->
                                </label>
                                
                            </div>
                        </div> 

                    </div> 
                    @endif                          
                   
                </div> 
                <input type="hidden" id="minprice" value="{{ @$propObj['price'] }}"></input>
                <h4>Pre Qualification & Proof of funds</h4>
                <div class="funds-info gray-bg">

                        <div class="row">
                            <div class="col-sm-12 col-xs-12">
                                <div class="alert-success pre-qulialert">
                                    <p>
                                        <i class="fa fa-check-circle fa-2x" aria-hidden="true"></i>   
                                        You are already Pre Qualified
                                    </p>
                                </div>
                            </div>  
                        </div>    

                        <div class="row">
                            <div class="col-md-6 col-sm-12 col-xs-12 padding-right">
                                <div class="form-group">
                                    <label>Requested Bid Limit<sup>*</sup></label>
                                    {!! Form::text('amount',"$".addSeprator($amount), ['class'=>'form-control',"disabled"=>true,"id"=>"amount"] ) !!}
                                </div>
                            </div>  

                        </div>



                        <div class="row">
                            <div class="col-sm-12 col-xs-12">
                                <p>Please provide proof of funds or a bank financing letter to demonstrate your ability to bid up to your requested limit.</p>
                            </div>

                            <div>
                                @if(!empty($bidDetail['document']))
                                    @foreach($bidDetail['document'] as $val)
                                    <div id="documentlist{{ $val['id'] }}" style="margin: 5px 0;float: left;width: 100%;" class="">
                                        <div class="col-md-6 col-sm-12 col-xs-12 padding-right">                                    

                                            <label class="bank-statement">
                                                @if($val['file']!="")
                                                    <a href="{{ asset(Config::get('constantsUrl.apiurlmediaUrl')).$val['file'] }}" target="_blank">{{ $constantDataFile['DOCUMENT_LIST'][$val["document_type"]] }}</a>
                                                @else
                                                    {{ $constantDataFile['DOCUMENT_LIST'][$val["document_type"]] }}
                                                @endif
                                            </label>
                                            
                                        </div>      
                                        <div class="col-md-6 col-sm-12 col-xs-12 padding-left add-row"> 
                                            <div class="brouse-file choose-file">
                                               <label for="document_file"><span>

                                               </span></label>
                                              
                                            </div>
                                                                      
                                        </div>                 
                                    </div>        
                                    @endforeach
                                @endif   

                                    

                            </div>
                        </div>
                        <div class="row">
                            <div class="col-sm-12 col-xs-12 text-center">
                                <div class="btn-block">
                                    <a href="{!! URL::to('/property') !!}/{{ $prop_id }}" class="btn submitBtn explore-pro">Explore Property</a>
                                    <a href="{{ URL::to('user/auction') }}" class="btn submitBtn">My Bids</a>
                                </div>
                            </div>
                        </div>                                          

                </div>
                
            </form>