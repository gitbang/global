@extends('layouts.master')
@section('title', trans('seocontent.home_title'))
@section('meta_title', trans('seocontent.home_meta_title'))
@section('meta_description', trans('seocontent.home_desc'))
@section('sidebar')
@parent
@endsection
@section('content')

<style>
    .inactiveLink {
        pointer-events: none;
        cursor: default;
        opacity : 0.3;
    }

    .finalalert{
        border: 0;
        border-radius: 0;
        padding: 15px;
        margin-bottom: 20px;
    }
</style>
<?php 
    $constantDataFile = Config::get('constants');
    $constantUrlFile = Config::get('constantsUrl');
?>

<!--<section class="banner bid-detail-banner">
	<div class="banner-content">
		<div class="container">
		   <h2 class="animated" data-animation="appeared fadeInUp" data-animation-delay="200">Online Bidding</h2>
			<h3 class="animated" data-animation="appeared fadeInUp" data-animation-delay="400"><span>To transact the best </span>NEW HOMES <span> and </span> CONDOS <span> on market</h3>         
		</div>
	</div>
</section>-->
<section class="bid-detail-page">
    @if($bidDetail['bid_status']!="2")
    <section class="place-bid-fixed bidsection">
        <div class="container">     
            <div class="row">
                
                <div class="col-md-10 col-md-offset-1 col-sm-12"> 
                    <div class="msg_section"></div>
                    <div class="time-head">

                            <h4>{{ getLocalizeDateTimes($bidDetail['bid_start_at'],"l, F d, Y ") }} </h5>
                            <h5>Start Time : {{ getLocalizeDateTimes($bidDetail['bid_start_at'],"h:i A") }}</h5>
                            <h5>Planned End Time : {{ getLocalizeDateTimes(date("Y-m-d H:i:s",strtotime("+30 minutes",strtotime($bidDetail['bid_start_at']))),"h:i A") }}</h5>
                     </div>
                    <div class="time-counter">
                        
                          <div>
                            <span class="minutes">00</span>
                            <div class="smalltext">Minutes</div>
                          </div>
                          <div>
                            <span class="seconds">00</span>
                            <div class="smalltext">Seconds</div>
                          </div>

                          
                    </div>                  

                    <div class="place-bid-form">
                            <form class="form_bid">
                                <div class="form-group">
                                    <input type="text" id="bidamount" name="amount" class="form-control bidamount" value="${{ (isset($bidDetail['current_bid']) && $bidDetail['current_bid']!='0')?addSeprator($bidDetail['current_bid'] + $bidDetail['bid_increment']):addSeprator($bidDetail['price']) }}">
                                    <input type="hidden" id="bid_increment_amount" value="{!! isset($bidDetail['bid_increment']) ? $bidDetail['bid_increment'] :"" !!}"></input>
                                    <input type="hidden" id="bid_current_amount" value="{{ (isset($bidDetail['current_bid']) && $bidDetail['current_bid']!='0')?$bidDetail['current_bid'] + $bidDetail['bid_increment']:$bidDetail['price'] }}"></input>
                                    <button id="bid_save" class="bidBtn">PLACE BID</button>
                                </div>
                            </form>                              
                                <a href="" class="inactiveLink minus-btn"><span>-</span></a>
                                <a href="" class="plus-btn"><span>+</span></a>
                    </div>
                        
                </div>
            </div>
        </h4>    
    </section>
    @endif
	<div class="container">
        <div class="row">
            <div class="col-md-10 col-md-offset-1 col-sm-12">
    		  <h3 class="animated" data-animation="appeared fadeInUp" data-animation-delay="200">Bid Details</h3>
                <div class="clearfix"></div>
                @if($bidDetail['bid_status']!="2")
                <div class="time-head bidsection">
                            <h4>{{ getLocalizeDateTimes($bidDetail['bid_start_at'],"l, F d, Y ") }} </h5>
                            <h5>Start Time : {{ getLocalizeDateTimes($bidDetail['bid_start_at'],"h:i A") }}</h5>
                            <h5>Planned End Time : {{ getLocalizeDateTimes(date("Y-m-d H:i:s",strtotime("+30 minutes",strtotime($bidDetail['bid_start_at']))),"h:i A") }}</h5>
                        </div>
                <div class="time-counter bidsection">

                      <div>
                        <span class="minutes">00</span>
                        <div class="smalltext">Minutes</div>
                      </div>
                      <div>
                        <span class="seconds">00</span>
                        <div class="smalltext">Seconds</div>
                      </div>                  
                </div>

                <div class="place-bid-form bidsection" id="place-bid">
                    
                   
                        <form class="form_bid">
                            <div class="form-group">
                                <input type="text" id="bidamount" name="amount" class="form-control bidamount" value="${{ (isset($bidDetail['current_bid']) && $bidDetail['current_bid']!='0')?addSeprator($bidDetail['current_bid'] + $bidDetail['bid_increment']):addSeprator($bidDetail['price']) }}">
                                <input type="hidden" id="bid_increment_amount" value="{!! isset($bidDetail['bid_increment']) ? $bidDetail['bid_increment'] :"" !!}"></input>
                                <input type="hidden" id="bid_current_amount" value="{{ (isset($bidDetail['current_bid']) && $bidDetail['current_bid']!='0')?$bidDetail['current_bid'] + $bidDetail['bid_increment']:$bidDetail['price'] }}"></input>
                                <button id="bid_save" class="bidBtn">PLACE BID</button>
                            </div>
                        </form>
                   
                    <a href="" class="inactiveLink minus-btn"><span>-</span></a>
                    <a href="" class="plus-btn"><span>+</span></a>
                </div>  
                 @endif                
		<div class="bid-detail-block">

			<div class="bid-left-content">
                        <div class="msg_section"></div>
                        <div class="property-pic">
                            <figure>
                                <img src="{!! !empty($bidDetail['property_image']) ? asset(Config::get('constantsUrl.apiurlmediaUrl').$bidDetail['property_image']) : asset('front/images/map-building1.jpg'); !!}"" alt="" />
                            </figure>
                            <h4  class="animated" data-animation="appeared fadeInUp" data-animation-delay="300">{{ $bidDetail['name'] }}</h4>
                            <h5  class="animated" data-animation="appeared fadeInUp" data-animation-delay="500">{!! (!empty($bidDetail['address']['house_num']) && $bidDetail['address']['house_num']!="")?$bidDetail['address']['house_num']." ":'' !!}{!! !empty($bidDetail['address']['street'])?$bidDetail['address']['street'].", ":'' !!}{{--*/ $addComb =makeAddress("",!empty($bidDetail['address']['city_name'])?$bidDetail['address']['city_name']:'',!empty($bidDetail['address']['state_code'])?$bidDetail['address']['state_code']:'')/*--}}
                                                        {{ $addComb }}</h5>
                        </div>
                        <div class="bid-value">
   
                                           
                            <ul class="animated" data-animation="appeared fadeInUp" data-animation-delay="500">
                            
                                <li>Next Allowable Min Bid: <span id="next_allowable_bid">${{ (isset($bidDetail['current_bid']) && $bidDetail['current_bid']!='0')?addSeprator($bidDetail['current_bid'] + $bidDetail['bid_increment']):addSeprator($bidDetail['price']) }}</span></li>                            
                                <li>Current Bid: <span id="bid_current">{!! (isset($bidDetail['current_bid']) && $bidDetail['current_bid']!=0) ? "$ ". addSeprator($bidDetail['current_bid']) :"N/A" !!}</span></li>
                                <!--li>Next Bid: <span id="bid_next">${!! addSeprator($bidDetail['current_bid'] + $bidDetail['bid_increment']) !!}</span></li-->
                                <li>
                                    Min Bid Increment: <span>${!! isset($bidDetail['bid_increment']) ? addSeprator($bidDetail['bid_increment']) :"" !!}
                                    </span>
                                </li>
                                <li>My Max Allowable Bid: <span>${!! addSeprator($bidDetail['bid_max_amount']) !!}</span></li>
                                
                                @if(isset($bidDetail['bidlimit']) && $bidDetail['bidlimit']!=0)
                                    <li>My Autobid Limit: <span>${!! addSeprator($bidDetail['bidlimit']) !!}</span></li>
                                @endif

                                <li>Bid Status: <span id="bid_status">{{ @$constantDataFile['BID_STATUS'][$bidDetail['bid_status']] }}</span></li>
                                <li>No. of Bidders: <span>{{ isset($bidDetail['bidder_count'])?$bidDetail['bidder_count']:'' }}</span></li>
                                <li>Active Bids: <span id="bid_count">{!! isset($bidDetail['bid_count']) ? $bidDetail['bid_count'] :"" !!}</span></li>
                            </ul>
                        </div>                

                <input type="hidden" id="bid_minimum_amount" value="{!! $bidDetail['price'] !!}"></input>
                <input type="hidden" id="bid_max_amount" value="{!! $bidDetail['bid_max_amount'] !!}"></input>
                <input type="hidden" id="bid_next" value="${{ (isset($bidDetail['current_bid']) && $bidDetail['current_bid']!='0')?addSeprator($bidDetail['current_bid'] + $bidDetail['bid_increment']):addSeprator($bidDetail['price']) }}"></input>
				
                <input type="hidden" id="lastbid" value="${!! addSeprator($bidDetail['lastbid']) !!}"></input>
			</div>
			<div class="bid-history-content">
				<h4 class="history-heading animated" data-animation="appeared fadeInUp" data-animation-delay="100">History</h4>
				<div id="bid_history" class="history-list animated" data-animation="appeared fadeInUp" data-animation-delay="400">
					<table>
						<tr>
							<th>Time</th>
							<th>Amount</th>
							<th>Bidder</th>
						</tr>
                        <tr>
                            <td colspan="3">No Bid found</td>
                        </tr>
					</table>
				</div>
			</div>
            </div>
            </div>
		</div>          
	</div>
</section>



@stop
@section('scriptinclude')
n.js
<script src="{{ asset('front/js/js-date-format.min.js') }}"></script>
<script src="{{ asset('front/js/moment-timezone.min.js') }}"></script>
<script src="{{ asset('front/js/moment-timezone-with-data-2012-2022.min.js') }}"></script>

<script src="{{ asset('front/js/utility.js') }}"></script>
<script src="{{ asset('front/js/socket.js') }}"></script>
    <script type="text/javascript">
    
        try{

            

            var timezone = "{{ (Session::get('auth_user.tz_string'))?Session::get('auth_user.tz_string'):'UTC' }}"
            var socket = io('{{ @$constantUrlFile["NODE_API_URL"] }}',{'forceNew':true,reconnection: true,reconnectionDelay: 1000,reconnectionDelayMax : 5000,reconnectionAttempts: 99999 });
            var loggedin_id = '{{ @$bidDetail["logged_in_userid"] }}';
            var increment = '{{ @$constantUrlFile["BID_INCREMENTAL"] }}';

            var start_date_time = '{{ date("U", strtotime($bidDetail["bid_start_at"])) }}';

            var current_date_time = '{{ date("U") }}';

            var last_date_time = '{{ date("U", strtotime($bidDetail["popcorn_start_at"])) }}';

            var alertTimer = "";

            socket.emit('getBidIdDataRequest','{{ @$bidDetail["id"] }}',function(message){
             	console.log("::::::::: Received Confirmation For User Id :::::::::")
             	console.log(message);
             });

            socket.emit("adduser",'{{ @$bidDetail["id"] }}',function(data){
                console.log("data")
            });

            var refreshTimerId = '';

            socket.on("bidTimer",function(data){
                        var $seconds_div = $('.seconds');
                        var $minutes_div = $('.minutes');
                        //console.log("da")
                        
                        if(data < 1800)
                        {
                            timestamp = 1800 - data
                            var hours   = component(timestamp,      60 * 60) % 24,
                            minutes = checkTime(component(timestamp,           60) % 60),
                            seconds = checkTime(component(timestamp,            1) % 60);
                            $seconds_div.html(seconds);    
                            $minutes_div.html(minutes);                             
                            if(minutes == "00" && seconds == "00"){
                                clearInterval(refreshIntervalId);
                            }       
                        }                         
            });


            socket.on('getBidIdDataResponse',function(message){

             	
                $("#bid_count").text(message.length)
                if(message.length > 0){
                    var html = "<table><tr><th>Time</th><th>Amount</th><th>Bidder</th></tr>";
                 	$.each(message,function(key,data){
                 		//console.log(data)
                        var date = new Date(data.created_date);

                        time = moment(date).tz(timezone.toString()).format("h:mm A");
                        date = moment(date).tz(timezone.toString()).format("MMMM D, YYYY");
                        var username = ''
                        if(loggedin_id==data.user_id){
                        
                            username = 'Myself'
                        
                        }else{

                            username = "User "+data.user_id
                        }

                 		html += '<tr><td><span class="date"><i class="fa fa-calendar" aria-hidden="true"></i>'+date+'</span><span class="time">'+time+'</span></td><td>$'+thousandSeparator(data.amount.toString()) +'</td><td>'+username+' </td></tr>'
                 	})

                 	html +="</table>";
    					
                }else{
                    var html = "<div class='text-center' style='height:200px;margin-top: 100px;'>No Bid found</div>"
                }
    			$("#bid_history").html(html)
             });

    		socket.on("newBid",function(data){

                try{

                    if (data["error"] !== undefined && data["error"]!="")
                    {

                        $("#msg_section").html('<div class="clearfix"><div class="alert alert-danger no-margin"><button type="button" class="close" data-dismiss="alert"><i class="ace-icon fa fa-times"></i></button> '+ data['error'] +'</div></div>')                                
                    }else{
                        
                        current_bid = "$"+thousandSeparator(data.amount.toString());
                        last_bid = parseInt(($("#lastbid").val()).replace( /[^0-9\.]+/g, ''));

                        var nextbid = parseInt(data.amount) + parseInt($("#bid_increment_amount").val());
                        $("#bid_current").text(current_bid)
                        $("#bid_next").text("$"+thousandSeparator(nextbid.toString()))
                        $("#next_allowable_bid").text("$"+thousandSeparator(nextbid.toString()))
                        //$("#bid_count").text(parseInt($("#bid_count").text())+1)
                        $("#bid_current_amount").val(nextbid)
                        $(".bidamount").val("$"+thousandSeparator(nextbid.toString()))

                        if(loggedin_id==data.user_id){
                            $("#lastbid").val(current_bid)
                            $(".msg_section").html('<div class="clearfix"><div class="alert alert-success no-margin"><button type="button" class="close" data-dismiss="alert"><i class="ace-icon fa fa-times"></i></button> Bid added</div></div>');
                        
                        }else{
                            last_bid_diff = "$" + thousandSeparator((data.amount - last_bid).toString());
                            $(".msg_section").html('<div class="clearfix"><div class="alert alert-danger no-margin"><button type="button" class="close" data-dismiss="alert"><i class="ace-icon fa fa-times"></i></button>You have been outbid by '+last_bid_diff+' with a '+current_bid+' bid from User '+data.user_id+'.</div></div>')
                        }

                        $(".minus-btn").addClass("inactiveLink")

                    }

                    clearInterval(alertTimer);

                    alertTimer = setInterval(function() { 
                        $(".alert").slideUp(500, function(){
                    
                            $(".msg_section").html('');
                    
                        });  

                    }, 5000);

                }
                catch(e){
                    console.log(e)
                }
               
    		})	        


            socket.on("myBid",function(data){

                try{

                    if (data["error"] !== undefined && data["error"]!="")
                    {

                        $(".msg_section").html('<div class="clearfix"><div class="alert alert-danger no-margin"><button type="button" class="close" data-dismiss="alert"><i class="ace-icon fa fa-times"></i></button> '+ data['error'] +'</div></div>')                                
                    }else{
                        var nextbid = parseInt(data.amount) + parseInt($("#bid_increment_amount").val());
                        
                        $("#bid_current").text("$"+thousandSeparator(data.amount.toString()))
                        $("#bid_next").val("$"+thousandSeparator(nextbid.toString()))
                        $("#next_allowable_bid").text("$"+thousandSeparator(nextbid.toString()))
                        
                        //$("#bid_count").text(parseInt($("#bid_count").text())+1)
                        $("#bid_current_amount").val(nextbid)
                        
                        $(".bidamount").val("$"+thousandSeparator(nextbid.toString()))

                        $("#lastbid").val("$"+thousandSeparator(data.amount.toString()))

                        $(".msg_section").html('<div class="clearfix"><div class="alert alert-success no-margin"><button type="button" class="close" data-dismiss="alert"><i class="ace-icon fa fa-times"></i></button> Bid added</div></div>');
                        $(".minus-btn").addClass("inactiveLink")
                    }
                    $(".bidBtn").prop('disabled', false);
                    $(".bidBtn").removeClass("disable-btn");
                    clearInterval(alertTimer);

                    alertTimer = setInterval(function() { 
                        $(".alert").slideUp(500, function(){
                    
                            $(".msg_section").html('');
                    
                        });  

                    }, 5000);            
                }
                catch(e){
                    console.log(e)
                }
               
            })  


            jQuery.validator.addMethod("bidmaximum", function(value, element) {

              amount = parseInt(($("#bid_current_amount").val()).replace(/[^0-9\.]+/g, ''));

              bid_minimum_amount = parseInt(($("#bid_minimum_amount").val()).replace( /[^0-9\.]+/g, ''));


              value = parseInt((value).replace(/[^0-9\.]+/g, ''));


              if(amount <= value){
                    
                    if(bid_minimum_amount <= value){

                        return 1;
                    }else{
                        return 0;
                    }
              } 
              else{
              
                return 0;
             
              }
            }, "Please enter more or equal to Next Bid");        

            jQuery.validator.addMethod("bidlimit", function(value, element) {

              bid_max_amount = parseInt(($("#bid_max_amount").val()).replace( /[^0-9\.]+/g, ''));

              value = parseInt((value).replace(/[^0-9\.]+/g, ''));

              if(bid_max_amount >= value){
                    return 1;
              } 
              else{              
                return 0;             
              }
            }, "Please contact admin, you reached your maximum allowable bid");     



            $('.form_bid').each(function(key, form) {
                $(form).validate({
                	errorElement: "span",
                    rules: {
                    	amount : { required:true,bidmaximum : true,bidlimit:true}
                    },submitHandler: function(form){

        	            var amount = $("#bidamount").val();
                        amount = amount.replace(/[^0-9\.]+/g, '');
                        //console.log(amount);return false;

        	            socket.emit('saveBid','{{ @$bidDetail["logged_in_userid"] }}','{{ @$bidDetail["id"] }}',amount);
                        $(".bidBtn").prop('disabled', true);
                        $(".bidBtn").addClass("disable-btn");
                        //form.reset()         

                    	return false;
                    }
                });
            });


            $(".bidamount").change(function(){
                var value = $(this).val();
                amount = value.replace(/[^0-9\.]+/g, '')
                //Math.round(amount/1000)*1000
                $(".bidamount").val("$"+thousandSeparator(amount.toString()))
            });

 

            socket.on("endBidResponse",function(data){
                
                var amount = 0
                
                if (data[0] !== undefined && data[0].amount !== undefined){
                    amount = data[0].amount
                }    
                $(".bidsection").remove()
                $(".msg_section").html('<div class="clearfix"><div class="finalalert alert-success no-margin"> BID ENDED: A final, winning bid of $'+thousandSeparator(amount.toString())+' has secured the purchase of this home.</div></div>')   
                $("#bid_status").text("OutBid")

                socket.emit("leaveAuction",'{{ @$bidDetail["id"] }}')  

                           
            })      

            socket.on("reconnect",function(data){
                console.log("Reconnect");
                socket.emit("adduser",'{{ @$bidDetail["id"] }}');                
            });

            $(".plus-btn").click(function(){
 
                amount = parseInt(($("#bidamount").val()).replace(/[^0-9\.]+/g, ''));
                amount = amount + parseInt(increment)
                $("#bid_next").val(amount)
                $(".bidamount").val("$"+thousandSeparator(amount.toString()))
                $(".minus-btn").removeClass("inactiveLink")

                return false;
            })

            $(".minus-btn").click(function(){
 
                amount = parseInt(($("#bidamount").val()).replace(/[^0-9\.]+/g, ''));
                amount = amount - parseInt(increment)
                $("#bid_next").val(amount)
                $(".bidamount").val("$"+thousandSeparator(amount.toString()))

                bid_minimum_amount = parseInt(($("#bid_current_amount").val()).replace(/[^0-9\.]+/g, ''));

                if(amount <= bid_minimum_amount){
                    $(".minus-btn").addClass("inactiveLink")
                }
                return false;
            })    

            function component(x, v) {
                return Math.floor(x / v);
            }

            function checkTime(i) {
                if (i < 10) {i = "0" + i};  // add zero in front of numbers < 10
                return i;
            }

            var refreshIntervalId = timertimestamp = "";


            socket.on("popcornTimer",function(data){

                timertimestamp = data;
                var hours   = component(timertimestamp,      60 * 60) % 24,
                    minutes = checkTime(component(timertimestamp,           60) % 60),
                    seconds = checkTime(component(timertimestamp,            1) % 60);
                $(".mini-timer").html(seconds);    
                                            
             
            });


            socket.on("startTimer",function(data){//alert("Timer")
                $(".timer-alert").remove();
                $(".time-counter").append('<div class="timer-alert"><span class="mini-timer">'+data+'</span></div>');
                $(".msg_section").html('<div class="clearfix"><div class="alert alert-success no-margin"><button type="button" class="close" data-dismiss="alert"><i class="ace-icon fa fa-times"></i></button> BID OVERTIME: An additional minute has been added to accommodate high bidding activity </div></div>') 

                clearInterval(alertTimer);

                alertTimer = setInterval(function() { 
                    $(".alert").slideUp(500, function(){
                
                        $(".msg_section").html('');
                
                    });  

                }, 5000);

                $('.seconds,.minutes').html("00");
                
                clearInterval(refreshIntervalId);
                clearInterval(refreshTimerId);

                timertimestamp = data;
                refreshTimerId = setInterval(function() {
                    timertimestamp--;
                    var hours   = component(timertimestamp,      60 * 60) % 24,
                        minutes = checkTime(component(timertimestamp,           60) % 60),
                        seconds = checkTime(component(timertimestamp,            1) % 60);
                        $(".mini-timer").html(seconds);    
                                            
                        if(seconds == "00"){
                            clearInterval(refreshTimerId);
                        }
                }, 1000);                
            });
            
            start_date_time = parseInt(start_date_time);
            current_date_time = parseInt(current_date_time)
             
            if (start_date_time <= current_date_time)
            {

                start_date_time_min = start_date_time + 30*60;

                if(start_date_time_min >= current_date_time){


                    var timestamp =  start_date_time_min - current_date_time;
                    //console.log(timestamp)
                    //timestamp /= 1000; // from ms to seconds
                    timestamp = Math.floor(timestamp)


                        var $seconds_div = $('.seconds');
                        var $minutes_div = $('.minutes');
                        
                        refreshIntervalId = setInterval(function() {
                            timestamp--;
                            var hours   = component(timestamp,      60 * 60) % 24,
                                minutes = checkTime(component(timestamp,           60) % 60),
                                seconds = checkTime(component(timestamp,            1) % 60);
                                $seconds_div.html(seconds);    
                                $minutes_div.html(minutes);                             
                                if(minutes == "00" && seconds == "00"){
                                    clearInterval(refreshIntervalId);
                                }
                        }, 1000);
                }

                max_date_time = start_date_time_min + 15*60;
                if(current_date_time > start_date_time_min && current_date_time <= max_date_time){

                    $('.seconds,.minutes').html("00");
                    
                    clearInterval(refreshIntervalId);
                    
                    var timertimestamp = 60 - component(current_date_time,  1) % 60;
                    seconds = checkTime(timertimestamp)
                    $(".time-counter").append('<div class="timer-alert"><span class="mini-timer">'+seconds+'</span></div>');
                    refreshTimerId = setInterval(function() {
                        timertimestamp--;
                        var hours   = component(timertimestamp,      60 * 60) % 24,
                            minutes = checkTime(component(timertimestamp,           60) % 60),
                            seconds = checkTime(component(timertimestamp,            1) % 60);

                            $(".mini-timer").html(seconds);    
                                                
                            if(seconds == "00"){
                                clearInterval(refreshTimerId);
                            }
                    }, 1000);       

                }
            }
            
          
        }catch(e){

        }  

</script>        
@stop
