@extends('layouts.master')
@section('title', trans('seocontent.home_title'))
@section('meta_title', trans('seocontent.home_meta_title'))
@section('meta_description', trans('seocontent.home_desc'))
@section('sidebar')
@parent
@endsection
@section('content')
<style>
    .MT20{
        margin-top:20px;
    }
</style>

<?php
$constantDataFile = Config::get('constants');
?> 


<section class="banner inner-page-banner">
    <div class="banner-content">
        <div class="container">
            <h2 class="animated" data-animation="appeared fadeInUp" data-animation-delay="200">An Online Bidding Platform</h2>
            <h3 class="animated" data-animation="appeared fadeInUp" data-animation-delay="400"><span>For transacting the best </span>NEW HOMES <span> and </span> CONDOS <span> on the market </span></h3>               
        </div>
    </div>
</section>
<section class="bid-registration-page">
    <div class="container">
        <h3>Bidding Detail</h3>
        <div class="form-section ">

            @if(isset($authmsg))
                <div class="MT20">
                {!! $authmsg !!}
                    <a href="{{ URL::previous() }}" class="center btn submitBtn">Back</a>
                </div>
            @else

                @if(Session::has('registermsg'))
                    {!! Session::get('registermsg') !!}
                @endif
                
                @if(isset($bidDetail['pre_qualified']) && $bidDetail['pre_qualified']=="1")
                    @include('bid.qualified')
                @else
                    @include('bid.prequalified')
                @endif

            @endif
        </div>              
    </div>
</section>



@stop
@section('scriptinclude')
<script src="{{ asset('front/js/jquery-ui.js') }}"></script>
<script src="{{ asset('front/js/utility.js') }}"></script>
<script src="{{ asset('front/js/bid/bidregistration.js') }}"></script>
<script>
    /*
    $("#state_id").change(function(){
        
        var stateid = $("#state").val()

        $.ajax({
            url: '{{ URL::route("utility.city") }}',
            data : {"state":stateid},
            dataType: 'json',
            success : function(data){console.log(data)
                var html = "<option>Select City</option>";
                $.each(data.items,function(key,value){
                    html += "<option value='"+value.id+"''>"+value.text+"</option>";
                });
                $("#city").html(html)                
            }
        });
        
    });
    */


    $("#country_id").change(function(){
        var country = $("#country").val()
        $.ajax({
            url: '{{ URL::route("utility.state") }}',
            data : {"country":country},
            dataType: 'json',
            success : function(data){
                console.log(data)
                var html = "<option>Select State</option>";
                $.each(data.items,function(key,value){
                    html += "<option value='"+value.id+"''>"+value.text+"</option>";
                });
                $("#state").html(html)
            }
        });
    });


    $("#auto_bid_allowed").change(function(){
        if($(this).is(":checked")){
            $("#auto_bid_section").removeClass("hide")
        }else{
            $("#auto_bid_section").addClass("hide")
        }
    });

    $("#is_agent").change(function(){
        if($(this).is(":checked")){
            $(".agent_section").removeClass("hide")
        }else{
            $("#agent_name,#license_number,#agent_email").val('')            
            $(".agent_section").addClass("hide")
        }
    });


    $( "#city" ).autocomplete({
      source: function(request, response) {
        console.log(request.term)
            $.getJSON("{{ URL::route('utility.citylist') }}", { state: $('#state_id').val(),term : request.term }, 
            response);
      },
      //minLength: 2,
      select: function( event, ui ) {
        console.log( "Selected: " + ui.item.value + " aka " + ui.item.id );
      }
    });          

</script>

@stop
