@extends('layouts.master')
@section('title', trans('seocontent.home_title'))
@section('meta_title', trans('seocontent.home_meta_title'))
@section('meta_description', trans('seocontent.home_desc'))
@section('sidebar')
@parent
@endsection
@section('content')


<?php
$constantDataFile = Config::get('constants');
?> 


<section class="banner inner-page-banner">
    <div class="banner-content">
        <div class="container">
            <h2 class="animated" data-animation="appeared fadeInUp" data-animation-delay="200">An Online Bidding Platform</h2>
            <h3 class="animated" data-animation="appeared fadeInUp" data-animation-delay="400"><span>For transacting the best </span>NEW HOMES <span> and </span> CONDOS <span> on the market </span></h3>   
                     
        </div>
    </div>
</section>
<section class="bid-registration-page">
    <div class="container">
        <h3 class="animated" data-animation="appeared fadeInUp" data-animation-delay="200">Bidding Registration</h3>
        <div class="form-section">

                @if(Session::has('registermsg'))
                    {!! Session::get('registermsg') !!}
                @endif

            <form id="bid_form" name="bid_form" action="{{ URL::route('bid.savebidregistration') }}" method="POST" enctype='multipart/form-data'>

                <input type="hidden" id="_token" name="_token" value="{{ csrf_token() }}">
                <h4 class="animated" data-animation="appeared fadeInUp" data-animation-delay="300">Buyer Information</h4>

                <div class="buyar-info gray-bg">
                    <div class="row">
                        <div class="col-sm-6 col-xs-12 padding-right">
                            <div class="form-group animated" data-animation="appeared fadeInDown" data-animation-delay="100">
                                <label>Registrant Name<sup>*</sup></label>
                                {!! Form::text('registrant_name',@Session::get('auth_user')['name'] ,['class'=>'form-control',"id"=>"registrant_name"] ) !!}
                            </div>
                        </div>
                        <div class="col-sm-6 col-xs-12 padding-left">
                            <div class="form-group animated" data-animation="appeared fadeInDown" data-animation-delay="200">
                                <label>Buyer Name (if different)</label>
                                {!! Form::text('name',"", ['class'=>'form-control',"id"=>"name"] ) !!}
                            </div>
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-sm-6 col-xs-12 padding-right">
                            <div class="form-group animated" data-animation="appeared fadeInDown" data-animation-delay="300">
                                <label>Email<sup>*</sup></label>
                                {!! Form::text('email',@Session::get('auth_user')['email'], ['class'=>'form-control',"id"=>"email"] ) !!}
                            </div>
                        </div>
                        <div class="col-sm-6 col-xs-12 padding-left">
                            <div class="form-group animated" data-animation="appeared fadeInDown" data-animation-delay="400">
                                <label>Mobile Number<sup>*</sup></label>
                                {!! Form::text('contact_number',@Session::get('auth_user')['contact_number'], ['class'=>'form-control',"id"=>"contact_number"] ) !!}
                            </div>
                        </div>
                    </div>  
                    <div class="row">
                        <div class="col-sm-6 col-xs-12 padding-right">
                            <div class="form-group animated" data-animation="appeared fadeInDown" data-animation-delay="500">
                                <label>Office Number</label>
                                {!! Form::text('office_number',"", ['class'=>'form-control',"id"=>"office_number"] ) !!}
                            </div>
                        </div>
                        <div class="col-sm-6 col-xs-12 padding-left">
                            <div class="form-group animated" data-animation="appeared fadeInDown" data-animation-delay="600">
                                <label>Extension</label>
                                {!! Form::text('extension',"", ['class'=>'form-control',"id"=>"extension"] ) !!}
                            </div>
                        </div>
                    </div>  
                    <div class="row">
                        <div class="col-sm-6 col-xs-12 padding-right">
                            <div class="form-group animated" data-animation="appeared fadeInDown" data-animation-delay="700">
                                <label>Address Line 1<sup>*</sup></label>
                                {!! Form::text('addressline',@Session::get('auth_user')['street'], ['class'=>'form-control',"id"=>"addressline"] ) !!}
                            </div>
                        </div>
                        <div class="col-sm-6 col-xs-12 padding-left">
                            <div class="form-group animated" data-animation="appeared fadeInDown" data-animation-delay="800">
                                <label>Address Line 2</label>
                                {!! Form::text('addressline2',"", ['class'=>'form-control',"id"=>"addressline2"] ) !!}
                            </div>
                        </div>
                    </div>

                    <div class="row">
                        <div class="col-sm-6 col-xs-12 padding-right">
                            <div class="form-group animated" data-animation="appeared fadeInDown" data-animation-delay="800">
                                <label>Country<sup>*</sup></label>
                                {!! Form::select('country',[''=>'Please Select']+$country_list,@Session::get('auth_user')['country'], ["class"=> "form-control","id"=>"country"] ) !!}
                            </div>
                        </div>
                        <div class="col-sm-6 col-xs-12 padding-left">
                            <div class="form-group animated" data-animation="appeared fadeInDown" data-animation-delay="800">
                                <label>State<sup>*</sup></label>
                                {!! Form::select('state',[''=>'Please Select']+$state_list,@Session::get('auth_user')['state'], ["class"=> "form-control","id"=>"state"] ) !!}
                            </div>
                        </div>
                    </div>

                    <div class="row">
                        <div class="col-sm-6 col-xs-12 padding-right">
                            <div class="form-group animated" data-animation="appeared fadeInDown" data-animation-delay="800">
                                <label>City<sup>*</sup></label>
                                {!! Form::text('city',@Session::get('auth_user')['city_name'], ['class'=>'form-control',"id"=>"city"] ) !!} 
                            </div>
                        </div>
                        <div class="col-sm-6 col-xs-12 padding-left">
                            <div class="form-group animated" data-animation="appeared fadeInDown" data-animation-delay="800">
                                <label>Zip Code<sup>*</sup></label>
                                {!! Form::text('zipcode',@Session::get('auth_user')['zipcode'], ['class'=>'form-control',"id"=>"zipcode"] ) !!}
                            </div>
                        </div>
                    </div>

                                        
                </div>


                <h4 class="animated" data-animation="appeared fadeInUp" data-animation-delay="400">Agent Information</h4>
                <div class="purchase-info gray-bg autobids-block">
                    <div class="row">

                        <div class="col-md-6 col-sm-6 col-xs-12 padding-right">
                            <div class="form-group animated check-label" data-animation="appeared fadeInDown" data-animation-delay="300">
                                <label>Are you working with an agent? </label>
                                {!! Form::checkbox('is_agent',"1",false, ['class'=>'',"id"=>"is_agent"] ) !!}
                            </div>
                        </div> 

                        <div class="col-sm-6 col-xs-12 padding-left agent_section hide ">
                            <div class="form-group animated" data-animation="appeared fadeInDown" data-animation-delay="300">
                                <label> Name of Agent <sup>*</sup></label>
                                {!! Form::text('agent_name',"", ['class'=>'form-control',"id"=>"agent_name"] ) !!}
                            </div>
                        </div>


                    </div>

                    <div class="row hide agent_section">
                        <div class="col-sm-6 col-xs-12 padding-right">
                            <div class="form-group animated" data-animation="appeared fadeInDown" data-animation-delay="800">
                                <label>Email of Agent<sup>*</sup></label>
                                {!! Form::text('agent_email',"", ['class'=>'form-control',"id"=>"agent_email"] ) !!}
                            </div>
                        </div>
                        <div class="col-sm-6 col-xs-12 padding-left">
                            <div class="form-group animated" data-animation="appeared fadeInDown" data-animation-delay="800">
                                <label>License #</label>
                                {!! Form::text('license_number',"", ['class'=>'form-control',"id"=>"license_number"] ) !!}
                            </div>
                        </div>                         
                    </div>                            
                   
                </div>     

                <input type="hidden" name="property_id" value="{{ @$property_id }}">
                <h4 class="animated" data-animation="appeared fadeInUp" data-animation-delay="400">Property to bid</h4>
                <div class="purchase-info gray-bg property-info-block">
                    <div class="row">
                        <div class="col-xs-12">
                            <div class="form-group multiselectOption animated" data-animation="appeared fadeInDown" data-animation-delay="200">
                           
                                <label>Property </label>
                               
                                                                 
                                <?php 
                                    $propObj = array();
                                    if(!empty($bid_property)){
                                        foreach($bid_property as $val){
                                            if($val["id"]==$property_id){
                                                $propObj = $val;
                                                break;
                                            }
                                        }
                                        
                                    }
                                ?>
                                
                                <p>
                                    {{ @$propObj['name'] }}
                                </p>
                               
                           
                               
                            </div>
                        </div>                              
                    </div>
                </div>         
                <input type="hidden" id="minprice" value="{{ @$propObj['price'] }}"></input> 
                <input type="hidden" name="prop" id="prop" value="{{ @$property_id }}"></input>

                <h4 class="animated" data-animation="appeared fadeInUp" data-animation-delay="400">My Autobid Preferences</h4>
                <div class="purchase-info gray-bg autobids-block">
                    <div class="row">

                        <div class="col-md-6 col-sm-12 col-xs-12 padding-right">
                            <div class="form-group check-label animated" data-animation="appeared fadeInDown" data-animation-delay="300">
                                <label>I would like to elect Autobid </label>
                                {!! Form::checkbox('auto_bid_allowed',"1",false, ['class'=>'',"id"=>"auto_bid_allowed"] ) !!}
                            </div>
                        </div> 

                    </div>

                    <div class="row hide" id="auto_bid_section">
                        <div class="col-md-6 col-sm-12 col-xs-12 padding-right">
                            <div class="form-group check-label animated" data-animation="appeared fadeInDown" data-animation-delay="300">
                                <label class="add-autobid"> I would like to add Autobids  </label>
                                {!! Form::text('auto_bid_amount',"", ['class'=>'amount form-control',"id"=>"auto_bid_amount"] ) !!}
                            </div>
                        </div>

                        <div class="col-md-6 col-sm-12 col-xs-12 padding-right">
                            <div class="form-group animated" data-animation="appeared fadeInDown" data-animation-delay="300">
                                <label class="allow-autobid">
                                    Note : 
                                        Autobids allow you to bid automatically upto this amount 
                                        <!--li> AutoBid increment by $1,000 at each automatic bid </li-->
                                </label>
                                
                            </div>
                        </div>                          
                    </div>                            
                   
                </div>     


                <h4 class="animated" data-animation="appeared fadeInUp" data-animation-delay="400">Pre Qualification & Proof of funds</h4>
                <div class="funds-info gray-bg">
                    <div class="row">
                        <div class="col-md-6 col-sm-12 col-xs-12 padding-right">
                            <div class="form-group animated" data-animation="appeared fadeInDown" data-animation-delay="300">
                                <label class="add-autobid">Requested Bid Limit<sup>*</sup></label>
                                {!! Form::text('amount',"", ['class'=>'amount form-control',"id"=>"amount"] ) !!}
                            </div>
                        </div>  
                        <div class="col-md-6 col-sm-12 col-xs-12 padding-right">
                            <div class="form-group animated" data-animation="appeared fadeInDown" data-animation-delay="300">
                                <label class="allow-autobid">Note : This amount help you to set total preference</label>
                                
                            </div>
                        </div>                         
                    </div>

                    <div class="row">
                        <div class="col-sm-12 col-xs-12">
                            <p class="animated" data-animation="appeared fadeInUp" data-animation-delay="500">Please provide proof of funds or a bank financing letter to demonstrate your ability to bid up to your requested limit.</p>
                        </div>

                        <?php 
                                $documentOption = "";
                                if(!empty($constantDataFile['DOCUMENT_LIST'])){
                                    foreach(Config::get('constants.DOCUMENT_LIST') as $key=>$data){
                                            $documentOption .= '<option value="'.$key.'">'.$data.'</option>';
                                    }
                                }
                        ?>

                        <input type="hidden" id="documentoption" value="{{ $documentOption }}">
						<div class="addList">
							<div id="documentlist">
                                <div id="doclist0">
    								<div class="col-md-6 col-sm-12 col-xs-12 padding-right">                                    
    									<select name="document[]" id="document" class="form-control animated" data-animation="appeared fadeInDown" data-animation-delay="500">
                                        {!! $documentOption !!}
    									</select>
    								</div>      
    								<div class="col-md-6 col-sm-12 col-xs-12 padding-left add-row"> 
    									<div class="brouse-file choose-file" data-animation="appeared fadeInDown" data-animation-delay="600">
    										<input type="file" name="document_file[]" id="document_file" onchange="checkimagetype(this.id)" data-targetimg="filetext" class="custom-file-input">                                
    										<label for="document_file"><span class="chose-file-text">Choose File</span><span id="filetext" class="file-text">no file chosen</span></label>
    										<i class="fa fa-window-close" data-attr="0" aria-hidden="true"></i>
    									</div>                                                                   
    								</div>   	
                                </div>						
							</div>    
						</div>
						<div class="col-xs-12">
							<a class="btn addMore">Add More</a>
						</div>
                    </div>
                    <div class="row">
                        <div class="col-sm-12 col-xs-12 text-center">
                            <div class="btn-block">
                                <button class="btn submitBtn animated" data-animation="appeared bounceInUp" data-animation-delay="600">Submit</button>
                            </div>
                        </div>
                    </div>
                </div>
                
            </form>
        </div>              
    </div>
</section>



@stop
@section('scriptinclude')
<script src="{{ asset('front/js/jquery-ui.js') }}"></script>
<script src="{{ asset('front/js/utility.js') }}"></script>
<script src="{{ asset('front/js/bid/bidregistration.js') }}"></script>
<script>
    /*
    $("#state_id").change(function(){
        
        var stateid = $("#state").val()

        $.ajax({
            url: '{{ URL::route("utility.city") }}',
            data : {"state":stateid},
            dataType: 'json',
            success : function(data){console.log(data)
                var html = "<option>Select City</option>";
                $.each(data.items,function(key,value){
                    html += "<option value='"+value.id+"''>"+value.text+"</option>";
                });
                $("#city").html(html)                
            }
        });
        
    });
    */


    $("#country_id").change(function(){
        var country = $("#country").val()
        $.ajax({
            url: '{{ URL::route("utility.state") }}',
            data : {"country":country},
            dataType: 'json',
            success : function(data){
                console.log(data)
                var html = "<option>Select State</option>";
                $.each(data.items,function(key,value){
                    html += "<option value='"+value.id+"''>"+value.text+"</option>";
                });
                $("#state").html(html)
            }
        });
    });


    $("#auto_bid_allowed").change(function(){
        if($(this).is(":checked")){
            $("#auto_bid_section").removeClass("hide")
        }else{

            $("#auto_bid_section").addClass("hide")
        }
    });


    
    $("#is_agent").change(function(){
        if($(this).is(":checked")){
            $(".agent_section").removeClass("hide")
        }else{
            $("#agent_name,#license_number,#agent_email").val('')

            $(".agent_section").addClass("hide")
        }
    });

    /*
    $("#minprice").val($("#prop").find('option:selected').attr("data-value"))

    $("#prop").change(function(){
        $("#minprice").val($(this).find('option:selected').attr("data-value"))
    });*/

    $( "#city" ).autocomplete({
      source: function(request, response) {
        console.log(request.term)
            $.getJSON("{{ URL::route('utility.citylist') }}", { state: $('#state_id').val(),term : request.term }, 
            response);
      },
      //minLength: 2,
      select: function( event, ui ) {
        console.log( "Selected: " + ui.item.value + " aka " + ui.item.id );
      }
    });    

</script>

@stop
