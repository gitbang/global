@extends('layouts.inner_property',["footer"=>true])
@section('title', trans('seocontent.sell_title'))
@section('meta_title', trans('seocontent.sell_meta_title'))
@section('meta_description', trans('seocontent.sell_desc'))
@section('content')        

<section class="banner inner-page-banner">
    <div class="banner-content">
        <div class="container">
            <h2 class="animated" data-animation="appeared fadeInUp" data-animation-delay="200">An Online Bidding Platform</h2>
            <h3 class="animated" data-animation="appeared fadeInUp" data-animation-delay="400"><span>For transacting the best </span>NEW HOMES <span> and </span> CONDOS <span> on the market </span></h3>                   
        </div>
    </div>
</section>
<section class="property-submit-block">
    <div class="container">
        <h3 class="animated" data-animation="appeared fadeInUp" data-animation-delay="200">Property Request</h3>
        <div class="form-section">
                
                @if(Session::has('registermsg'))
                    {!! Session::get('registermsg') !!}
                @endif

                {!! Form::open(array('id'=>'request_form','route' => 'sell.saverequest', 'method' => 'post')) !!}  
                
                <div class="row">
                    
                    <div class="col-sm-6 col-xs-12 padding-right">
                        <div class="form-group animated" data-animation="appeared fadeInDown" data-animation-delay="100">
                            <label>Select<sup>*</sup></label>
                            <select name="user_type" id="usertype" class="form-control">
                                <option value="">Select </option>
                                <option value="4">Homebuilder </option>
                                <option value="3">Agent </option>
                                <option value="2">Seller </option>                               
                            </select>
                        </div>
                    </div>
                    <div class="col-sm-6 col-xs-12 homebuilder padding-left">
                        
                            <div class="form-group">
                                <label>Homebuilder name<sup>*</sup></label>
                                {!! Form::text('homebuilder_name',null,['id'=>'homebuilder_name','class'=>'form-control common-input-style']) !!}
                            </div>
                       
                    </div>

                </div>    

                <div class="row agent">
                    <div class="col-sm-6 col-xs-12 padding-right">
                        <div class="form-group">
                            <label>Brokerage name<sup>*</sup></label>
                            {!! Form::text('brokerage_name',null,['id'=>'brokerage_name','class'=>'form-control']) !!}
                        </div>
                    </div>
                    <div class="col-sm-6 col-xs-12 padding-left">
                        <div class="form-group">
                            <label>Agent License number<sup>*</sup></label>
                            {!! Form::text('agent_license_number',null,['id'=>'agent_license_number','class'=>'form-control']) !!}
                        </div>
                    </div>
                </div>
                    
                <div class="row">
                    <div class="col-sm-6 col-xs-12 padding-right">
                        <div class="form-group animated" data-animation="appeared fadeInDown" data-animation-delay="300">
                            <label>First Name<sup>*</sup></label>
                            {!! Form::text('first_name',null,['id'=>'first_name','class'=>'form-control']) !!}
                        </div>
                    </div>
                    <div class="col-sm-6 col-xs-12 padding-left">
                        <div class="form-group animated" data-animation="appeared fadeInDown" data-animation-delay="400">
                            <label>Last Name<sup>*</sup></label>
                            {!! Form::text('last_name',null,['id'=>'last_name','class'=>'form-control']) !!}
                        </div>
                    </div>
                </div>


                <div class="row">
                    <div class="col-sm-6 col-xs-12 padding-right">
                        <div class="form-group animated" data-animation="appeared fadeInDown" data-animation-delay="500">
                            <label>Email<sup>*</sup></label>
                            {!! Form::email('email',null,['id'=>'email','class'=>'form-control']) !!}
                        </div>
                    </div>
                    <div class="col-sm-6 col-xs-12 padding-left">
                        <div class="form-group animated" data-animation="appeared fadeInDown" data-animation-delay="600">
                            <label>Contact Number<sup>*</sup></label>
                            {!! Form::text('contact_number',null,['id'=>'contact_number','class'=>'form-control'])!!}
                        </div>
                    </div>
                </div>
                  
                <div class="row">
                    <div class="col-sm-6 col-xs-12 padding-right">
                        <div class="form-group animated" data-animation="appeared fadeInDown" data-animation-delay="700">
                            <label>Property's website</label>
                            {!! Form::text('website',null,['id'=>'website','class'=>'form-control common-input-style'])!!}
                        </div>
                    </div>

                    <div class="col-sm-6 col-xs-12 padding-left">
                        <div class="form-group animated" data-animation="appeared fadeInDown" data-animation-delay="800">
                            <label>Home Type</label>
                            <select name="home_type" class="form-control">
                                <option value="">Select </option>
                                <option value="0">New Home </option>
                                <option value="1">Existing Home </option>                               
                            </select>
                        </div>
                    </div>
                </div>

                <div class="row">
                    <div class="col-sm-6 col-xs-12 padding-right">
                        <div class="form-group animated" data-animation="appeared fadeInDown" data-animation-delay="800">
                            <label>Desired # of bidders</label>
                            {!! Form::text('desired',null,['id'=>'desired','class'=>'form-control common-input-style'])!!} 
                        </div>
                    </div>

                    <div class="col-sm-6 col-xs-12 padding-left">
                        <div class="form-group animated" data-animation="appeared fadeInDown" data-animation-delay="800">
                            <label>Current Offer Price</label>
                            {!! Form::text('price',null,['id'=>'price','class'=>'form-control'])!!}  
                        </div>
                    </div>
                </div>

                <div class="row">
                    
                    <div class="col-sm-6 col-xs-12 padding-right">
                        <div class="form-group animated" data-animation="appeared fadeInDown" data-animation-delay="800">
                            <label>Property Address</label>
                            {!! Form::textarea('address',null,['id'=>'address','class'=>'form-control',"rows"=>3])!!}
                        </div>
                    </div>

                    <div class="col-sm-6 col-xs-12 padding-left">
                        <div class="form-group animated" data-animation="appeared fadeInDown" data-animation-delay="800">
                            <label>Message</label>
                             {!! Form::textarea('cmessage',null,['id'=>'cmessage','class'=>'form-control common-input-style',"rows"=>3])!!}
                        </div>
                    </div>
                </div>

                  
                   
                <div class="row">
                    <div class="col-sm-12 col-xs-12 text-center">
                        <button class="btn submitBtn  animated" data-animation="appeared bounceInUp" data-animation-delay="800">Submit</button>
                    </div>
                </div>
            </form>
        </div>              
    </div>
</section>

@stop

@section('scriptinclude')

<script>
    $("#request_form").validate({
        //wrapper: "p",
        ignore : ":not(:visible)",
        errorElement: "span",
        rules: {
            user_type : {
                required : true
            },
            brokerage_name: {
                required: true,
                noSpace: true,
            },
            agent_license_number: {
                required: true,
                noSpace: true,
            },
            homebuilder_name: {
                required: true,
                noSpace: true,
            },             
            first_name: {
                required: true,
            },
            last_name: {
                required: true,
            },
            email: {
                required: true,
                email: true,
            },
            contact_number: {
                required: true
            },
            website: {
                url: true
            },
            desired: {
                number : true
            },
            price: {
                number : true
            },                                                                              
        }
    });

$("#usertype").change(function() {
    var value = $(this).val();
    if(value == "4"){
        $(".agent").hide();
		$(".homebuilder").fadeIn(300);
    }
    else if(value == "3"){
        $(".homebuilder").hide();
        $(".agent").fadeIn(300);
    }else{
        $(".homebuilder").hide();
        $(".agent").hide(); 
    }
});

</script>

@stop